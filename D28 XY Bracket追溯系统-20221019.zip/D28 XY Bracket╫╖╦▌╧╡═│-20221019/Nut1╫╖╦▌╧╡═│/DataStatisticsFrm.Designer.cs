﻿namespace 卓汇数据追溯系统
{
    partial class DataStatisticsFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel17 = new System.Windows.Forms.TableLayoutPanel();
            this.dtp_FixtureErrorTOP5Time = new System.Windows.Forms.DateTimePicker();
            this.label53 = new System.Windows.Forms.Label();
            this.btn_SelectFixtureError = new System.Windows.Forms.Button();
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.chart_FixtureErrorNumber = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tableLayoutPanel19 = new System.Windows.Forms.TableLayoutPanel();
            this.lb_Number5 = new System.Windows.Forms.Label();
            this.lb_FixtureCode5 = new System.Windows.Forms.Label();
            this.lb_Number4 = new System.Windows.Forms.Label();
            this.lb_FixtureCode4 = new System.Windows.Forms.Label();
            this.lb_Number3 = new System.Windows.Forms.Label();
            this.lb_FixtureCode3 = new System.Windows.Forms.Label();
            this.lb_Number2 = new System.Windows.Forms.Label();
            this.lb_FixtureCode2 = new System.Windows.Forms.Label();
            this.lb_Number1 = new System.Windows.Forms.Label();
            this.lb_FixtureCode1 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.dtp_DT_Table = new System.Windows.Forms.DateTimePicker();
            this.btn_SelectDTTable = new System.Windows.Forms.Button();
            this.chart_DT = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.dtp_DT_Data = new System.Windows.Forms.DateTimePicker();
            this.btn_SelectDTData = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.label114 = new System.Windows.Forms.Label();
            this.lb_Product_time = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.lb_RunTime_08_20 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_08_20 = new System.Windows.Forms.Label();
            this.lb_PendingTime_08_20 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.lb_RunTime_20_08 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_20_08 = new System.Windows.Forms.Label();
            this.lb_PendingTime_20_08 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.lb_RunTime_19_20 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_19_20 = new System.Windows.Forms.Label();
            this.lb_PendingTime_19_20 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.lb_RunTime_07_08 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_07_08 = new System.Windows.Forms.Label();
            this.lb_PendingTime_07_08 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.lb_RunTime_18_19 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_18_19 = new System.Windows.Forms.Label();
            this.lb_PendingTime_18_19 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.lb_RunTime_06_07 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_06_07 = new System.Windows.Forms.Label();
            this.lb_PendingTime_06_07 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.lb_RunTime_17_18 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_17_18 = new System.Windows.Forms.Label();
            this.lb_PendingTime_17_18 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.lb_RunTime_05_06 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_05_06 = new System.Windows.Forms.Label();
            this.lb_PendingTime_05_06 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.lb_RunTime_16_17 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_16_17 = new System.Windows.Forms.Label();
            this.lb_PendingTime_16_17 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.lb_RunTime_04_05 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_04_05 = new System.Windows.Forms.Label();
            this.lb_PendingTime_04_05 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.lb_RunTime_15_16 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_15_16 = new System.Windows.Forms.Label();
            this.lb_PendingTime_15_16 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.lb_RunTime_03_04 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_03_04 = new System.Windows.Forms.Label();
            this.lb_PendingTime_03_04 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.lb_RunTime_14_15 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_14_15 = new System.Windows.Forms.Label();
            this.lb_PendingTime_14_15 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.lb_RunTime_02_03 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_02_03 = new System.Windows.Forms.Label();
            this.lb_PendingTime_02_03 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.lb_RunTime_13_14 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_13_14 = new System.Windows.Forms.Label();
            this.lb_PendingTime_13_14 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.lb_RunTime_01_02 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_01_02 = new System.Windows.Forms.Label();
            this.lb_PendingTime_01_02 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.lb_RunTime_12_13 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_12_13 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.lb_RunTime_11_12 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_11_12 = new System.Windows.Forms.Label();
            this.lb_PendingTime_11_12 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.lb_RunTime_10_11 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_10_11 = new System.Windows.Forms.Label();
            this.lb_PendingTime_10_11 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lb_RunTime_09_10 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_09_10 = new System.Windows.Forms.Label();
            this.lb_PendingTime_09_10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lb_RunTime_08_09 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_08_09 = new System.Windows.Forms.Label();
            this.lb_PendingTime_08_09 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lb_PendingTime_20_21 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_20_21 = new System.Windows.Forms.Label();
            this.lb_RunTime_20_21 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lb_PendingTime_21_22 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_21_22 = new System.Windows.Forms.Label();
            this.lb_RunTime_21_22 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lb_PendingTime_22_23 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_22_23 = new System.Windows.Forms.Label();
            this.lb_RunTime_22_23 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.lb_PendingTime_23_00 = new System.Windows.Forms.Label();
            this.lb_RunTime_23_00 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.lb_PendingTime_00_01 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_00_01 = new System.Windows.Forms.Label();
            this.lb_ErrorTime_23_00 = new System.Windows.Forms.Label();
            this.lb_RunTime_00_01 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.lb_PendingTime_12_13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lb_Product_time_N1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.txt_CT1 = new System.Windows.Forms.TextBox();
            this.txt_AverageCT10 = new System.Windows.Forms.TextBox();
            this.txt_CT10 = new System.Windows.Forms.TextBox();
            this.txt_CT9 = new System.Windows.Forms.TextBox();
            this.txt_CT8 = new System.Windows.Forms.TextBox();
            this.txt_CT7 = new System.Windows.Forms.TextBox();
            this.txt_CT6 = new System.Windows.Forms.TextBox();
            this.txt_CT5 = new System.Windows.Forms.TextBox();
            this.txt_CT4 = new System.Windows.Forms.TextBox();
            this.txt_CT3 = new System.Windows.Forms.TextBox();
            this.txt_CT2 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.dtp_UPH_Table = new System.Windows.Forms.DateTimePicker();
            this.btn_SelectProductTable = new System.Windows.Forms.Button();
            this.chart_UPH = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel22 = new System.Windows.Forms.TableLayoutPanel();
            this.PF = new System.Windows.Forms.RadioButton();
            this.Yield = new System.Windows.Forms.RadioButton();
            this.All = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel20 = new System.Windows.Forms.TableLayoutPanel();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tableLayoutPanel21 = new System.Windows.Forms.TableLayoutPanel();
            this.EndDay = new System.Windows.Forms.DateTimePicker();
            this.StartDay = new System.Windows.Forms.DateTimePicker();
            this.outError = new System.Windows.Forms.Button();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.dgv_D = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.dgv_N = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.lb_Product_propery_N1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.lb_Product_Total_08_20 = new System.Windows.Forms.Label();
            this.lb_Product_NG_08_20 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_08_20 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.lb_Product_Total_20_08 = new System.Windows.Forms.Label();
            this.lb_Product_NG_20_08 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_20_08 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.lb_Product_Total_19_20 = new System.Windows.Forms.Label();
            this.lb_Product_NG_19_20 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_19_20 = new System.Windows.Forms.Label();
            this.label136 = new System.Windows.Forms.Label();
            this.lb_Product_Total_07_08 = new System.Windows.Forms.Label();
            this.lb_Product_NG_07_08 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_07_08 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.lb_Product_Total_18_19 = new System.Windows.Forms.Label();
            this.lb_Product_NG_18_19 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_18_19 = new System.Windows.Forms.Label();
            this.label144 = new System.Windows.Forms.Label();
            this.lb_Product_Total_06_07 = new System.Windows.Forms.Label();
            this.lb_Product_NG_06_07 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_06_07 = new System.Windows.Forms.Label();
            this.label148 = new System.Windows.Forms.Label();
            this.lb_Product_Total_17_18 = new System.Windows.Forms.Label();
            this.lb_Product_NG_17_18 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_17_18 = new System.Windows.Forms.Label();
            this.label152 = new System.Windows.Forms.Label();
            this.lb_Product_Total_05_06 = new System.Windows.Forms.Label();
            this.lb_Product_NG_05_06 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_05_06 = new System.Windows.Forms.Label();
            this.label156 = new System.Windows.Forms.Label();
            this.lb_Product_Total_16_17 = new System.Windows.Forms.Label();
            this.lb_Product_NG_16_17 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_16_17 = new System.Windows.Forms.Label();
            this.label160 = new System.Windows.Forms.Label();
            this.lb_Product_Total_04_05 = new System.Windows.Forms.Label();
            this.lb_Product_NG_04_05 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_04_05 = new System.Windows.Forms.Label();
            this.label164 = new System.Windows.Forms.Label();
            this.lb_Product_Total_15_16 = new System.Windows.Forms.Label();
            this.lb_Product_NG_15_16 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_15_16 = new System.Windows.Forms.Label();
            this.label168 = new System.Windows.Forms.Label();
            this.lb_Product_Total_03_04 = new System.Windows.Forms.Label();
            this.lb_Product_NG_03_04 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_03_04 = new System.Windows.Forms.Label();
            this.label172 = new System.Windows.Forms.Label();
            this.lb_Product_Total_14_15 = new System.Windows.Forms.Label();
            this.lb_Product_NG_14_15 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_14_15 = new System.Windows.Forms.Label();
            this.label176 = new System.Windows.Forms.Label();
            this.lb_Product_Total_02_03 = new System.Windows.Forms.Label();
            this.lb_Product_NG_02_03 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_02_03 = new System.Windows.Forms.Label();
            this.label180 = new System.Windows.Forms.Label();
            this.lb_Product_Total_13_14 = new System.Windows.Forms.Label();
            this.lb_Product_NG_13_14 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_13_14 = new System.Windows.Forms.Label();
            this.label184 = new System.Windows.Forms.Label();
            this.lb_Product_Total_01_02 = new System.Windows.Forms.Label();
            this.lb_Product_NG_01_02 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_01_02 = new System.Windows.Forms.Label();
            this.label188 = new System.Windows.Forms.Label();
            this.lb_Product_Total_12_13 = new System.Windows.Forms.Label();
            this.lb_Product_NG_12_13 = new System.Windows.Forms.Label();
            this.label191 = new System.Windows.Forms.Label();
            this.lb_Product_Total_11_12 = new System.Windows.Forms.Label();
            this.lb_Product_NG_11_12 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_11_12 = new System.Windows.Forms.Label();
            this.label195 = new System.Windows.Forms.Label();
            this.lb_Product_Total_10_11 = new System.Windows.Forms.Label();
            this.lb_Product_NG_10_11 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_10_11 = new System.Windows.Forms.Label();
            this.label199 = new System.Windows.Forms.Label();
            this.lb_Product_Total_09_10 = new System.Windows.Forms.Label();
            this.lb_Product_NG_09_10 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_09_10 = new System.Windows.Forms.Label();
            this.label203 = new System.Windows.Forms.Label();
            this.lb_Product_Total_08_09 = new System.Windows.Forms.Label();
            this.lb_Product_NG_08_09 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_08_09 = new System.Windows.Forms.Label();
            this.label207 = new System.Windows.Forms.Label();
            this.label208 = new System.Windows.Forms.Label();
            this.label209 = new System.Windows.Forms.Label();
            this.label210 = new System.Windows.Forms.Label();
            this.label211 = new System.Windows.Forms.Label();
            this.label212 = new System.Windows.Forms.Label();
            this.label213 = new System.Windows.Forms.Label();
            this.label214 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_20_21 = new System.Windows.Forms.Label();
            this.lb_Product_NG_20_21 = new System.Windows.Forms.Label();
            this.lb_Product_Total_20_21 = new System.Windows.Forms.Label();
            this.label218 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_21_22 = new System.Windows.Forms.Label();
            this.lb_Product_NG_21_22 = new System.Windows.Forms.Label();
            this.lb_Product_Total_21_22 = new System.Windows.Forms.Label();
            this.label222 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_22_23 = new System.Windows.Forms.Label();
            this.lb_Product_NG_22_23 = new System.Windows.Forms.Label();
            this.label226 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_23_00 = new System.Windows.Forms.Label();
            this.lb_Product_Total_23_00 = new System.Windows.Forms.Label();
            this.label229 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_00_01 = new System.Windows.Forms.Label();
            this.lb_Product_NG_00_01 = new System.Windows.Forms.Label();
            this.lb_Product_NG_23_00 = new System.Windows.Forms.Label();
            this.lb_Product_Total_00_01 = new System.Windows.Forms.Label();
            this.label234 = new System.Windows.Forms.Label();
            this.lb_Product_Lianglv_12_13 = new System.Windows.Forms.Label();
            this.lb_Product_Total_22_23 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.lb_Product_propery = new System.Windows.Forms.Label();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.dtp_UPH_Data = new System.Windows.Forms.DateTimePicker();
            this.btn_SelectProductData = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.tableLayoutPanel23 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel24 = new System.Windows.Forms.TableLayoutPanel();
            this.label69 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.tableLayoutPanel25 = new System.Windows.Forms.TableLayoutPanel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage10.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart_FixtureErrorNumber)).BeginInit();
            this.tableLayoutPanel19.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart_DT)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart_UPH)).BeginInit();
            this.tabPage6.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.tableLayoutPanel20.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            this.tabControl4.SuspendLayout();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_D)).BeginInit();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_N)).BeginInit();
            this.tableLayoutPanel11.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.tableLayoutPanel23.SuspendLayout();
            this.tableLayoutPanel24.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.tableLayoutPanel25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.webBrowser1);
            this.tabPage10.Location = new System.Drawing.Point(124, 4);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(733, 492);
            this.tabPage10.TabIndex = 3;
            this.tabPage10.Text = "tabPage10";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // webBrowser1
            // 
            this.webBrowser1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser1.Location = new System.Drawing.Point(3, 3);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(727, 486);
            this.webBrowser1.TabIndex = 3;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.tableLayoutPanel16);
            this.tabPage3.Location = new System.Drawing.Point(124, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(733, 492);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "治具统计";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.ColumnCount = 1;
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel16.Controls.Add(this.tableLayoutPanel17, 0, 0);
            this.tableLayoutPanel16.Controls.Add(this.tableLayoutPanel18, 0, 1);
            this.tableLayoutPanel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel16.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 2;
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.61789F));
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 86.38211F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(733, 492);
            this.tableLayoutPanel16.TabIndex = 1;
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.ColumnCount = 7;
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.51351F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.51351F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.51351F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18.91892F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.51351F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.51351F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.51351F));
            this.tableLayoutPanel17.Controls.Add(this.dtp_FixtureErrorTOP5Time, 3, 0);
            this.tableLayoutPanel17.Controls.Add(this.label53, 2, 0);
            this.tableLayoutPanel17.Controls.Add(this.btn_SelectFixtureError, 4, 0);
            this.tableLayoutPanel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel17.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 1;
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(727, 61);
            this.tableLayoutPanel17.TabIndex = 0;
            // 
            // dtp_FixtureErrorTOP5Time
            // 
            this.dtp_FixtureErrorTOP5Time.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dtp_FixtureErrorTOP5Time.CalendarFont = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.dtp_FixtureErrorTOP5Time.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.dtp_FixtureErrorTOP5Time.Location = new System.Drawing.Point(297, 17);
            this.dtp_FixtureErrorTOP5Time.Name = "dtp_FixtureErrorTOP5Time";
            this.dtp_FixtureErrorTOP5Time.Size = new System.Drawing.Size(131, 26);
            this.dtp_FixtureErrorTOP5Time.TabIndex = 0;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label53.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label53.Location = new System.Drawing.Point(199, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(92, 61);
            this.label53.TabIndex = 1;
            this.label53.Text = "时间：";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_SelectFixtureError
            // 
            this.btn_SelectFixtureError.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_SelectFixtureError.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_SelectFixtureError.Location = new System.Drawing.Point(434, 19);
            this.btn_SelectFixtureError.Name = "btn_SelectFixtureError";
            this.btn_SelectFixtureError.Size = new System.Drawing.Size(92, 23);
            this.btn_SelectFixtureError.TabIndex = 2;
            this.btn_SelectFixtureError.Text = "查询";
            this.btn_SelectFixtureError.UseVisualStyleBackColor = true;
            this.btn_SelectFixtureError.Click += new System.EventHandler(this.btn_SelectFixtureError_Click);
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.ColumnCount = 3;
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.83105F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 54.3379F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.83105F));
            this.tableLayoutPanel18.Controls.Add(this.chart_FixtureErrorNumber, 1, 0);
            this.tableLayoutPanel18.Controls.Add(this.tableLayoutPanel19, 1, 1);
            this.tableLayoutPanel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel18.Location = new System.Drawing.Point(3, 70);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 2;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(727, 419);
            this.tableLayoutPanel18.TabIndex = 1;
            // 
            // chart_FixtureErrorNumber
            // 
            chartArea1.Name = "ChartArea1";
            this.chart_FixtureErrorNumber.ChartAreas.Add(chartArea1);
            this.chart_FixtureErrorNumber.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chart_FixtureErrorNumber.Location = new System.Drawing.Point(168, 3);
            this.chart_FixtureErrorNumber.Name = "chart_FixtureErrorNumber";
            series1.ChartArea = "ChartArea1";
            series1.Name = "Series1";
            this.chart_FixtureErrorNumber.Series.Add(series1);
            this.chart_FixtureErrorNumber.Size = new System.Drawing.Size(389, 203);
            this.chart_FixtureErrorNumber.TabIndex = 5;
            this.chart_FixtureErrorNumber.Text = "chart1";
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.ColumnCount = 2;
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 67.19682F));
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.80318F));
            this.tableLayoutPanel19.Controls.Add(this.lb_Number5, 1, 5);
            this.tableLayoutPanel19.Controls.Add(this.lb_FixtureCode5, 0, 5);
            this.tableLayoutPanel19.Controls.Add(this.lb_Number4, 1, 4);
            this.tableLayoutPanel19.Controls.Add(this.lb_FixtureCode4, 0, 4);
            this.tableLayoutPanel19.Controls.Add(this.lb_Number3, 1, 3);
            this.tableLayoutPanel19.Controls.Add(this.lb_FixtureCode3, 0, 3);
            this.tableLayoutPanel19.Controls.Add(this.lb_Number2, 1, 2);
            this.tableLayoutPanel19.Controls.Add(this.lb_FixtureCode2, 0, 2);
            this.tableLayoutPanel19.Controls.Add(this.lb_Number1, 1, 1);
            this.tableLayoutPanel19.Controls.Add(this.lb_FixtureCode1, 0, 1);
            this.tableLayoutPanel19.Controls.Add(this.label56, 1, 0);
            this.tableLayoutPanel19.Controls.Add(this.label55, 0, 0);
            this.tableLayoutPanel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel19.Location = new System.Drawing.Point(168, 212);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.RowCount = 6;
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(389, 204);
            this.tableLayoutPanel19.TabIndex = 6;
            // 
            // lb_Number5
            // 
            this.lb_Number5.AutoSize = true;
            this.lb_Number5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_Number5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Number5.Location = new System.Drawing.Point(264, 165);
            this.lb_Number5.Name = "lb_Number5";
            this.lb_Number5.Size = new System.Drawing.Size(122, 39);
            this.lb_Number5.TabIndex = 11;
            this.lb_Number5.Text = "0";
            this.lb_Number5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_FixtureCode5
            // 
            this.lb_FixtureCode5.AutoSize = true;
            this.lb_FixtureCode5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_FixtureCode5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_FixtureCode5.Location = new System.Drawing.Point(3, 165);
            this.lb_FixtureCode5.Name = "lb_FixtureCode5";
            this.lb_FixtureCode5.Size = new System.Drawing.Size(255, 39);
            this.lb_FixtureCode5.TabIndex = 10;
            this.lb_FixtureCode5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Number4
            // 
            this.lb_Number4.AutoSize = true;
            this.lb_Number4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_Number4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Number4.Location = new System.Drawing.Point(264, 132);
            this.lb_Number4.Name = "lb_Number4";
            this.lb_Number4.Size = new System.Drawing.Size(122, 33);
            this.lb_Number4.TabIndex = 9;
            this.lb_Number4.Text = "0";
            this.lb_Number4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_FixtureCode4
            // 
            this.lb_FixtureCode4.AutoSize = true;
            this.lb_FixtureCode4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_FixtureCode4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_FixtureCode4.Location = new System.Drawing.Point(3, 132);
            this.lb_FixtureCode4.Name = "lb_FixtureCode4";
            this.lb_FixtureCode4.Size = new System.Drawing.Size(255, 33);
            this.lb_FixtureCode4.TabIndex = 8;
            this.lb_FixtureCode4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Number3
            // 
            this.lb_Number3.AutoSize = true;
            this.lb_Number3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_Number3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Number3.Location = new System.Drawing.Point(264, 99);
            this.lb_Number3.Name = "lb_Number3";
            this.lb_Number3.Size = new System.Drawing.Size(122, 33);
            this.lb_Number3.TabIndex = 7;
            this.lb_Number3.Text = "0";
            this.lb_Number3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_FixtureCode3
            // 
            this.lb_FixtureCode3.AutoSize = true;
            this.lb_FixtureCode3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_FixtureCode3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_FixtureCode3.Location = new System.Drawing.Point(3, 99);
            this.lb_FixtureCode3.Name = "lb_FixtureCode3";
            this.lb_FixtureCode3.Size = new System.Drawing.Size(255, 33);
            this.lb_FixtureCode3.TabIndex = 6;
            this.lb_FixtureCode3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Number2
            // 
            this.lb_Number2.AutoSize = true;
            this.lb_Number2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_Number2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Number2.Location = new System.Drawing.Point(264, 66);
            this.lb_Number2.Name = "lb_Number2";
            this.lb_Number2.Size = new System.Drawing.Size(122, 33);
            this.lb_Number2.TabIndex = 5;
            this.lb_Number2.Text = "0";
            this.lb_Number2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_FixtureCode2
            // 
            this.lb_FixtureCode2.AutoSize = true;
            this.lb_FixtureCode2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_FixtureCode2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_FixtureCode2.Location = new System.Drawing.Point(3, 66);
            this.lb_FixtureCode2.Name = "lb_FixtureCode2";
            this.lb_FixtureCode2.Size = new System.Drawing.Size(255, 33);
            this.lb_FixtureCode2.TabIndex = 4;
            this.lb_FixtureCode2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Number1
            // 
            this.lb_Number1.AutoSize = true;
            this.lb_Number1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_Number1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Number1.Location = new System.Drawing.Point(264, 33);
            this.lb_Number1.Name = "lb_Number1";
            this.lb_Number1.Size = new System.Drawing.Size(122, 33);
            this.lb_Number1.TabIndex = 3;
            this.lb_Number1.Text = "0";
            this.lb_Number1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_FixtureCode1
            // 
            this.lb_FixtureCode1.AutoSize = true;
            this.lb_FixtureCode1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_FixtureCode1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_FixtureCode1.Location = new System.Drawing.Point(3, 33);
            this.lb_FixtureCode1.Name = "lb_FixtureCode1";
            this.lb_FixtureCode1.Size = new System.Drawing.Size(255, 33);
            this.lb_FixtureCode1.TabIndex = 2;
            this.lb_FixtureCode1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label56.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label56.Location = new System.Drawing.Point(264, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(122, 33);
            this.label56.TabIndex = 1;
            this.label56.Text = "次数";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label55.Location = new System.Drawing.Point(3, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(255, 33);
            this.label55.TabIndex = 0;
            this.label55.Text = "治具码";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tabControl2);
            this.tabPage2.Location = new System.Drawing.Point(124, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(733, 492);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "时间统计";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.tabControl2.Location = new System.Drawing.Point(3, 3);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(727, 486);
            this.tabControl2.TabIndex = 2;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.tableLayoutPanel4);
            this.tabPage5.Location = new System.Drawing.Point(4, 30);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(719, 452);
            this.tabPage5.TabIndex = 1;
            this.tabPage5.Text = "图形显示";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel5, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.chart_DT, 0, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.05307F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88.94694F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(719, 452);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 4;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34F));
            this.tableLayoutPanel5.Controls.Add(this.dtp_DT_Table, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.btn_SelectDTTable, 2, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(713, 43);
            this.tableLayoutPanel5.TabIndex = 1;
            // 
            // dtp_DT_Table
            // 
            this.dtp_DT_Table.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dtp_DT_Table.CalendarFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.dtp_DT_Table.CustomFormat = "yyyy年MM月dd日";
            this.dtp_DT_Table.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.dtp_DT_Table.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_DT_Table.Location = new System.Drawing.Point(242, 7);
            this.dtp_DT_Table.Margin = new System.Windows.Forms.Padding(0);
            this.dtp_DT_Table.Name = "dtp_DT_Table";
            this.dtp_DT_Table.Size = new System.Drawing.Size(156, 29);
            this.dtp_DT_Table.TabIndex = 16;
            // 
            // btn_SelectDTTable
            // 
            this.btn_SelectDTTable.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_SelectDTTable.Location = new System.Drawing.Point(401, 3);
            this.btn_SelectDTTable.Name = "btn_SelectDTTable";
            this.btn_SelectDTTable.Size = new System.Drawing.Size(65, 37);
            this.btn_SelectDTTable.TabIndex = 17;
            this.btn_SelectDTTable.Text = "查询";
            this.btn_SelectDTTable.UseVisualStyleBackColor = true;
            this.btn_SelectDTTable.Click += new System.EventHandler(this.btn_SelectDTTable_Click);
            // 
            // chart_DT
            // 
            chartArea2.AxisX.Interval = 1D;
            chartArea2.AxisX.IntervalAutoMode = System.Windows.Forms.DataVisualization.Charting.IntervalAutoMode.VariableCount;
            chartArea2.Name = "ChartArea1";
            this.chart_DT.ChartAreas.Add(chartArea2);
            this.chart_DT.Dock = System.Windows.Forms.DockStyle.Fill;
            legend1.Name = "Legend1";
            this.chart_DT.Legends.Add(legend1);
            this.chart_DT.Location = new System.Drawing.Point(3, 52);
            this.chart_DT.Name = "chart_DT";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            series3.ChartArea = "ChartArea1";
            series3.Legend = "Legend1";
            series3.Name = "Series2";
            series4.ChartArea = "ChartArea1";
            series4.Legend = "Legend1";
            series4.Name = "Series3";
            this.chart_DT.Series.Add(series2);
            this.chart_DT.Series.Add(series3);
            this.chart_DT.Series.Add(series4);
            this.chart_DT.Size = new System.Drawing.Size(713, 397);
            this.chart_DT.TabIndex = 2;
            this.chart_DT.Text = "chart1";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.tableLayoutPanel1);
            this.tabPage4.Location = new System.Drawing.Point(4, 30);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(719, 452);
            this.tabPage4.TabIndex = 0;
            this.tabPage4.Text = "列表显示";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88.88889F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(719, 452);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34F));
            this.tableLayoutPanel2.Controls.Add(this.dtp_DT_Data, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.btn_SelectDTData, 2, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(713, 44);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // dtp_DT_Data
            // 
            this.dtp_DT_Data.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dtp_DT_Data.CalendarFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.dtp_DT_Data.CustomFormat = "yyyy年MM月dd日";
            this.dtp_DT_Data.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.dtp_DT_Data.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_DT_Data.Location = new System.Drawing.Point(242, 7);
            this.dtp_DT_Data.Margin = new System.Windows.Forms.Padding(0);
            this.dtp_DT_Data.Name = "dtp_DT_Data";
            this.dtp_DT_Data.Size = new System.Drawing.Size(156, 29);
            this.dtp_DT_Data.TabIndex = 16;
            this.dtp_DT_Data.ValueChanged += new System.EventHandler(this.dtp_DT_Data_ValueChanged);
            // 
            // btn_SelectDTData
            // 
            this.btn_SelectDTData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_SelectDTData.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.btn_SelectDTData.Location = new System.Drawing.Point(401, 3);
            this.btn_SelectDTData.Name = "btn_SelectDTData";
            this.btn_SelectDTData.Size = new System.Drawing.Size(65, 38);
            this.btn_SelectDTData.TabIndex = 17;
            this.btn_SelectDTData.Text = "查询";
            this.btn_SelectDTData.UseVisualStyleBackColor = true;
            this.btn_SelectDTData.Click += new System.EventHandler(this.btn_SelectDTData_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 79.66339F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.33661F));
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel15, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.groupBox1, 1, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 53);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(713, 396);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.ColumnCount = 11;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 0.4892958F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.10688F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.116159F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.116159F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.116159F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 2.110688F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.10688F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.116159F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.116159F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.116159F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 0.4892958F));
            this.tableLayoutPanel15.Controls.Add(this.label114, 1, 14);
            this.tableLayoutPanel15.Controls.Add(this.lb_Product_time, 2, 14);
            this.tableLayoutPanel15.Controls.Add(this.label106, 1, 13);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_08_20, 2, 13);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_08_20, 3, 13);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_08_20, 4, 13);
            this.tableLayoutPanel15.Controls.Add(this.label110, 6, 13);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_20_08, 7, 13);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_20_08, 8, 13);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_20_08, 9, 13);
            this.tableLayoutPanel15.Controls.Add(this.label98, 1, 12);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_19_20, 2, 12);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_19_20, 3, 12);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_19_20, 4, 12);
            this.tableLayoutPanel15.Controls.Add(this.label102, 6, 12);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_07_08, 7, 12);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_07_08, 8, 12);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_07_08, 9, 12);
            this.tableLayoutPanel15.Controls.Add(this.label90, 1, 11);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_18_19, 2, 11);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_18_19, 3, 11);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_18_19, 4, 11);
            this.tableLayoutPanel15.Controls.Add(this.label94, 6, 11);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_06_07, 7, 11);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_06_07, 8, 11);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_06_07, 9, 11);
            this.tableLayoutPanel15.Controls.Add(this.label82, 1, 10);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_17_18, 2, 10);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_17_18, 3, 10);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_17_18, 4, 10);
            this.tableLayoutPanel15.Controls.Add(this.label86, 6, 10);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_05_06, 7, 10);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_05_06, 8, 10);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_05_06, 9, 10);
            this.tableLayoutPanel15.Controls.Add(this.label74, 1, 9);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_16_17, 2, 9);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_16_17, 3, 9);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_16_17, 4, 9);
            this.tableLayoutPanel15.Controls.Add(this.label78, 6, 9);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_04_05, 7, 9);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_04_05, 8, 9);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_04_05, 9, 9);
            this.tableLayoutPanel15.Controls.Add(this.label66, 1, 8);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_15_16, 2, 8);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_15_16, 3, 8);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_15_16, 4, 8);
            this.tableLayoutPanel15.Controls.Add(this.label70, 6, 8);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_03_04, 7, 8);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_03_04, 8, 8);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_03_04, 9, 8);
            this.tableLayoutPanel15.Controls.Add(this.label58, 1, 7);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_14_15, 2, 7);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_14_15, 3, 7);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_14_15, 4, 7);
            this.tableLayoutPanel15.Controls.Add(this.label62, 6, 7);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_02_03, 7, 7);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_02_03, 8, 7);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_02_03, 9, 7);
            this.tableLayoutPanel15.Controls.Add(this.label50, 1, 6);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_13_14, 2, 6);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_13_14, 3, 6);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_13_14, 4, 6);
            this.tableLayoutPanel15.Controls.Add(this.label54, 6, 6);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_01_02, 7, 6);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_01_02, 8, 6);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_01_02, 9, 6);
            this.tableLayoutPanel15.Controls.Add(this.label47, 1, 5);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_12_13, 2, 5);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_12_13, 3, 5);
            this.tableLayoutPanel15.Controls.Add(this.label38, 1, 4);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_11_12, 2, 4);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_11_12, 3, 4);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_11_12, 4, 4);
            this.tableLayoutPanel15.Controls.Add(this.label29, 1, 3);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_10_11, 2, 3);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_10_11, 3, 3);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_10_11, 4, 3);
            this.tableLayoutPanel15.Controls.Add(this.label20, 1, 2);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_09_10, 2, 2);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_09_10, 3, 2);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_09_10, 4, 2);
            this.tableLayoutPanel15.Controls.Add(this.label11, 1, 1);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_08_09, 2, 1);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_08_09, 3, 1);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_08_09, 4, 1);
            this.tableLayoutPanel15.Controls.Add(this.label5, 4, 0);
            this.tableLayoutPanel15.Controls.Add(this.label4, 3, 0);
            this.tableLayoutPanel15.Controls.Add(this.label3, 2, 0);
            this.tableLayoutPanel15.Controls.Add(this.label2, 1, 0);
            this.tableLayoutPanel15.Controls.Add(this.label9, 9, 0);
            this.tableLayoutPanel15.Controls.Add(this.label8, 8, 0);
            this.tableLayoutPanel15.Controls.Add(this.label7, 7, 0);
            this.tableLayoutPanel15.Controls.Add(this.label6, 6, 0);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_20_21, 9, 1);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_20_21, 8, 1);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_20_21, 7, 1);
            this.tableLayoutPanel15.Controls.Add(this.label10, 6, 1);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_21_22, 9, 2);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_21_22, 8, 2);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_21_22, 7, 2);
            this.tableLayoutPanel15.Controls.Add(this.label18, 6, 2);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_22_23, 9, 3);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_22_23, 8, 3);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_22_23, 7, 3);
            this.tableLayoutPanel15.Controls.Add(this.label26, 6, 3);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_23_00, 9, 4);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_23_00, 7, 4);
            this.tableLayoutPanel15.Controls.Add(this.label34, 6, 4);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_00_01, 9, 5);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_00_01, 8, 5);
            this.tableLayoutPanel15.Controls.Add(this.lb_ErrorTime_23_00, 8, 4);
            this.tableLayoutPanel15.Controls.Add(this.lb_RunTime_00_01, 7, 5);
            this.tableLayoutPanel15.Controls.Add(this.label43, 6, 5);
            this.tableLayoutPanel15.Controls.Add(this.lb_PendingTime_12_13, 4, 5);
            this.tableLayoutPanel15.Controls.Add(this.label12, 6, 14);
            this.tableLayoutPanel15.Controls.Add(this.lb_Product_time_N1, 7, 14);
            this.tableLayoutPanel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel15.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.tableLayoutPanel15.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 15;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(561, 390);
            this.tableLayoutPanel15.TabIndex = 3;
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label114.Location = new System.Drawing.Point(5, 364);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(112, 26);
            this.label114.TabIndex = 118;
            this.label114.Text = "时间稼动";
            this.label114.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_time
            // 
            this.lb_Product_time.AutoSize = true;
            this.lb_Product_time.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_time.Location = new System.Drawing.Point(123, 364);
            this.lb_Product_time.Name = "lb_Product_time";
            this.lb_Product_time.Size = new System.Drawing.Size(45, 26);
            this.lb_Product_time.TabIndex = 117;
            this.lb_Product_time.Text = "0.0％";
            this.lb_Product_time.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label106.Location = new System.Drawing.Point(5, 338);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(112, 26);
            this.label106.TabIndex = 110;
            this.label106.Text = "合计";
            this.label106.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_08_20
            // 
            this.lb_RunTime_08_20.AutoSize = true;
            this.lb_RunTime_08_20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_08_20.Location = new System.Drawing.Point(123, 338);
            this.lb_RunTime_08_20.Name = "lb_RunTime_08_20";
            this.lb_RunTime_08_20.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_08_20.TabIndex = 109;
            this.lb_RunTime_08_20.Text = "0";
            this.lb_RunTime_08_20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_08_20
            // 
            this.lb_ErrorTime_08_20.AutoSize = true;
            this.lb_ErrorTime_08_20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_08_20.Location = new System.Drawing.Point(174, 338);
            this.lb_ErrorTime_08_20.Name = "lb_ErrorTime_08_20";
            this.lb_ErrorTime_08_20.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_08_20.TabIndex = 108;
            this.lb_ErrorTime_08_20.Text = "0";
            this.lb_ErrorTime_08_20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_08_20
            // 
            this.lb_PendingTime_08_20.AutoSize = true;
            this.lb_PendingTime_08_20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_08_20.Location = new System.Drawing.Point(225, 338);
            this.lb_PendingTime_08_20.Name = "lb_PendingTime_08_20";
            this.lb_PendingTime_08_20.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_08_20.TabIndex = 111;
            this.lb_PendingTime_08_20.Text = "0";
            this.lb_PendingTime_08_20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label110.Location = new System.Drawing.Point(287, 338);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(112, 26);
            this.label110.TabIndex = 104;
            this.label110.Text = "合计";
            this.label110.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_20_08
            // 
            this.lb_RunTime_20_08.AutoSize = true;
            this.lb_RunTime_20_08.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_20_08.Location = new System.Drawing.Point(405, 338);
            this.lb_RunTime_20_08.Name = "lb_RunTime_20_08";
            this.lb_RunTime_20_08.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_20_08.TabIndex = 105;
            this.lb_RunTime_20_08.Text = "0";
            this.lb_RunTime_20_08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_20_08
            // 
            this.lb_ErrorTime_20_08.AutoSize = true;
            this.lb_ErrorTime_20_08.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_20_08.Location = new System.Drawing.Point(456, 338);
            this.lb_ErrorTime_20_08.Name = "lb_ErrorTime_20_08";
            this.lb_ErrorTime_20_08.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_20_08.TabIndex = 106;
            this.lb_ErrorTime_20_08.Text = "0";
            this.lb_ErrorTime_20_08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_20_08
            // 
            this.lb_PendingTime_20_08.AutoSize = true;
            this.lb_PendingTime_20_08.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_20_08.Location = new System.Drawing.Point(507, 338);
            this.lb_PendingTime_20_08.Name = "lb_PendingTime_20_08";
            this.lb_PendingTime_20_08.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_20_08.TabIndex = 107;
            this.lb_PendingTime_20_08.Text = "0";
            this.lb_PendingTime_20_08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label98.Location = new System.Drawing.Point(5, 312);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(112, 26);
            this.label98.TabIndex = 102;
            this.label98.Text = "17:00-18:00";
            this.label98.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_19_20
            // 
            this.lb_RunTime_19_20.AutoSize = true;
            this.lb_RunTime_19_20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_19_20.Location = new System.Drawing.Point(123, 312);
            this.lb_RunTime_19_20.Name = "lb_RunTime_19_20";
            this.lb_RunTime_19_20.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_19_20.TabIndex = 101;
            this.lb_RunTime_19_20.Text = "0";
            this.lb_RunTime_19_20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_19_20
            // 
            this.lb_ErrorTime_19_20.AutoSize = true;
            this.lb_ErrorTime_19_20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_19_20.Location = new System.Drawing.Point(174, 312);
            this.lb_ErrorTime_19_20.Name = "lb_ErrorTime_19_20";
            this.lb_ErrorTime_19_20.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_19_20.TabIndex = 100;
            this.lb_ErrorTime_19_20.Text = "0";
            this.lb_ErrorTime_19_20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_19_20
            // 
            this.lb_PendingTime_19_20.AutoSize = true;
            this.lb_PendingTime_19_20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_19_20.Location = new System.Drawing.Point(225, 312);
            this.lb_PendingTime_19_20.Name = "lb_PendingTime_19_20";
            this.lb_PendingTime_19_20.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_19_20.TabIndex = 103;
            this.lb_PendingTime_19_20.Text = "0";
            this.lb_PendingTime_19_20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label102.Location = new System.Drawing.Point(287, 312);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(112, 26);
            this.label102.TabIndex = 96;
            this.label102.Text = "05:00-06:00";
            this.label102.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_07_08
            // 
            this.lb_RunTime_07_08.AutoSize = true;
            this.lb_RunTime_07_08.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_07_08.Location = new System.Drawing.Point(405, 312);
            this.lb_RunTime_07_08.Name = "lb_RunTime_07_08";
            this.lb_RunTime_07_08.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_07_08.TabIndex = 97;
            this.lb_RunTime_07_08.Text = "0";
            this.lb_RunTime_07_08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_07_08
            // 
            this.lb_ErrorTime_07_08.AutoSize = true;
            this.lb_ErrorTime_07_08.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_07_08.Location = new System.Drawing.Point(456, 312);
            this.lb_ErrorTime_07_08.Name = "lb_ErrorTime_07_08";
            this.lb_ErrorTime_07_08.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_07_08.TabIndex = 98;
            this.lb_ErrorTime_07_08.Text = "0";
            this.lb_ErrorTime_07_08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_07_08
            // 
            this.lb_PendingTime_07_08.AutoSize = true;
            this.lb_PendingTime_07_08.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_07_08.Location = new System.Drawing.Point(507, 312);
            this.lb_PendingTime_07_08.Name = "lb_PendingTime_07_08";
            this.lb_PendingTime_07_08.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_07_08.TabIndex = 99;
            this.lb_PendingTime_07_08.Text = "0";
            this.lb_PendingTime_07_08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label90.Location = new System.Drawing.Point(5, 286);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(112, 26);
            this.label90.TabIndex = 94;
            this.label90.Text = "16:00-17:00";
            this.label90.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_18_19
            // 
            this.lb_RunTime_18_19.AutoSize = true;
            this.lb_RunTime_18_19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_18_19.Location = new System.Drawing.Point(123, 286);
            this.lb_RunTime_18_19.Name = "lb_RunTime_18_19";
            this.lb_RunTime_18_19.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_18_19.TabIndex = 93;
            this.lb_RunTime_18_19.Text = "0";
            this.lb_RunTime_18_19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_18_19
            // 
            this.lb_ErrorTime_18_19.AutoSize = true;
            this.lb_ErrorTime_18_19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_18_19.Location = new System.Drawing.Point(174, 286);
            this.lb_ErrorTime_18_19.Name = "lb_ErrorTime_18_19";
            this.lb_ErrorTime_18_19.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_18_19.TabIndex = 92;
            this.lb_ErrorTime_18_19.Text = "0";
            this.lb_ErrorTime_18_19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_18_19
            // 
            this.lb_PendingTime_18_19.AutoSize = true;
            this.lb_PendingTime_18_19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_18_19.Location = new System.Drawing.Point(225, 286);
            this.lb_PendingTime_18_19.Name = "lb_PendingTime_18_19";
            this.lb_PendingTime_18_19.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_18_19.TabIndex = 95;
            this.lb_PendingTime_18_19.Text = "0";
            this.lb_PendingTime_18_19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label94.Location = new System.Drawing.Point(287, 286);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(112, 26);
            this.label94.TabIndex = 88;
            this.label94.Text = "04:00-05:00";
            this.label94.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_06_07
            // 
            this.lb_RunTime_06_07.AutoSize = true;
            this.lb_RunTime_06_07.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_06_07.Location = new System.Drawing.Point(405, 286);
            this.lb_RunTime_06_07.Name = "lb_RunTime_06_07";
            this.lb_RunTime_06_07.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_06_07.TabIndex = 89;
            this.lb_RunTime_06_07.Text = "0";
            this.lb_RunTime_06_07.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_06_07
            // 
            this.lb_ErrorTime_06_07.AutoSize = true;
            this.lb_ErrorTime_06_07.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_06_07.Location = new System.Drawing.Point(456, 286);
            this.lb_ErrorTime_06_07.Name = "lb_ErrorTime_06_07";
            this.lb_ErrorTime_06_07.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_06_07.TabIndex = 90;
            this.lb_ErrorTime_06_07.Text = "0";
            this.lb_ErrorTime_06_07.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_06_07
            // 
            this.lb_PendingTime_06_07.AutoSize = true;
            this.lb_PendingTime_06_07.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_06_07.Location = new System.Drawing.Point(507, 286);
            this.lb_PendingTime_06_07.Name = "lb_PendingTime_06_07";
            this.lb_PendingTime_06_07.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_06_07.TabIndex = 91;
            this.lb_PendingTime_06_07.Text = "0";
            this.lb_PendingTime_06_07.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label82.Location = new System.Drawing.Point(5, 260);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(112, 26);
            this.label82.TabIndex = 86;
            this.label82.Text = "15:00-16:00";
            this.label82.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_17_18
            // 
            this.lb_RunTime_17_18.AutoSize = true;
            this.lb_RunTime_17_18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_17_18.Location = new System.Drawing.Point(123, 260);
            this.lb_RunTime_17_18.Name = "lb_RunTime_17_18";
            this.lb_RunTime_17_18.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_17_18.TabIndex = 85;
            this.lb_RunTime_17_18.Text = "0";
            this.lb_RunTime_17_18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_17_18
            // 
            this.lb_ErrorTime_17_18.AutoSize = true;
            this.lb_ErrorTime_17_18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_17_18.Location = new System.Drawing.Point(174, 260);
            this.lb_ErrorTime_17_18.Name = "lb_ErrorTime_17_18";
            this.lb_ErrorTime_17_18.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_17_18.TabIndex = 84;
            this.lb_ErrorTime_17_18.Text = "0";
            this.lb_ErrorTime_17_18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_17_18
            // 
            this.lb_PendingTime_17_18.AutoSize = true;
            this.lb_PendingTime_17_18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_17_18.Location = new System.Drawing.Point(225, 260);
            this.lb_PendingTime_17_18.Name = "lb_PendingTime_17_18";
            this.lb_PendingTime_17_18.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_17_18.TabIndex = 87;
            this.lb_PendingTime_17_18.Text = "0";
            this.lb_PendingTime_17_18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label86.Location = new System.Drawing.Point(287, 260);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(112, 26);
            this.label86.TabIndex = 80;
            this.label86.Text = "03:00-04:00";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_05_06
            // 
            this.lb_RunTime_05_06.AutoSize = true;
            this.lb_RunTime_05_06.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_05_06.Location = new System.Drawing.Point(405, 260);
            this.lb_RunTime_05_06.Name = "lb_RunTime_05_06";
            this.lb_RunTime_05_06.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_05_06.TabIndex = 81;
            this.lb_RunTime_05_06.Text = "0";
            this.lb_RunTime_05_06.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_05_06
            // 
            this.lb_ErrorTime_05_06.AutoSize = true;
            this.lb_ErrorTime_05_06.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_05_06.Location = new System.Drawing.Point(456, 260);
            this.lb_ErrorTime_05_06.Name = "lb_ErrorTime_05_06";
            this.lb_ErrorTime_05_06.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_05_06.TabIndex = 82;
            this.lb_ErrorTime_05_06.Text = "0";
            this.lb_ErrorTime_05_06.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_05_06
            // 
            this.lb_PendingTime_05_06.AutoSize = true;
            this.lb_PendingTime_05_06.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_05_06.Location = new System.Drawing.Point(507, 260);
            this.lb_PendingTime_05_06.Name = "lb_PendingTime_05_06";
            this.lb_PendingTime_05_06.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_05_06.TabIndex = 83;
            this.lb_PendingTime_05_06.Text = "0";
            this.lb_PendingTime_05_06.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label74.Location = new System.Drawing.Point(5, 234);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(112, 26);
            this.label74.TabIndex = 78;
            this.label74.Text = "14:00-15:00";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_16_17
            // 
            this.lb_RunTime_16_17.AutoSize = true;
            this.lb_RunTime_16_17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_16_17.Location = new System.Drawing.Point(123, 234);
            this.lb_RunTime_16_17.Name = "lb_RunTime_16_17";
            this.lb_RunTime_16_17.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_16_17.TabIndex = 77;
            this.lb_RunTime_16_17.Text = "0";
            this.lb_RunTime_16_17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_16_17
            // 
            this.lb_ErrorTime_16_17.AutoSize = true;
            this.lb_ErrorTime_16_17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_16_17.Location = new System.Drawing.Point(174, 234);
            this.lb_ErrorTime_16_17.Name = "lb_ErrorTime_16_17";
            this.lb_ErrorTime_16_17.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_16_17.TabIndex = 76;
            this.lb_ErrorTime_16_17.Text = "0";
            this.lb_ErrorTime_16_17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_16_17
            // 
            this.lb_PendingTime_16_17.AutoSize = true;
            this.lb_PendingTime_16_17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_16_17.Location = new System.Drawing.Point(225, 234);
            this.lb_PendingTime_16_17.Name = "lb_PendingTime_16_17";
            this.lb_PendingTime_16_17.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_16_17.TabIndex = 79;
            this.lb_PendingTime_16_17.Text = "0";
            this.lb_PendingTime_16_17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label78.Location = new System.Drawing.Point(287, 234);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(112, 26);
            this.label78.TabIndex = 72;
            this.label78.Text = "02:00-03:00";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_04_05
            // 
            this.lb_RunTime_04_05.AutoSize = true;
            this.lb_RunTime_04_05.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_04_05.Location = new System.Drawing.Point(405, 234);
            this.lb_RunTime_04_05.Name = "lb_RunTime_04_05";
            this.lb_RunTime_04_05.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_04_05.TabIndex = 73;
            this.lb_RunTime_04_05.Text = "0";
            this.lb_RunTime_04_05.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_04_05
            // 
            this.lb_ErrorTime_04_05.AutoSize = true;
            this.lb_ErrorTime_04_05.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_04_05.Location = new System.Drawing.Point(456, 234);
            this.lb_ErrorTime_04_05.Name = "lb_ErrorTime_04_05";
            this.lb_ErrorTime_04_05.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_04_05.TabIndex = 74;
            this.lb_ErrorTime_04_05.Text = "0";
            this.lb_ErrorTime_04_05.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_04_05
            // 
            this.lb_PendingTime_04_05.AutoSize = true;
            this.lb_PendingTime_04_05.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_04_05.Location = new System.Drawing.Point(507, 234);
            this.lb_PendingTime_04_05.Name = "lb_PendingTime_04_05";
            this.lb_PendingTime_04_05.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_04_05.TabIndex = 75;
            this.lb_PendingTime_04_05.Text = "0";
            this.lb_PendingTime_04_05.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label66.Location = new System.Drawing.Point(5, 208);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(112, 26);
            this.label66.TabIndex = 70;
            this.label66.Text = "13:00-14:00";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_15_16
            // 
            this.lb_RunTime_15_16.AutoSize = true;
            this.lb_RunTime_15_16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_15_16.Location = new System.Drawing.Point(123, 208);
            this.lb_RunTime_15_16.Name = "lb_RunTime_15_16";
            this.lb_RunTime_15_16.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_15_16.TabIndex = 69;
            this.lb_RunTime_15_16.Text = "0";
            this.lb_RunTime_15_16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_15_16
            // 
            this.lb_ErrorTime_15_16.AutoSize = true;
            this.lb_ErrorTime_15_16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_15_16.Location = new System.Drawing.Point(174, 208);
            this.lb_ErrorTime_15_16.Name = "lb_ErrorTime_15_16";
            this.lb_ErrorTime_15_16.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_15_16.TabIndex = 68;
            this.lb_ErrorTime_15_16.Text = "0";
            this.lb_ErrorTime_15_16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_15_16
            // 
            this.lb_PendingTime_15_16.AutoSize = true;
            this.lb_PendingTime_15_16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_15_16.Location = new System.Drawing.Point(225, 208);
            this.lb_PendingTime_15_16.Name = "lb_PendingTime_15_16";
            this.lb_PendingTime_15_16.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_15_16.TabIndex = 71;
            this.lb_PendingTime_15_16.Text = "0";
            this.lb_PendingTime_15_16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label70.Location = new System.Drawing.Point(287, 208);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(112, 26);
            this.label70.TabIndex = 64;
            this.label70.Text = "01:00-02:00";
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_03_04
            // 
            this.lb_RunTime_03_04.AutoSize = true;
            this.lb_RunTime_03_04.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_03_04.Location = new System.Drawing.Point(405, 208);
            this.lb_RunTime_03_04.Name = "lb_RunTime_03_04";
            this.lb_RunTime_03_04.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_03_04.TabIndex = 65;
            this.lb_RunTime_03_04.Text = "0";
            this.lb_RunTime_03_04.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_03_04
            // 
            this.lb_ErrorTime_03_04.AutoSize = true;
            this.lb_ErrorTime_03_04.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_03_04.Location = new System.Drawing.Point(456, 208);
            this.lb_ErrorTime_03_04.Name = "lb_ErrorTime_03_04";
            this.lb_ErrorTime_03_04.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_03_04.TabIndex = 66;
            this.lb_ErrorTime_03_04.Text = "0";
            this.lb_ErrorTime_03_04.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_03_04
            // 
            this.lb_PendingTime_03_04.AutoSize = true;
            this.lb_PendingTime_03_04.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_03_04.Location = new System.Drawing.Point(507, 208);
            this.lb_PendingTime_03_04.Name = "lb_PendingTime_03_04";
            this.lb_PendingTime_03_04.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_03_04.TabIndex = 67;
            this.lb_PendingTime_03_04.Text = "0";
            this.lb_PendingTime_03_04.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label58.Location = new System.Drawing.Point(5, 182);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(112, 26);
            this.label58.TabIndex = 62;
            this.label58.Text = "12:00-13:00";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_14_15
            // 
            this.lb_RunTime_14_15.AutoSize = true;
            this.lb_RunTime_14_15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_14_15.Location = new System.Drawing.Point(123, 182);
            this.lb_RunTime_14_15.Name = "lb_RunTime_14_15";
            this.lb_RunTime_14_15.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_14_15.TabIndex = 61;
            this.lb_RunTime_14_15.Text = "0";
            this.lb_RunTime_14_15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_14_15
            // 
            this.lb_ErrorTime_14_15.AutoSize = true;
            this.lb_ErrorTime_14_15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_14_15.Location = new System.Drawing.Point(174, 182);
            this.lb_ErrorTime_14_15.Name = "lb_ErrorTime_14_15";
            this.lb_ErrorTime_14_15.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_14_15.TabIndex = 60;
            this.lb_ErrorTime_14_15.Text = "0";
            this.lb_ErrorTime_14_15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_14_15
            // 
            this.lb_PendingTime_14_15.AutoSize = true;
            this.lb_PendingTime_14_15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_14_15.Location = new System.Drawing.Point(225, 182);
            this.lb_PendingTime_14_15.Name = "lb_PendingTime_14_15";
            this.lb_PendingTime_14_15.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_14_15.TabIndex = 63;
            this.lb_PendingTime_14_15.Text = "0";
            this.lb_PendingTime_14_15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label62.Location = new System.Drawing.Point(287, 182);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(112, 26);
            this.label62.TabIndex = 56;
            this.label62.Text = "00:00-01:00";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_02_03
            // 
            this.lb_RunTime_02_03.AutoSize = true;
            this.lb_RunTime_02_03.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_02_03.Location = new System.Drawing.Point(405, 182);
            this.lb_RunTime_02_03.Name = "lb_RunTime_02_03";
            this.lb_RunTime_02_03.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_02_03.TabIndex = 57;
            this.lb_RunTime_02_03.Text = "0";
            this.lb_RunTime_02_03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_02_03
            // 
            this.lb_ErrorTime_02_03.AutoSize = true;
            this.lb_ErrorTime_02_03.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_02_03.Location = new System.Drawing.Point(456, 182);
            this.lb_ErrorTime_02_03.Name = "lb_ErrorTime_02_03";
            this.lb_ErrorTime_02_03.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_02_03.TabIndex = 58;
            this.lb_ErrorTime_02_03.Text = "0";
            this.lb_ErrorTime_02_03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_02_03
            // 
            this.lb_PendingTime_02_03.AutoSize = true;
            this.lb_PendingTime_02_03.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_02_03.Location = new System.Drawing.Point(507, 182);
            this.lb_PendingTime_02_03.Name = "lb_PendingTime_02_03";
            this.lb_PendingTime_02_03.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_02_03.TabIndex = 59;
            this.lb_PendingTime_02_03.Text = "0";
            this.lb_PendingTime_02_03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label50.Location = new System.Drawing.Point(5, 156);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(112, 26);
            this.label50.TabIndex = 54;
            this.label50.Text = "11:00-12:00";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_13_14
            // 
            this.lb_RunTime_13_14.AutoSize = true;
            this.lb_RunTime_13_14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_13_14.Location = new System.Drawing.Point(123, 156);
            this.lb_RunTime_13_14.Name = "lb_RunTime_13_14";
            this.lb_RunTime_13_14.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_13_14.TabIndex = 53;
            this.lb_RunTime_13_14.Text = "0";
            this.lb_RunTime_13_14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_13_14
            // 
            this.lb_ErrorTime_13_14.AutoSize = true;
            this.lb_ErrorTime_13_14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_13_14.Location = new System.Drawing.Point(174, 156);
            this.lb_ErrorTime_13_14.Name = "lb_ErrorTime_13_14";
            this.lb_ErrorTime_13_14.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_13_14.TabIndex = 52;
            this.lb_ErrorTime_13_14.Text = "0";
            this.lb_ErrorTime_13_14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_13_14
            // 
            this.lb_PendingTime_13_14.AutoSize = true;
            this.lb_PendingTime_13_14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_13_14.Location = new System.Drawing.Point(225, 156);
            this.lb_PendingTime_13_14.Name = "lb_PendingTime_13_14";
            this.lb_PendingTime_13_14.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_13_14.TabIndex = 55;
            this.lb_PendingTime_13_14.Text = "0";
            this.lb_PendingTime_13_14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label54.Location = new System.Drawing.Point(287, 156);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(112, 26);
            this.label54.TabIndex = 48;
            this.label54.Text = "23:00-00:00";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_01_02
            // 
            this.lb_RunTime_01_02.AutoSize = true;
            this.lb_RunTime_01_02.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_01_02.Location = new System.Drawing.Point(405, 156);
            this.lb_RunTime_01_02.Name = "lb_RunTime_01_02";
            this.lb_RunTime_01_02.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_01_02.TabIndex = 49;
            this.lb_RunTime_01_02.Text = "0";
            this.lb_RunTime_01_02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_01_02
            // 
            this.lb_ErrorTime_01_02.AutoSize = true;
            this.lb_ErrorTime_01_02.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_01_02.Location = new System.Drawing.Point(456, 156);
            this.lb_ErrorTime_01_02.Name = "lb_ErrorTime_01_02";
            this.lb_ErrorTime_01_02.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_01_02.TabIndex = 50;
            this.lb_ErrorTime_01_02.Text = "0";
            this.lb_ErrorTime_01_02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_01_02
            // 
            this.lb_PendingTime_01_02.AutoSize = true;
            this.lb_PendingTime_01_02.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_01_02.Location = new System.Drawing.Point(507, 156);
            this.lb_PendingTime_01_02.Name = "lb_PendingTime_01_02";
            this.lb_PendingTime_01_02.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_01_02.TabIndex = 51;
            this.lb_PendingTime_01_02.Text = "0";
            this.lb_PendingTime_01_02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label47.Location = new System.Drawing.Point(5, 130);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(112, 26);
            this.label47.TabIndex = 46;
            this.label47.Text = "10:00-11:00";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_12_13
            // 
            this.lb_RunTime_12_13.AutoSize = true;
            this.lb_RunTime_12_13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_12_13.Location = new System.Drawing.Point(123, 130);
            this.lb_RunTime_12_13.Name = "lb_RunTime_12_13";
            this.lb_RunTime_12_13.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_12_13.TabIndex = 45;
            this.lb_RunTime_12_13.Text = "0";
            this.lb_RunTime_12_13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_12_13
            // 
            this.lb_ErrorTime_12_13.AutoSize = true;
            this.lb_ErrorTime_12_13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_12_13.Location = new System.Drawing.Point(174, 130);
            this.lb_ErrorTime_12_13.Name = "lb_ErrorTime_12_13";
            this.lb_ErrorTime_12_13.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_12_13.TabIndex = 44;
            this.lb_ErrorTime_12_13.Text = "0";
            this.lb_ErrorTime_12_13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label38.Location = new System.Drawing.Point(5, 104);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(112, 26);
            this.label38.TabIndex = 39;
            this.label38.Text = "09:00-10:00";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_11_12
            // 
            this.lb_RunTime_11_12.AutoSize = true;
            this.lb_RunTime_11_12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_11_12.Location = new System.Drawing.Point(123, 104);
            this.lb_RunTime_11_12.Name = "lb_RunTime_11_12";
            this.lb_RunTime_11_12.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_11_12.TabIndex = 38;
            this.lb_RunTime_11_12.Text = "0";
            this.lb_RunTime_11_12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_11_12
            // 
            this.lb_ErrorTime_11_12.AutoSize = true;
            this.lb_ErrorTime_11_12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_11_12.Location = new System.Drawing.Point(174, 104);
            this.lb_ErrorTime_11_12.Name = "lb_ErrorTime_11_12";
            this.lb_ErrorTime_11_12.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_11_12.TabIndex = 37;
            this.lb_ErrorTime_11_12.Text = "0";
            this.lb_ErrorTime_11_12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_11_12
            // 
            this.lb_PendingTime_11_12.AutoSize = true;
            this.lb_PendingTime_11_12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_11_12.Location = new System.Drawing.Point(225, 104);
            this.lb_PendingTime_11_12.Name = "lb_PendingTime_11_12";
            this.lb_PendingTime_11_12.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_11_12.TabIndex = 36;
            this.lb_PendingTime_11_12.Text = "0";
            this.lb_PendingTime_11_12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label29.Location = new System.Drawing.Point(5, 78);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(112, 26);
            this.label29.TabIndex = 24;
            this.label29.Text = "08:00-09:00";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_10_11
            // 
            this.lb_RunTime_10_11.AutoSize = true;
            this.lb_RunTime_10_11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_10_11.Location = new System.Drawing.Point(123, 78);
            this.lb_RunTime_10_11.Name = "lb_RunTime_10_11";
            this.lb_RunTime_10_11.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_10_11.TabIndex = 31;
            this.lb_RunTime_10_11.Text = "0";
            this.lb_RunTime_10_11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_10_11
            // 
            this.lb_ErrorTime_10_11.AutoSize = true;
            this.lb_ErrorTime_10_11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_10_11.Location = new System.Drawing.Point(174, 78);
            this.lb_ErrorTime_10_11.Name = "lb_ErrorTime_10_11";
            this.lb_ErrorTime_10_11.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_10_11.TabIndex = 30;
            this.lb_ErrorTime_10_11.Text = "0";
            this.lb_ErrorTime_10_11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_10_11
            // 
            this.lb_PendingTime_10_11.AutoSize = true;
            this.lb_PendingTime_10_11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_10_11.Location = new System.Drawing.Point(225, 78);
            this.lb_PendingTime_10_11.Name = "lb_PendingTime_10_11";
            this.lb_PendingTime_10_11.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_10_11.TabIndex = 29;
            this.lb_PendingTime_10_11.Text = "0";
            this.lb_PendingTime_10_11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Location = new System.Drawing.Point(5, 52);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(112, 26);
            this.label20.TabIndex = 17;
            this.label20.Text = "07:00-08:00";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_09_10
            // 
            this.lb_RunTime_09_10.AutoSize = true;
            this.lb_RunTime_09_10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_09_10.Location = new System.Drawing.Point(123, 52);
            this.lb_RunTime_09_10.Name = "lb_RunTime_09_10";
            this.lb_RunTime_09_10.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_09_10.TabIndex = 16;
            this.lb_RunTime_09_10.Text = "0";
            this.lb_RunTime_09_10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_09_10
            // 
            this.lb_ErrorTime_09_10.AutoSize = true;
            this.lb_ErrorTime_09_10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_09_10.Location = new System.Drawing.Point(174, 52);
            this.lb_ErrorTime_09_10.Name = "lb_ErrorTime_09_10";
            this.lb_ErrorTime_09_10.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_09_10.TabIndex = 23;
            this.lb_ErrorTime_09_10.Text = "0";
            this.lb_ErrorTime_09_10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_09_10
            // 
            this.lb_PendingTime_09_10.AutoSize = true;
            this.lb_PendingTime_09_10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_09_10.Location = new System.Drawing.Point(225, 52);
            this.lb_PendingTime_09_10.Name = "lb_PendingTime_09_10";
            this.lb_PendingTime_09_10.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_09_10.TabIndex = 22;
            this.lb_PendingTime_09_10.Text = "0";
            this.lb_PendingTime_09_10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label11.Location = new System.Drawing.Point(5, 26);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(112, 26);
            this.label11.TabIndex = 10;
            this.label11.Text = "06:00-07:00";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_08_09
            // 
            this.lb_RunTime_08_09.AutoSize = true;
            this.lb_RunTime_08_09.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_08_09.Location = new System.Drawing.Point(123, 26);
            this.lb_RunTime_08_09.Name = "lb_RunTime_08_09";
            this.lb_RunTime_08_09.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_08_09.TabIndex = 9;
            this.lb_RunTime_08_09.Text = "0";
            this.lb_RunTime_08_09.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_08_09
            // 
            this.lb_ErrorTime_08_09.AutoSize = true;
            this.lb_ErrorTime_08_09.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_08_09.Location = new System.Drawing.Point(174, 26);
            this.lb_ErrorTime_08_09.Name = "lb_ErrorTime_08_09";
            this.lb_ErrorTime_08_09.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_08_09.TabIndex = 8;
            this.lb_ErrorTime_08_09.Text = "0";
            this.lb_ErrorTime_08_09.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_08_09
            // 
            this.lb_PendingTime_08_09.AutoSize = true;
            this.lb_PendingTime_08_09.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_08_09.Location = new System.Drawing.Point(225, 26);
            this.lb_PendingTime_08_09.Name = "lb_PendingTime_08_09";
            this.lb_PendingTime_08_09.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_08_09.TabIndex = 15;
            this.lb_PendingTime_08_09.Text = "0";
            this.lb_PendingTime_08_09.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(225, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 26);
            this.label5.TabIndex = 3;
            this.label5.Text = "待机时间";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(174, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 26);
            this.label4.TabIndex = 2;
            this.label4.Text = "异常时间";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label3.Location = new System.Drawing.Point(123, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 26);
            this.label3.TabIndex = 1;
            this.label3.Text = "运行时间";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label2.Location = new System.Drawing.Point(5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 26);
            this.label2.TabIndex = 0;
            this.label2.Text = "时间段";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Location = new System.Drawing.Point(507, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 26);
            this.label9.TabIndex = 7;
            this.label9.Text = "待机时间";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label8.Location = new System.Drawing.Point(456, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 26);
            this.label8.TabIndex = 6;
            this.label8.Text = "异常时间";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Location = new System.Drawing.Point(405, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 26);
            this.label7.TabIndex = 5;
            this.label7.Text = "运行时间";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Location = new System.Drawing.Point(287, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 26);
            this.label6.TabIndex = 4;
            this.label6.Text = "时间段";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_20_21
            // 
            this.lb_PendingTime_20_21.AutoSize = true;
            this.lb_PendingTime_20_21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_20_21.Location = new System.Drawing.Point(507, 26);
            this.lb_PendingTime_20_21.Name = "lb_PendingTime_20_21";
            this.lb_PendingTime_20_21.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_20_21.TabIndex = 12;
            this.lb_PendingTime_20_21.Text = "0";
            this.lb_PendingTime_20_21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_20_21
            // 
            this.lb_ErrorTime_20_21.AutoSize = true;
            this.lb_ErrorTime_20_21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_20_21.Location = new System.Drawing.Point(456, 26);
            this.lb_ErrorTime_20_21.Name = "lb_ErrorTime_20_21";
            this.lb_ErrorTime_20_21.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_20_21.TabIndex = 13;
            this.lb_ErrorTime_20_21.Text = "0";
            this.lb_ErrorTime_20_21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_20_21
            // 
            this.lb_RunTime_20_21.AutoSize = true;
            this.lb_RunTime_20_21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_20_21.Location = new System.Drawing.Point(405, 26);
            this.lb_RunTime_20_21.Name = "lb_RunTime_20_21";
            this.lb_RunTime_20_21.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_20_21.TabIndex = 14;
            this.lb_RunTime_20_21.Text = "0";
            this.lb_RunTime_20_21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Location = new System.Drawing.Point(287, 26);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(112, 26);
            this.label10.TabIndex = 11;
            this.label10.Text = "18:00-19:00";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_21_22
            // 
            this.lb_PendingTime_21_22.AutoSize = true;
            this.lb_PendingTime_21_22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_21_22.Location = new System.Drawing.Point(507, 52);
            this.lb_PendingTime_21_22.Name = "lb_PendingTime_21_22";
            this.lb_PendingTime_21_22.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_21_22.TabIndex = 20;
            this.lb_PendingTime_21_22.Text = "0";
            this.lb_PendingTime_21_22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_21_22
            // 
            this.lb_ErrorTime_21_22.AutoSize = true;
            this.lb_ErrorTime_21_22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_21_22.Location = new System.Drawing.Point(456, 52);
            this.lb_ErrorTime_21_22.Name = "lb_ErrorTime_21_22";
            this.lb_ErrorTime_21_22.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_21_22.TabIndex = 21;
            this.lb_ErrorTime_21_22.Text = "0";
            this.lb_ErrorTime_21_22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_21_22
            // 
            this.lb_RunTime_21_22.AutoSize = true;
            this.lb_RunTime_21_22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_21_22.Location = new System.Drawing.Point(405, 52);
            this.lb_RunTime_21_22.Name = "lb_RunTime_21_22";
            this.lb_RunTime_21_22.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_21_22.TabIndex = 18;
            this.lb_RunTime_21_22.Text = "0";
            this.lb_RunTime_21_22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Location = new System.Drawing.Point(287, 52);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(112, 26);
            this.label18.TabIndex = 19;
            this.label18.Text = "19:00-20:00";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_22_23
            // 
            this.lb_PendingTime_22_23.AutoSize = true;
            this.lb_PendingTime_22_23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_22_23.Location = new System.Drawing.Point(507, 78);
            this.lb_PendingTime_22_23.Name = "lb_PendingTime_22_23";
            this.lb_PendingTime_22_23.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_22_23.TabIndex = 28;
            this.lb_PendingTime_22_23.Text = "0";
            this.lb_PendingTime_22_23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_22_23
            // 
            this.lb_ErrorTime_22_23.AutoSize = true;
            this.lb_ErrorTime_22_23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_22_23.Location = new System.Drawing.Point(456, 78);
            this.lb_ErrorTime_22_23.Name = "lb_ErrorTime_22_23";
            this.lb_ErrorTime_22_23.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_22_23.TabIndex = 25;
            this.lb_ErrorTime_22_23.Text = "0";
            this.lb_ErrorTime_22_23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_22_23
            // 
            this.lb_RunTime_22_23.AutoSize = true;
            this.lb_RunTime_22_23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_22_23.Location = new System.Drawing.Point(405, 78);
            this.lb_RunTime_22_23.Name = "lb_RunTime_22_23";
            this.lb_RunTime_22_23.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_22_23.TabIndex = 26;
            this.lb_RunTime_22_23.Text = "0";
            this.lb_RunTime_22_23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.Location = new System.Drawing.Point(287, 78);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(112, 26);
            this.label26.TabIndex = 27;
            this.label26.Text = "20:00-21:00";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_23_00
            // 
            this.lb_PendingTime_23_00.AutoSize = true;
            this.lb_PendingTime_23_00.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_23_00.Location = new System.Drawing.Point(507, 104);
            this.lb_PendingTime_23_00.Name = "lb_PendingTime_23_00";
            this.lb_PendingTime_23_00.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_23_00.TabIndex = 32;
            this.lb_PendingTime_23_00.Text = "0";
            this.lb_PendingTime_23_00.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_23_00
            // 
            this.lb_RunTime_23_00.AutoSize = true;
            this.lb_RunTime_23_00.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_23_00.Location = new System.Drawing.Point(405, 104);
            this.lb_RunTime_23_00.Name = "lb_RunTime_23_00";
            this.lb_RunTime_23_00.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_23_00.TabIndex = 34;
            this.lb_RunTime_23_00.Text = "0";
            this.lb_RunTime_23_00.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label34.Location = new System.Drawing.Point(287, 104);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(112, 26);
            this.label34.TabIndex = 35;
            this.label34.Text = "21:00-22:00";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_00_01
            // 
            this.lb_PendingTime_00_01.AutoSize = true;
            this.lb_PendingTime_00_01.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_00_01.Location = new System.Drawing.Point(507, 130);
            this.lb_PendingTime_00_01.Name = "lb_PendingTime_00_01";
            this.lb_PendingTime_00_01.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_00_01.TabIndex = 47;
            this.lb_PendingTime_00_01.Text = "0";
            this.lb_PendingTime_00_01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_00_01
            // 
            this.lb_ErrorTime_00_01.AutoSize = true;
            this.lb_ErrorTime_00_01.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_00_01.Location = new System.Drawing.Point(456, 130);
            this.lb_ErrorTime_00_01.Name = "lb_ErrorTime_00_01";
            this.lb_ErrorTime_00_01.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_00_01.TabIndex = 40;
            this.lb_ErrorTime_00_01.Text = "0";
            this.lb_ErrorTime_00_01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_ErrorTime_23_00
            // 
            this.lb_ErrorTime_23_00.AutoSize = true;
            this.lb_ErrorTime_23_00.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ErrorTime_23_00.Location = new System.Drawing.Point(456, 104);
            this.lb_ErrorTime_23_00.Name = "lb_ErrorTime_23_00";
            this.lb_ErrorTime_23_00.Size = new System.Drawing.Size(45, 26);
            this.lb_ErrorTime_23_00.TabIndex = 33;
            this.lb_ErrorTime_23_00.Text = "0";
            this.lb_ErrorTime_23_00.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_RunTime_00_01
            // 
            this.lb_RunTime_00_01.AutoSize = true;
            this.lb_RunTime_00_01.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_RunTime_00_01.Location = new System.Drawing.Point(405, 130);
            this.lb_RunTime_00_01.Name = "lb_RunTime_00_01";
            this.lb_RunTime_00_01.Size = new System.Drawing.Size(45, 26);
            this.lb_RunTime_00_01.TabIndex = 41;
            this.lb_RunTime_00_01.Text = "0";
            this.lb_RunTime_00_01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label43.Location = new System.Drawing.Point(287, 130);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(112, 26);
            this.label43.TabIndex = 42;
            this.label43.Text = "22:00-23:00";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PendingTime_12_13
            // 
            this.lb_PendingTime_12_13.AutoSize = true;
            this.lb_PendingTime_12_13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PendingTime_12_13.Location = new System.Drawing.Point(225, 130);
            this.lb_PendingTime_12_13.Name = "lb_PendingTime_12_13";
            this.lb_PendingTime_12_13.Size = new System.Drawing.Size(45, 26);
            this.lb_PendingTime_12_13.TabIndex = 43;
            this.lb_PendingTime_12_13.Text = "0";
            this.lb_PendingTime_12_13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Location = new System.Drawing.Point(287, 364);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(112, 26);
            this.label12.TabIndex = 119;
            this.label12.Text = "时间稼动";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_time_N1
            // 
            this.lb_Product_time_N1.AutoSize = true;
            this.lb_Product_time_N1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_time_N1.Location = new System.Drawing.Point(405, 364);
            this.lb_Product_time_N1.Name = "lb_Product_time_N1";
            this.lb_Product_time_N1.Size = new System.Drawing.Size(45, 26);
            this.lb_Product_time_N1.TabIndex = 120;
            this.lb_Product_time_N1.Text = "0.0％";
            this.lb_Product_time_N1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel14);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(570, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(140, 390);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 2;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 67.36111F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.63889F));
            this.tableLayoutPanel14.Controls.Add(this.txt_CT1, 1, 0);
            this.tableLayoutPanel14.Controls.Add(this.txt_AverageCT10, 1, 10);
            this.tableLayoutPanel14.Controls.Add(this.txt_CT10, 1, 9);
            this.tableLayoutPanel14.Controls.Add(this.txt_CT9, 1, 8);
            this.tableLayoutPanel14.Controls.Add(this.txt_CT8, 1, 7);
            this.tableLayoutPanel14.Controls.Add(this.txt_CT7, 1, 6);
            this.tableLayoutPanel14.Controls.Add(this.txt_CT6, 1, 5);
            this.tableLayoutPanel14.Controls.Add(this.txt_CT5, 1, 4);
            this.tableLayoutPanel14.Controls.Add(this.txt_CT4, 1, 3);
            this.tableLayoutPanel14.Controls.Add(this.txt_CT3, 1, 2);
            this.tableLayoutPanel14.Controls.Add(this.txt_CT2, 1, 1);
            this.tableLayoutPanel14.Controls.Add(this.label39, 0, 0);
            this.tableLayoutPanel14.Controls.Add(this.label40, 0, 1);
            this.tableLayoutPanel14.Controls.Add(this.label41, 0, 2);
            this.tableLayoutPanel14.Controls.Add(this.label42, 0, 3);
            this.tableLayoutPanel14.Controls.Add(this.label44, 0, 4);
            this.tableLayoutPanel14.Controls.Add(this.label45, 0, 5);
            this.tableLayoutPanel14.Controls.Add(this.label46, 0, 6);
            this.tableLayoutPanel14.Controls.Add(this.label48, 0, 7);
            this.tableLayoutPanel14.Controls.Add(this.label49, 0, 8);
            this.tableLayoutPanel14.Controls.Add(this.label51, 0, 9);
            this.tableLayoutPanel14.Controls.Add(this.label52, 0, 10);
            this.tableLayoutPanel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel14.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 11;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(134, 362);
            this.tableLayoutPanel14.TabIndex = 5;
            // 
            // txt_CT1
            // 
            this.txt_CT1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_CT1.Location = new System.Drawing.Point(93, 3);
            this.txt_CT1.Name = "txt_CT1";
            this.txt_CT1.ReadOnly = true;
            this.txt_CT1.Size = new System.Drawing.Size(38, 29);
            this.txt_CT1.TabIndex = 22;
            this.txt_CT1.Text = "0.0";
            // 
            // txt_AverageCT10
            // 
            this.txt_AverageCT10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_AverageCT10.Location = new System.Drawing.Point(93, 326);
            this.txt_AverageCT10.Name = "txt_AverageCT10";
            this.txt_AverageCT10.ReadOnly = true;
            this.txt_AverageCT10.Size = new System.Drawing.Size(38, 29);
            this.txt_AverageCT10.TabIndex = 21;
            this.txt_AverageCT10.Text = "0.0";
            // 
            // txt_CT10
            // 
            this.txt_CT10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_CT10.Location = new System.Drawing.Point(93, 291);
            this.txt_CT10.Name = "txt_CT10";
            this.txt_CT10.ReadOnly = true;
            this.txt_CT10.Size = new System.Drawing.Size(38, 29);
            this.txt_CT10.TabIndex = 20;
            this.txt_CT10.Text = "0.0";
            // 
            // txt_CT9
            // 
            this.txt_CT9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_CT9.Location = new System.Drawing.Point(93, 259);
            this.txt_CT9.Name = "txt_CT9";
            this.txt_CT9.ReadOnly = true;
            this.txt_CT9.Size = new System.Drawing.Size(38, 29);
            this.txt_CT9.TabIndex = 19;
            this.txt_CT9.Text = "0.0";
            // 
            // txt_CT8
            // 
            this.txt_CT8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_CT8.Location = new System.Drawing.Point(93, 227);
            this.txt_CT8.Name = "txt_CT8";
            this.txt_CT8.ReadOnly = true;
            this.txt_CT8.Size = new System.Drawing.Size(38, 29);
            this.txt_CT8.TabIndex = 18;
            this.txt_CT8.Text = "0.0";
            // 
            // txt_CT7
            // 
            this.txt_CT7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_CT7.Location = new System.Drawing.Point(93, 195);
            this.txt_CT7.Name = "txt_CT7";
            this.txt_CT7.ReadOnly = true;
            this.txt_CT7.Size = new System.Drawing.Size(38, 29);
            this.txt_CT7.TabIndex = 17;
            this.txt_CT7.Text = "0.0";
            // 
            // txt_CT6
            // 
            this.txt_CT6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_CT6.Location = new System.Drawing.Point(93, 163);
            this.txt_CT6.Name = "txt_CT6";
            this.txt_CT6.ReadOnly = true;
            this.txt_CT6.Size = new System.Drawing.Size(38, 29);
            this.txt_CT6.TabIndex = 16;
            this.txt_CT6.Text = "0.0";
            // 
            // txt_CT5
            // 
            this.txt_CT5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_CT5.Location = new System.Drawing.Point(93, 131);
            this.txt_CT5.Name = "txt_CT5";
            this.txt_CT5.ReadOnly = true;
            this.txt_CT5.Size = new System.Drawing.Size(38, 29);
            this.txt_CT5.TabIndex = 15;
            this.txt_CT5.Text = "0.0";
            // 
            // txt_CT4
            // 
            this.txt_CT4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_CT4.Location = new System.Drawing.Point(93, 99);
            this.txt_CT4.Name = "txt_CT4";
            this.txt_CT4.ReadOnly = true;
            this.txt_CT4.Size = new System.Drawing.Size(38, 29);
            this.txt_CT4.TabIndex = 14;
            this.txt_CT4.Text = "0.0";
            // 
            // txt_CT3
            // 
            this.txt_CT3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_CT3.Location = new System.Drawing.Point(93, 67);
            this.txt_CT3.Name = "txt_CT3";
            this.txt_CT3.ReadOnly = true;
            this.txt_CT3.Size = new System.Drawing.Size(38, 29);
            this.txt_CT3.TabIndex = 13;
            this.txt_CT3.Text = "0.0";
            // 
            // txt_CT2
            // 
            this.txt_CT2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_CT2.Location = new System.Drawing.Point(93, 35);
            this.txt_CT2.Name = "txt_CT2";
            this.txt_CT2.ReadOnly = true;
            this.txt_CT2.Size = new System.Drawing.Size(38, 29);
            this.txt_CT2.TabIndex = 12;
            this.txt_CT2.Text = "0.0";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label39.Location = new System.Drawing.Point(3, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(84, 32);
            this.label39.TabIndex = 0;
            this.label39.Text = "第1片物料CT";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label40.Location = new System.Drawing.Point(3, 32);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(84, 32);
            this.label40.TabIndex = 1;
            this.label40.Text = "第2片物料CT";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label41.Location = new System.Drawing.Point(3, 64);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(84, 32);
            this.label41.TabIndex = 2;
            this.label41.Text = "第3片物料CT";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label42.Location = new System.Drawing.Point(3, 96);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(84, 32);
            this.label42.TabIndex = 3;
            this.label42.Text = "第4片物料CT";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label44.Location = new System.Drawing.Point(3, 128);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(84, 32);
            this.label44.TabIndex = 4;
            this.label44.Text = "第5片物料CT";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label45.Location = new System.Drawing.Point(3, 160);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(84, 32);
            this.label45.TabIndex = 5;
            this.label45.Text = "第6片物料CT";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label46.Location = new System.Drawing.Point(3, 192);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(84, 32);
            this.label46.TabIndex = 6;
            this.label46.Text = "第7片物料CT";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label48.Location = new System.Drawing.Point(3, 224);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(84, 32);
            this.label48.TabIndex = 7;
            this.label48.Text = "第8片物料CT";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label49.Location = new System.Drawing.Point(3, 256);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(84, 32);
            this.label49.TabIndex = 8;
            this.label49.Text = "第9片物料CT";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label51.Location = new System.Drawing.Point(3, 288);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(84, 32);
            this.label51.TabIndex = 9;
            this.label51.Text = "第10片物料CT";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label52.Location = new System.Drawing.Point(3, 320);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(84, 42);
            this.label52.TabIndex = 10;
            this.label52.Text = "前10片物料平均CT";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tabControl3);
            this.tabPage1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabPage1.Location = new System.Drawing.Point(124, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(733, 492);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "产能统计";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage7);
            this.tabControl3.Controls.Add(this.tabPage6);
            this.tabControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.tabControl3.Location = new System.Drawing.Point(3, 3);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(727, 486);
            this.tabControl3.TabIndex = 3;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.tableLayoutPanel9);
            this.tabPage7.Location = new System.Drawing.Point(4, 30);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(719, 452);
            this.tabPage7.TabIndex = 1;
            this.tabPage7.Text = "图形显示";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 1;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Controls.Add(this.tableLayoutPanel10, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.chart_UPH, 0, 1);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 2;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.05307F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88.94694F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(719, 452);
            this.tableLayoutPanel9.TabIndex = 0;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 4;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34F));
            this.tableLayoutPanel10.Controls.Add(this.dtp_UPH_Table, 1, 0);
            this.tableLayoutPanel10.Controls.Add(this.btn_SelectProductTable, 2, 0);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 1;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(713, 43);
            this.tableLayoutPanel10.TabIndex = 1;
            // 
            // dtp_UPH_Table
            // 
            this.dtp_UPH_Table.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dtp_UPH_Table.CalendarFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.dtp_UPH_Table.CustomFormat = "yyyy年MM月dd日";
            this.dtp_UPH_Table.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.dtp_UPH_Table.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_UPH_Table.Location = new System.Drawing.Point(242, 7);
            this.dtp_UPH_Table.Margin = new System.Windows.Forms.Padding(0);
            this.dtp_UPH_Table.Name = "dtp_UPH_Table";
            this.dtp_UPH_Table.Size = new System.Drawing.Size(156, 29);
            this.dtp_UPH_Table.TabIndex = 16;
            // 
            // btn_SelectProductTable
            // 
            this.btn_SelectProductTable.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_SelectProductTable.Location = new System.Drawing.Point(401, 3);
            this.btn_SelectProductTable.Name = "btn_SelectProductTable";
            this.btn_SelectProductTable.Size = new System.Drawing.Size(65, 37);
            this.btn_SelectProductTable.TabIndex = 17;
            this.btn_SelectProductTable.Text = "查询";
            this.btn_SelectProductTable.UseVisualStyleBackColor = true;
            this.btn_SelectProductTable.Click += new System.EventHandler(this.btn_SelectProductTable_Click);
            // 
            // chart_UPH
            // 
            chartArea3.AxisX.Interval = 1D;
            chartArea3.AxisX.IntervalAutoMode = System.Windows.Forms.DataVisualization.Charting.IntervalAutoMode.VariableCount;
            chartArea3.Name = "ChartArea1";
            this.chart_UPH.ChartAreas.Add(chartArea3);
            this.chart_UPH.Dock = System.Windows.Forms.DockStyle.Fill;
            legend2.Name = "Legend1";
            this.chart_UPH.Legends.Add(legend2);
            this.chart_UPH.Location = new System.Drawing.Point(3, 52);
            this.chart_UPH.Name = "chart_UPH";
            series5.ChartArea = "ChartArea1";
            series5.Legend = "Legend1";
            series5.Name = "Series1";
            series6.ChartArea = "ChartArea1";
            series6.Legend = "Legend1";
            series6.Name = "Series2";
            this.chart_UPH.Series.Add(series5);
            this.chart_UPH.Series.Add(series6);
            this.chart_UPH.Size = new System.Drawing.Size(713, 397);
            this.chart_UPH.TabIndex = 2;
            this.chart_UPH.Text = "chart1";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.tableLayoutPanel6);
            this.tabPage6.Location = new System.Drawing.Point(4, 30);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(719, 452);
            this.tabPage6.TabIndex = 0;
            this.tabPage6.Text = "列表显示";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Controls.Add(this.tableLayoutPanel8, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.tableLayoutPanel7, 0, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88.88889F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(719, 452);
            this.tableLayoutPanel6.TabIndex = 3;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 74.47405F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.52595F));
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel12, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel11, 0, 0);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(3, 53);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 1;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(713, 396);
            this.tableLayoutPanel8.TabIndex = 3;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.ColumnCount = 1;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Controls.Add(this.tableLayoutPanel13, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.tabControl4, 0, 1);
            this.tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(533, 3);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 2;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32.5641F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 67.4359F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(177, 390);
            this.tableLayoutPanel12.TabIndex = 6;
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel13.ColumnCount = 1;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Controls.Add(this.tableLayoutPanel22, 0, 2);
            this.tableLayoutPanel13.Controls.Add(this.tableLayoutPanel20, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.tableLayoutPanel21, 0, 1);
            this.tableLayoutPanel13.Controls.Add(this.outError, 0, 3);
            this.tableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 4;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 21.84874F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.68908F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 27.73109F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 26.85185F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(171, 120);
            this.tableLayoutPanel13.TabIndex = 13;
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.ColumnCount = 3;
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.63158F));
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.47369F));
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.89473F));
            this.tableLayoutPanel22.Controls.Add(this.PF, 0, 0);
            this.tableLayoutPanel22.Controls.Add(this.Yield, 0, 0);
            this.tableLayoutPanel22.Controls.Add(this.All, 0, 0);
            this.tableLayoutPanel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel22.Location = new System.Drawing.Point(4, 57);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 1;
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(163, 26);
            this.tableLayoutPanel22.TabIndex = 7;
            // 
            // PF
            // 
            this.PF.AutoSize = true;
            this.PF.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PF.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PF.Location = new System.Drawing.Point(112, 3);
            this.PF.Name = "PF";
            this.PF.Size = new System.Drawing.Size(48, 20);
            this.PF.TabIndex = 3;
            this.PF.TabStop = true;
            this.PF.Text = "PF部分";
            this.PF.UseVisualStyleBackColor = true;
            // 
            // Yield
            // 
            this.Yield.AutoSize = true;
            this.Yield.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Yield.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Yield.Location = new System.Drawing.Point(48, 3);
            this.Yield.Name = "Yield";
            this.Yield.Size = new System.Drawing.Size(58, 20);
            this.Yield.TabIndex = 2;
            this.Yield.TabStop = true;
            this.Yield.Text = "Yield部分";
            this.Yield.UseVisualStyleBackColor = true;
            // 
            // All
            // 
            this.All.AutoSize = true;
            this.All.Dock = System.Windows.Forms.DockStyle.Fill;
            this.All.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.All.Location = new System.Drawing.Point(3, 3);
            this.All.Name = "All";
            this.All.Size = new System.Drawing.Size(39, 20);
            this.All.TabIndex = 1;
            this.All.TabStop = true;
            this.All.Text = "All";
            this.All.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel20.ColumnCount = 2;
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel20.Controls.Add(this.label13, 1, 0);
            this.tableLayoutPanel20.Controls.Add(this.label14, 0, 0);
            this.tableLayoutPanel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel20.Location = new System.Drawing.Point(4, 4);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 1;
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(163, 19);
            this.tableLayoutPanel20.TabIndex = 2;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.Location = new System.Drawing.Point(85, 1);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(74, 17);
            this.label13.TabIndex = 2;
            this.label13.Text = "结束时间";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(4, 1);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(74, 17);
            this.label14.TabIndex = 0;
            this.label14.Text = "开始时间";
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.ColumnCount = 2;
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel21.Controls.Add(this.EndDay, 0, 0);
            this.tableLayoutPanel21.Controls.Add(this.StartDay, 0, 0);
            this.tableLayoutPanel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel21.Location = new System.Drawing.Point(4, 30);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 1;
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(163, 20);
            this.tableLayoutPanel21.TabIndex = 4;
            // 
            // EndDay
            // 
            this.EndDay.CalendarFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.EndDay.CustomFormat = "yyyy年MM月dd日";
            this.EndDay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.EndDay.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.EndDay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.EndDay.Location = new System.Drawing.Point(81, 0);
            this.EndDay.Margin = new System.Windows.Forms.Padding(0);
            this.EndDay.Name = "EndDay";
            this.EndDay.Size = new System.Drawing.Size(82, 26);
            this.EndDay.TabIndex = 20;
            // 
            // StartDay
            // 
            this.StartDay.CalendarFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.StartDay.CustomFormat = "yyyy年MM月dd日";
            this.StartDay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.StartDay.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.StartDay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.StartDay.Location = new System.Drawing.Point(0, 0);
            this.StartDay.Margin = new System.Windows.Forms.Padding(0);
            this.StartDay.Name = "StartDay";
            this.StartDay.Size = new System.Drawing.Size(81, 26);
            this.StartDay.TabIndex = 19;
            // 
            // outError
            // 
            this.outError.Dock = System.Windows.Forms.DockStyle.Fill;
            this.outError.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.outError.Location = new System.Drawing.Point(4, 90);
            this.outError.Name = "outError";
            this.outError.Size = new System.Drawing.Size(163, 26);
            this.outError.TabIndex = 8;
            this.outError.Text = "导出";
            this.outError.UseVisualStyleBackColor = true;
            this.outError.Click += new System.EventHandler(this.outError_Click);
            // 
            // tabControl4
            // 
            this.tabControl4.Controls.Add(this.tabPage8);
            this.tabControl4.Controls.Add(this.tabPage9);
            this.tabControl4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl4.Location = new System.Drawing.Point(3, 129);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(171, 258);
            this.tabControl4.TabIndex = 10;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.dgv_D);
            this.tabPage8.Location = new System.Drawing.Point(4, 30);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(163, 224);
            this.tabPage8.TabIndex = 0;
            this.tabPage8.Text = "白班";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // dgv_D
            // 
            this.dgv_D.AllowUserToAddRows = false;
            this.dgv_D.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgv_D.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_D.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3});
            this.dgv_D.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_D.Location = new System.Drawing.Point(3, 3);
            this.dgv_D.Name = "dgv_D";
            this.dgv_D.ReadOnly = true;
            this.dgv_D.RowHeadersWidth = 51;
            this.dgv_D.RowTemplate.Height = 23;
            this.dgv_D.Size = new System.Drawing.Size(157, 218);
            this.dgv_D.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "统计项目";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column1.Width = 124;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "数量";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column2.Width = 124;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "百分比";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column3.Width = 124;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.dgv_N);
            this.tabPage9.Location = new System.Drawing.Point(4, 30);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(163, 224);
            this.tabPage9.TabIndex = 1;
            this.tabPage9.Text = "夜班";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // dgv_N
            // 
            this.dgv_N.AllowUserToAddRows = false;
            this.dgv_N.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgv_N.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_N.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.dgv_N.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_N.Location = new System.Drawing.Point(3, 3);
            this.dgv_N.Name = "dgv_N";
            this.dgv_N.ReadOnly = true;
            this.dgv_N.RowHeadersWidth = 51;
            this.dgv_N.RowTemplate.Height = 23;
            this.dgv_N.Size = new System.Drawing.Size(157, 218);
            this.dgv_N.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "统计项目";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Width = 124;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "数量";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Width = 124;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "百分比";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn3.Width = 124;
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 11;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 0.485517F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.10943F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.116529F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.116529F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.116529F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 2.110943F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.10943F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.116529F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.116529F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.116529F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 0.485517F));
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_propery_N1, 7, 14);
            this.tableLayoutPanel11.Controls.Add(this.label1, 6, 14);
            this.tableLayoutPanel11.Controls.Add(this.label124, 1, 13);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_08_20, 2, 13);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_08_20, 3, 13);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_08_20, 4, 13);
            this.tableLayoutPanel11.Controls.Add(this.label128, 6, 13);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_20_08, 7, 13);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_20_08, 8, 13);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_20_08, 9, 13);
            this.tableLayoutPanel11.Controls.Add(this.label132, 1, 12);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_19_20, 2, 12);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_19_20, 3, 12);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_19_20, 4, 12);
            this.tableLayoutPanel11.Controls.Add(this.label136, 6, 12);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_07_08, 7, 12);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_07_08, 8, 12);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_07_08, 9, 12);
            this.tableLayoutPanel11.Controls.Add(this.label140, 1, 11);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_18_19, 2, 11);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_18_19, 3, 11);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_18_19, 4, 11);
            this.tableLayoutPanel11.Controls.Add(this.label144, 6, 11);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_06_07, 7, 11);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_06_07, 8, 11);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_06_07, 9, 11);
            this.tableLayoutPanel11.Controls.Add(this.label148, 1, 10);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_17_18, 2, 10);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_17_18, 3, 10);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_17_18, 4, 10);
            this.tableLayoutPanel11.Controls.Add(this.label152, 6, 10);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_05_06, 7, 10);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_05_06, 8, 10);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_05_06, 9, 10);
            this.tableLayoutPanel11.Controls.Add(this.label156, 1, 9);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_16_17, 2, 9);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_16_17, 3, 9);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_16_17, 4, 9);
            this.tableLayoutPanel11.Controls.Add(this.label160, 6, 9);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_04_05, 7, 9);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_04_05, 8, 9);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_04_05, 9, 9);
            this.tableLayoutPanel11.Controls.Add(this.label164, 1, 8);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_15_16, 2, 8);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_15_16, 3, 8);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_15_16, 4, 8);
            this.tableLayoutPanel11.Controls.Add(this.label168, 6, 8);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_03_04, 7, 8);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_03_04, 8, 8);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_03_04, 9, 8);
            this.tableLayoutPanel11.Controls.Add(this.label172, 1, 7);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_14_15, 2, 7);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_14_15, 3, 7);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_14_15, 4, 7);
            this.tableLayoutPanel11.Controls.Add(this.label176, 6, 7);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_02_03, 7, 7);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_02_03, 8, 7);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_02_03, 9, 7);
            this.tableLayoutPanel11.Controls.Add(this.label180, 1, 6);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_13_14, 2, 6);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_13_14, 3, 6);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_13_14, 4, 6);
            this.tableLayoutPanel11.Controls.Add(this.label184, 6, 6);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_01_02, 7, 6);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_01_02, 8, 6);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_01_02, 9, 6);
            this.tableLayoutPanel11.Controls.Add(this.label188, 1, 5);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_12_13, 2, 5);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_12_13, 3, 5);
            this.tableLayoutPanel11.Controls.Add(this.label191, 1, 4);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_11_12, 2, 4);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_11_12, 3, 4);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_11_12, 4, 4);
            this.tableLayoutPanel11.Controls.Add(this.label195, 1, 3);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_10_11, 2, 3);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_10_11, 3, 3);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_10_11, 4, 3);
            this.tableLayoutPanel11.Controls.Add(this.label199, 1, 2);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_09_10, 2, 2);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_09_10, 3, 2);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_09_10, 4, 2);
            this.tableLayoutPanel11.Controls.Add(this.label203, 1, 1);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_08_09, 2, 1);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_08_09, 3, 1);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_08_09, 4, 1);
            this.tableLayoutPanel11.Controls.Add(this.label207, 4, 0);
            this.tableLayoutPanel11.Controls.Add(this.label208, 3, 0);
            this.tableLayoutPanel11.Controls.Add(this.label209, 2, 0);
            this.tableLayoutPanel11.Controls.Add(this.label210, 1, 0);
            this.tableLayoutPanel11.Controls.Add(this.label211, 9, 0);
            this.tableLayoutPanel11.Controls.Add(this.label212, 8, 0);
            this.tableLayoutPanel11.Controls.Add(this.label213, 7, 0);
            this.tableLayoutPanel11.Controls.Add(this.label214, 6, 0);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_20_21, 9, 1);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_20_21, 8, 1);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_20_21, 7, 1);
            this.tableLayoutPanel11.Controls.Add(this.label218, 6, 1);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_21_22, 9, 2);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_21_22, 8, 2);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_21_22, 7, 2);
            this.tableLayoutPanel11.Controls.Add(this.label222, 6, 2);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_22_23, 9, 3);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_22_23, 8, 3);
            this.tableLayoutPanel11.Controls.Add(this.label226, 6, 3);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_23_00, 9, 4);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_23_00, 7, 4);
            this.tableLayoutPanel11.Controls.Add(this.label229, 6, 4);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_00_01, 9, 5);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_00_01, 8, 5);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_NG_23_00, 8, 4);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_00_01, 7, 5);
            this.tableLayoutPanel11.Controls.Add(this.label234, 6, 5);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Lianglv_12_13, 4, 5);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_Total_22_23, 7, 3);
            this.tableLayoutPanel11.Controls.Add(this.label71, 1, 14);
            this.tableLayoutPanel11.Controls.Add(this.lb_Product_propery, 2, 14);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel11.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.tableLayoutPanel11.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 15;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(524, 390);
            this.tableLayoutPanel11.TabIndex = 4;
            // 
            // lb_Product_propery_N1
            // 
            this.lb_Product_propery_N1.AutoSize = true;
            this.lb_Product_propery_N1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_propery_N1.Location = new System.Drawing.Point(377, 364);
            this.lb_Product_propery_N1.Name = "lb_Product_propery_N1";
            this.lb_Product_propery_N1.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_propery_N1.TabIndex = 116;
            this.lb_Product_propery_N1.Text = "0.0％";
            this.lb_Product_propery_N1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(267, 364);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 26);
            this.label1.TabIndex = 115;
            this.label1.Text = "性能稼动";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label124.Location = new System.Drawing.Point(5, 338);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(104, 26);
            this.label124.TabIndex = 110;
            this.label124.Text = "合计";
            this.label124.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_08_20
            // 
            this.lb_Product_Total_08_20.AutoSize = true;
            this.lb_Product_Total_08_20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_08_20.Location = new System.Drawing.Point(115, 338);
            this.lb_Product_Total_08_20.Name = "lb_Product_Total_08_20";
            this.lb_Product_Total_08_20.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_08_20.TabIndex = 109;
            this.lb_Product_Total_08_20.Text = "0";
            this.lb_Product_Total_08_20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_08_20
            // 
            this.lb_Product_NG_08_20.AutoSize = true;
            this.lb_Product_NG_08_20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_08_20.Location = new System.Drawing.Point(162, 338);
            this.lb_Product_NG_08_20.Name = "lb_Product_NG_08_20";
            this.lb_Product_NG_08_20.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_08_20.TabIndex = 108;
            this.lb_Product_NG_08_20.Text = "0";
            this.lb_Product_NG_08_20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_08_20
            // 
            this.lb_Product_Lianglv_08_20.AutoSize = true;
            this.lb_Product_Lianglv_08_20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_08_20.Location = new System.Drawing.Point(209, 338);
            this.lb_Product_Lianglv_08_20.Name = "lb_Product_Lianglv_08_20";
            this.lb_Product_Lianglv_08_20.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_08_20.TabIndex = 111;
            this.lb_Product_Lianglv_08_20.Text = "0";
            this.lb_Product_Lianglv_08_20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label128.Location = new System.Drawing.Point(267, 338);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(104, 26);
            this.label128.TabIndex = 104;
            this.label128.Text = "合计";
            this.label128.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_20_08
            // 
            this.lb_Product_Total_20_08.AutoSize = true;
            this.lb_Product_Total_20_08.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_20_08.Location = new System.Drawing.Point(377, 338);
            this.lb_Product_Total_20_08.Name = "lb_Product_Total_20_08";
            this.lb_Product_Total_20_08.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_20_08.TabIndex = 105;
            this.lb_Product_Total_20_08.Text = "0";
            this.lb_Product_Total_20_08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_20_08
            // 
            this.lb_Product_NG_20_08.AutoSize = true;
            this.lb_Product_NG_20_08.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_20_08.Location = new System.Drawing.Point(424, 338);
            this.lb_Product_NG_20_08.Name = "lb_Product_NG_20_08";
            this.lb_Product_NG_20_08.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_20_08.TabIndex = 106;
            this.lb_Product_NG_20_08.Text = "0";
            this.lb_Product_NG_20_08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_20_08
            // 
            this.lb_Product_Lianglv_20_08.AutoSize = true;
            this.lb_Product_Lianglv_20_08.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_20_08.Location = new System.Drawing.Point(471, 338);
            this.lb_Product_Lianglv_20_08.Name = "lb_Product_Lianglv_20_08";
            this.lb_Product_Lianglv_20_08.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_20_08.TabIndex = 107;
            this.lb_Product_Lianglv_20_08.Text = "0";
            this.lb_Product_Lianglv_20_08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label132.Location = new System.Drawing.Point(5, 312);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(104, 26);
            this.label132.TabIndex = 102;
            this.label132.Text = "17:00-18:00";
            this.label132.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_19_20
            // 
            this.lb_Product_Total_19_20.AutoSize = true;
            this.lb_Product_Total_19_20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_19_20.Location = new System.Drawing.Point(115, 312);
            this.lb_Product_Total_19_20.Name = "lb_Product_Total_19_20";
            this.lb_Product_Total_19_20.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_19_20.TabIndex = 101;
            this.lb_Product_Total_19_20.Text = "0";
            this.lb_Product_Total_19_20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_19_20
            // 
            this.lb_Product_NG_19_20.AutoSize = true;
            this.lb_Product_NG_19_20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_19_20.Location = new System.Drawing.Point(162, 312);
            this.lb_Product_NG_19_20.Name = "lb_Product_NG_19_20";
            this.lb_Product_NG_19_20.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_19_20.TabIndex = 100;
            this.lb_Product_NG_19_20.Text = "0";
            this.lb_Product_NG_19_20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_19_20
            // 
            this.lb_Product_Lianglv_19_20.AutoSize = true;
            this.lb_Product_Lianglv_19_20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_19_20.Location = new System.Drawing.Point(209, 312);
            this.lb_Product_Lianglv_19_20.Name = "lb_Product_Lianglv_19_20";
            this.lb_Product_Lianglv_19_20.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_19_20.TabIndex = 103;
            this.lb_Product_Lianglv_19_20.Text = "0";
            this.lb_Product_Lianglv_19_20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label136.Location = new System.Drawing.Point(267, 312);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(104, 26);
            this.label136.TabIndex = 96;
            this.label136.Text = "05:00-06:00";
            this.label136.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_07_08
            // 
            this.lb_Product_Total_07_08.AutoSize = true;
            this.lb_Product_Total_07_08.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_07_08.Location = new System.Drawing.Point(377, 312);
            this.lb_Product_Total_07_08.Name = "lb_Product_Total_07_08";
            this.lb_Product_Total_07_08.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_07_08.TabIndex = 97;
            this.lb_Product_Total_07_08.Text = "0";
            this.lb_Product_Total_07_08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_07_08
            // 
            this.lb_Product_NG_07_08.AutoSize = true;
            this.lb_Product_NG_07_08.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_07_08.Location = new System.Drawing.Point(424, 312);
            this.lb_Product_NG_07_08.Name = "lb_Product_NG_07_08";
            this.lb_Product_NG_07_08.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_07_08.TabIndex = 98;
            this.lb_Product_NG_07_08.Text = "0";
            this.lb_Product_NG_07_08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_07_08
            // 
            this.lb_Product_Lianglv_07_08.AutoSize = true;
            this.lb_Product_Lianglv_07_08.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_07_08.Location = new System.Drawing.Point(471, 312);
            this.lb_Product_Lianglv_07_08.Name = "lb_Product_Lianglv_07_08";
            this.lb_Product_Lianglv_07_08.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_07_08.TabIndex = 99;
            this.lb_Product_Lianglv_07_08.Text = "0";
            this.lb_Product_Lianglv_07_08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label140.Location = new System.Drawing.Point(5, 286);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(104, 26);
            this.label140.TabIndex = 94;
            this.label140.Text = "16:00-17:00";
            this.label140.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_18_19
            // 
            this.lb_Product_Total_18_19.AutoSize = true;
            this.lb_Product_Total_18_19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_18_19.Location = new System.Drawing.Point(115, 286);
            this.lb_Product_Total_18_19.Name = "lb_Product_Total_18_19";
            this.lb_Product_Total_18_19.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_18_19.TabIndex = 93;
            this.lb_Product_Total_18_19.Text = "0";
            this.lb_Product_Total_18_19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_18_19
            // 
            this.lb_Product_NG_18_19.AutoSize = true;
            this.lb_Product_NG_18_19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_18_19.Location = new System.Drawing.Point(162, 286);
            this.lb_Product_NG_18_19.Name = "lb_Product_NG_18_19";
            this.lb_Product_NG_18_19.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_18_19.TabIndex = 92;
            this.lb_Product_NG_18_19.Text = "0";
            this.lb_Product_NG_18_19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_18_19
            // 
            this.lb_Product_Lianglv_18_19.AutoSize = true;
            this.lb_Product_Lianglv_18_19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_18_19.Location = new System.Drawing.Point(209, 286);
            this.lb_Product_Lianglv_18_19.Name = "lb_Product_Lianglv_18_19";
            this.lb_Product_Lianglv_18_19.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_18_19.TabIndex = 95;
            this.lb_Product_Lianglv_18_19.Text = "0";
            this.lb_Product_Lianglv_18_19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label144
            // 
            this.label144.AutoSize = true;
            this.label144.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label144.Location = new System.Drawing.Point(267, 286);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(104, 26);
            this.label144.TabIndex = 88;
            this.label144.Text = "04:00-05:00";
            this.label144.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_06_07
            // 
            this.lb_Product_Total_06_07.AutoSize = true;
            this.lb_Product_Total_06_07.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_06_07.Location = new System.Drawing.Point(377, 286);
            this.lb_Product_Total_06_07.Name = "lb_Product_Total_06_07";
            this.lb_Product_Total_06_07.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_06_07.TabIndex = 89;
            this.lb_Product_Total_06_07.Text = "0";
            this.lb_Product_Total_06_07.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_06_07
            // 
            this.lb_Product_NG_06_07.AutoSize = true;
            this.lb_Product_NG_06_07.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_06_07.Location = new System.Drawing.Point(424, 286);
            this.lb_Product_NG_06_07.Name = "lb_Product_NG_06_07";
            this.lb_Product_NG_06_07.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_06_07.TabIndex = 90;
            this.lb_Product_NG_06_07.Text = "0";
            this.lb_Product_NG_06_07.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_06_07
            // 
            this.lb_Product_Lianglv_06_07.AutoSize = true;
            this.lb_Product_Lianglv_06_07.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_06_07.Location = new System.Drawing.Point(471, 286);
            this.lb_Product_Lianglv_06_07.Name = "lb_Product_Lianglv_06_07";
            this.lb_Product_Lianglv_06_07.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_06_07.TabIndex = 91;
            this.lb_Product_Lianglv_06_07.Text = "0";
            this.lb_Product_Lianglv_06_07.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label148
            // 
            this.label148.AutoSize = true;
            this.label148.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label148.Location = new System.Drawing.Point(5, 260);
            this.label148.Name = "label148";
            this.label148.Size = new System.Drawing.Size(104, 26);
            this.label148.TabIndex = 86;
            this.label148.Text = "15:00-16:00";
            this.label148.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_17_18
            // 
            this.lb_Product_Total_17_18.AutoSize = true;
            this.lb_Product_Total_17_18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_17_18.Location = new System.Drawing.Point(115, 260);
            this.lb_Product_Total_17_18.Name = "lb_Product_Total_17_18";
            this.lb_Product_Total_17_18.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_17_18.TabIndex = 85;
            this.lb_Product_Total_17_18.Text = "0";
            this.lb_Product_Total_17_18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_17_18
            // 
            this.lb_Product_NG_17_18.AutoSize = true;
            this.lb_Product_NG_17_18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_17_18.Location = new System.Drawing.Point(162, 260);
            this.lb_Product_NG_17_18.Name = "lb_Product_NG_17_18";
            this.lb_Product_NG_17_18.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_17_18.TabIndex = 84;
            this.lb_Product_NG_17_18.Text = "0";
            this.lb_Product_NG_17_18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_17_18
            // 
            this.lb_Product_Lianglv_17_18.AutoSize = true;
            this.lb_Product_Lianglv_17_18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_17_18.Location = new System.Drawing.Point(209, 260);
            this.lb_Product_Lianglv_17_18.Name = "lb_Product_Lianglv_17_18";
            this.lb_Product_Lianglv_17_18.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_17_18.TabIndex = 87;
            this.lb_Product_Lianglv_17_18.Text = "0";
            this.lb_Product_Lianglv_17_18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label152
            // 
            this.label152.AutoSize = true;
            this.label152.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label152.Location = new System.Drawing.Point(267, 260);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(104, 26);
            this.label152.TabIndex = 80;
            this.label152.Text = "03:00-04:00";
            this.label152.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_05_06
            // 
            this.lb_Product_Total_05_06.AutoSize = true;
            this.lb_Product_Total_05_06.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_05_06.Location = new System.Drawing.Point(377, 260);
            this.lb_Product_Total_05_06.Name = "lb_Product_Total_05_06";
            this.lb_Product_Total_05_06.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_05_06.TabIndex = 81;
            this.lb_Product_Total_05_06.Text = "0";
            this.lb_Product_Total_05_06.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_05_06
            // 
            this.lb_Product_NG_05_06.AutoSize = true;
            this.lb_Product_NG_05_06.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_05_06.Location = new System.Drawing.Point(424, 260);
            this.lb_Product_NG_05_06.Name = "lb_Product_NG_05_06";
            this.lb_Product_NG_05_06.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_05_06.TabIndex = 82;
            this.lb_Product_NG_05_06.Text = "0";
            this.lb_Product_NG_05_06.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_05_06
            // 
            this.lb_Product_Lianglv_05_06.AutoSize = true;
            this.lb_Product_Lianglv_05_06.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_05_06.Location = new System.Drawing.Point(471, 260);
            this.lb_Product_Lianglv_05_06.Name = "lb_Product_Lianglv_05_06";
            this.lb_Product_Lianglv_05_06.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_05_06.TabIndex = 83;
            this.lb_Product_Lianglv_05_06.Text = "0";
            this.lb_Product_Lianglv_05_06.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label156
            // 
            this.label156.AutoSize = true;
            this.label156.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label156.Location = new System.Drawing.Point(5, 234);
            this.label156.Name = "label156";
            this.label156.Size = new System.Drawing.Size(104, 26);
            this.label156.TabIndex = 78;
            this.label156.Text = "14:00-15:00";
            this.label156.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_16_17
            // 
            this.lb_Product_Total_16_17.AutoSize = true;
            this.lb_Product_Total_16_17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_16_17.Location = new System.Drawing.Point(115, 234);
            this.lb_Product_Total_16_17.Name = "lb_Product_Total_16_17";
            this.lb_Product_Total_16_17.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_16_17.TabIndex = 77;
            this.lb_Product_Total_16_17.Text = "0";
            this.lb_Product_Total_16_17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_16_17
            // 
            this.lb_Product_NG_16_17.AutoSize = true;
            this.lb_Product_NG_16_17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_16_17.Location = new System.Drawing.Point(162, 234);
            this.lb_Product_NG_16_17.Name = "lb_Product_NG_16_17";
            this.lb_Product_NG_16_17.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_16_17.TabIndex = 76;
            this.lb_Product_NG_16_17.Text = "0";
            this.lb_Product_NG_16_17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_16_17
            // 
            this.lb_Product_Lianglv_16_17.AutoSize = true;
            this.lb_Product_Lianglv_16_17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_16_17.Location = new System.Drawing.Point(209, 234);
            this.lb_Product_Lianglv_16_17.Name = "lb_Product_Lianglv_16_17";
            this.lb_Product_Lianglv_16_17.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_16_17.TabIndex = 79;
            this.lb_Product_Lianglv_16_17.Text = "0";
            this.lb_Product_Lianglv_16_17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label160
            // 
            this.label160.AutoSize = true;
            this.label160.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label160.Location = new System.Drawing.Point(267, 234);
            this.label160.Name = "label160";
            this.label160.Size = new System.Drawing.Size(104, 26);
            this.label160.TabIndex = 72;
            this.label160.Text = "02:00-03:00";
            this.label160.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_04_05
            // 
            this.lb_Product_Total_04_05.AutoSize = true;
            this.lb_Product_Total_04_05.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_04_05.Location = new System.Drawing.Point(377, 234);
            this.lb_Product_Total_04_05.Name = "lb_Product_Total_04_05";
            this.lb_Product_Total_04_05.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_04_05.TabIndex = 73;
            this.lb_Product_Total_04_05.Text = "0";
            this.lb_Product_Total_04_05.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_04_05
            // 
            this.lb_Product_NG_04_05.AutoSize = true;
            this.lb_Product_NG_04_05.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_04_05.Location = new System.Drawing.Point(424, 234);
            this.lb_Product_NG_04_05.Name = "lb_Product_NG_04_05";
            this.lb_Product_NG_04_05.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_04_05.TabIndex = 74;
            this.lb_Product_NG_04_05.Text = "0";
            this.lb_Product_NG_04_05.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_04_05
            // 
            this.lb_Product_Lianglv_04_05.AutoSize = true;
            this.lb_Product_Lianglv_04_05.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_04_05.Location = new System.Drawing.Point(471, 234);
            this.lb_Product_Lianglv_04_05.Name = "lb_Product_Lianglv_04_05";
            this.lb_Product_Lianglv_04_05.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_04_05.TabIndex = 75;
            this.lb_Product_Lianglv_04_05.Text = "0";
            this.lb_Product_Lianglv_04_05.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label164
            // 
            this.label164.AutoSize = true;
            this.label164.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label164.Location = new System.Drawing.Point(5, 208);
            this.label164.Name = "label164";
            this.label164.Size = new System.Drawing.Size(104, 26);
            this.label164.TabIndex = 70;
            this.label164.Text = "13:00-14:00";
            this.label164.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_15_16
            // 
            this.lb_Product_Total_15_16.AutoSize = true;
            this.lb_Product_Total_15_16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_15_16.Location = new System.Drawing.Point(115, 208);
            this.lb_Product_Total_15_16.Name = "lb_Product_Total_15_16";
            this.lb_Product_Total_15_16.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_15_16.TabIndex = 69;
            this.lb_Product_Total_15_16.Text = "0";
            this.lb_Product_Total_15_16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_15_16
            // 
            this.lb_Product_NG_15_16.AutoSize = true;
            this.lb_Product_NG_15_16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_15_16.Location = new System.Drawing.Point(162, 208);
            this.lb_Product_NG_15_16.Name = "lb_Product_NG_15_16";
            this.lb_Product_NG_15_16.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_15_16.TabIndex = 68;
            this.lb_Product_NG_15_16.Text = "0";
            this.lb_Product_NG_15_16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_15_16
            // 
            this.lb_Product_Lianglv_15_16.AutoSize = true;
            this.lb_Product_Lianglv_15_16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_15_16.Location = new System.Drawing.Point(209, 208);
            this.lb_Product_Lianglv_15_16.Name = "lb_Product_Lianglv_15_16";
            this.lb_Product_Lianglv_15_16.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_15_16.TabIndex = 71;
            this.lb_Product_Lianglv_15_16.Text = "0";
            this.lb_Product_Lianglv_15_16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label168
            // 
            this.label168.AutoSize = true;
            this.label168.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label168.Location = new System.Drawing.Point(267, 208);
            this.label168.Name = "label168";
            this.label168.Size = new System.Drawing.Size(104, 26);
            this.label168.TabIndex = 64;
            this.label168.Text = "01:00-02:00";
            this.label168.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_03_04
            // 
            this.lb_Product_Total_03_04.AutoSize = true;
            this.lb_Product_Total_03_04.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_03_04.Location = new System.Drawing.Point(377, 208);
            this.lb_Product_Total_03_04.Name = "lb_Product_Total_03_04";
            this.lb_Product_Total_03_04.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_03_04.TabIndex = 65;
            this.lb_Product_Total_03_04.Text = "0";
            this.lb_Product_Total_03_04.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_03_04
            // 
            this.lb_Product_NG_03_04.AutoSize = true;
            this.lb_Product_NG_03_04.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_03_04.Location = new System.Drawing.Point(424, 208);
            this.lb_Product_NG_03_04.Name = "lb_Product_NG_03_04";
            this.lb_Product_NG_03_04.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_03_04.TabIndex = 66;
            this.lb_Product_NG_03_04.Text = "0";
            this.lb_Product_NG_03_04.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_03_04
            // 
            this.lb_Product_Lianglv_03_04.AutoSize = true;
            this.lb_Product_Lianglv_03_04.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_03_04.Location = new System.Drawing.Point(471, 208);
            this.lb_Product_Lianglv_03_04.Name = "lb_Product_Lianglv_03_04";
            this.lb_Product_Lianglv_03_04.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_03_04.TabIndex = 67;
            this.lb_Product_Lianglv_03_04.Text = "0";
            this.lb_Product_Lianglv_03_04.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label172
            // 
            this.label172.AutoSize = true;
            this.label172.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label172.Location = new System.Drawing.Point(5, 182);
            this.label172.Name = "label172";
            this.label172.Size = new System.Drawing.Size(104, 26);
            this.label172.TabIndex = 62;
            this.label172.Text = "12:00-13:00";
            this.label172.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_14_15
            // 
            this.lb_Product_Total_14_15.AutoSize = true;
            this.lb_Product_Total_14_15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_14_15.Location = new System.Drawing.Point(115, 182);
            this.lb_Product_Total_14_15.Name = "lb_Product_Total_14_15";
            this.lb_Product_Total_14_15.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_14_15.TabIndex = 61;
            this.lb_Product_Total_14_15.Text = "0";
            this.lb_Product_Total_14_15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_14_15
            // 
            this.lb_Product_NG_14_15.AutoSize = true;
            this.lb_Product_NG_14_15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_14_15.Location = new System.Drawing.Point(162, 182);
            this.lb_Product_NG_14_15.Name = "lb_Product_NG_14_15";
            this.lb_Product_NG_14_15.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_14_15.TabIndex = 60;
            this.lb_Product_NG_14_15.Text = "0";
            this.lb_Product_NG_14_15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_14_15
            // 
            this.lb_Product_Lianglv_14_15.AutoSize = true;
            this.lb_Product_Lianglv_14_15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_14_15.Location = new System.Drawing.Point(209, 182);
            this.lb_Product_Lianglv_14_15.Name = "lb_Product_Lianglv_14_15";
            this.lb_Product_Lianglv_14_15.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_14_15.TabIndex = 63;
            this.lb_Product_Lianglv_14_15.Text = "0";
            this.lb_Product_Lianglv_14_15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label176
            // 
            this.label176.AutoSize = true;
            this.label176.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label176.Location = new System.Drawing.Point(267, 182);
            this.label176.Name = "label176";
            this.label176.Size = new System.Drawing.Size(104, 26);
            this.label176.TabIndex = 56;
            this.label176.Text = "00:00-01:00";
            this.label176.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_02_03
            // 
            this.lb_Product_Total_02_03.AutoSize = true;
            this.lb_Product_Total_02_03.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_02_03.Location = new System.Drawing.Point(377, 182);
            this.lb_Product_Total_02_03.Name = "lb_Product_Total_02_03";
            this.lb_Product_Total_02_03.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_02_03.TabIndex = 57;
            this.lb_Product_Total_02_03.Text = "0";
            this.lb_Product_Total_02_03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_02_03
            // 
            this.lb_Product_NG_02_03.AutoSize = true;
            this.lb_Product_NG_02_03.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_02_03.Location = new System.Drawing.Point(424, 182);
            this.lb_Product_NG_02_03.Name = "lb_Product_NG_02_03";
            this.lb_Product_NG_02_03.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_02_03.TabIndex = 58;
            this.lb_Product_NG_02_03.Text = "0";
            this.lb_Product_NG_02_03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_02_03
            // 
            this.lb_Product_Lianglv_02_03.AutoSize = true;
            this.lb_Product_Lianglv_02_03.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_02_03.Location = new System.Drawing.Point(471, 182);
            this.lb_Product_Lianglv_02_03.Name = "lb_Product_Lianglv_02_03";
            this.lb_Product_Lianglv_02_03.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_02_03.TabIndex = 59;
            this.lb_Product_Lianglv_02_03.Text = "0";
            this.lb_Product_Lianglv_02_03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label180
            // 
            this.label180.AutoSize = true;
            this.label180.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label180.Location = new System.Drawing.Point(5, 156);
            this.label180.Name = "label180";
            this.label180.Size = new System.Drawing.Size(104, 26);
            this.label180.TabIndex = 54;
            this.label180.Text = "11:00-12:00";
            this.label180.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_13_14
            // 
            this.lb_Product_Total_13_14.AutoSize = true;
            this.lb_Product_Total_13_14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_13_14.Location = new System.Drawing.Point(115, 156);
            this.lb_Product_Total_13_14.Name = "lb_Product_Total_13_14";
            this.lb_Product_Total_13_14.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_13_14.TabIndex = 53;
            this.lb_Product_Total_13_14.Text = "0";
            this.lb_Product_Total_13_14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_13_14
            // 
            this.lb_Product_NG_13_14.AutoSize = true;
            this.lb_Product_NG_13_14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_13_14.Location = new System.Drawing.Point(162, 156);
            this.lb_Product_NG_13_14.Name = "lb_Product_NG_13_14";
            this.lb_Product_NG_13_14.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_13_14.TabIndex = 52;
            this.lb_Product_NG_13_14.Text = "0";
            this.lb_Product_NG_13_14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_13_14
            // 
            this.lb_Product_Lianglv_13_14.AutoSize = true;
            this.lb_Product_Lianglv_13_14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_13_14.Location = new System.Drawing.Point(209, 156);
            this.lb_Product_Lianglv_13_14.Name = "lb_Product_Lianglv_13_14";
            this.lb_Product_Lianglv_13_14.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_13_14.TabIndex = 55;
            this.lb_Product_Lianglv_13_14.Text = "0";
            this.lb_Product_Lianglv_13_14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label184
            // 
            this.label184.AutoSize = true;
            this.label184.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label184.Location = new System.Drawing.Point(267, 156);
            this.label184.Name = "label184";
            this.label184.Size = new System.Drawing.Size(104, 26);
            this.label184.TabIndex = 48;
            this.label184.Text = "23:00-00:00";
            this.label184.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_01_02
            // 
            this.lb_Product_Total_01_02.AutoSize = true;
            this.lb_Product_Total_01_02.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_01_02.Location = new System.Drawing.Point(377, 156);
            this.lb_Product_Total_01_02.Name = "lb_Product_Total_01_02";
            this.lb_Product_Total_01_02.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_01_02.TabIndex = 49;
            this.lb_Product_Total_01_02.Text = "0";
            this.lb_Product_Total_01_02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_01_02
            // 
            this.lb_Product_NG_01_02.AutoSize = true;
            this.lb_Product_NG_01_02.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_01_02.Location = new System.Drawing.Point(424, 156);
            this.lb_Product_NG_01_02.Name = "lb_Product_NG_01_02";
            this.lb_Product_NG_01_02.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_01_02.TabIndex = 50;
            this.lb_Product_NG_01_02.Text = "0";
            this.lb_Product_NG_01_02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_01_02
            // 
            this.lb_Product_Lianglv_01_02.AutoSize = true;
            this.lb_Product_Lianglv_01_02.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_01_02.Location = new System.Drawing.Point(471, 156);
            this.lb_Product_Lianglv_01_02.Name = "lb_Product_Lianglv_01_02";
            this.lb_Product_Lianglv_01_02.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_01_02.TabIndex = 51;
            this.lb_Product_Lianglv_01_02.Text = "0";
            this.lb_Product_Lianglv_01_02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label188
            // 
            this.label188.AutoSize = true;
            this.label188.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label188.Location = new System.Drawing.Point(5, 130);
            this.label188.Name = "label188";
            this.label188.Size = new System.Drawing.Size(104, 26);
            this.label188.TabIndex = 46;
            this.label188.Text = "10:00-11:00";
            this.label188.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_12_13
            // 
            this.lb_Product_Total_12_13.AutoSize = true;
            this.lb_Product_Total_12_13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_12_13.Location = new System.Drawing.Point(115, 130);
            this.lb_Product_Total_12_13.Name = "lb_Product_Total_12_13";
            this.lb_Product_Total_12_13.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_12_13.TabIndex = 45;
            this.lb_Product_Total_12_13.Text = "0";
            this.lb_Product_Total_12_13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_12_13
            // 
            this.lb_Product_NG_12_13.AutoSize = true;
            this.lb_Product_NG_12_13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_12_13.Location = new System.Drawing.Point(162, 130);
            this.lb_Product_NG_12_13.Name = "lb_Product_NG_12_13";
            this.lb_Product_NG_12_13.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_12_13.TabIndex = 44;
            this.lb_Product_NG_12_13.Text = "0";
            this.lb_Product_NG_12_13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label191
            // 
            this.label191.AutoSize = true;
            this.label191.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label191.Location = new System.Drawing.Point(5, 104);
            this.label191.Name = "label191";
            this.label191.Size = new System.Drawing.Size(104, 26);
            this.label191.TabIndex = 39;
            this.label191.Text = "09:00-10:00";
            this.label191.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_11_12
            // 
            this.lb_Product_Total_11_12.AutoSize = true;
            this.lb_Product_Total_11_12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_11_12.Location = new System.Drawing.Point(115, 104);
            this.lb_Product_Total_11_12.Name = "lb_Product_Total_11_12";
            this.lb_Product_Total_11_12.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_11_12.TabIndex = 38;
            this.lb_Product_Total_11_12.Text = "0";
            this.lb_Product_Total_11_12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_11_12
            // 
            this.lb_Product_NG_11_12.AutoSize = true;
            this.lb_Product_NG_11_12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_11_12.Location = new System.Drawing.Point(162, 104);
            this.lb_Product_NG_11_12.Name = "lb_Product_NG_11_12";
            this.lb_Product_NG_11_12.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_11_12.TabIndex = 37;
            this.lb_Product_NG_11_12.Text = "0";
            this.lb_Product_NG_11_12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_11_12
            // 
            this.lb_Product_Lianglv_11_12.AutoSize = true;
            this.lb_Product_Lianglv_11_12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_11_12.Location = new System.Drawing.Point(209, 104);
            this.lb_Product_Lianglv_11_12.Name = "lb_Product_Lianglv_11_12";
            this.lb_Product_Lianglv_11_12.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_11_12.TabIndex = 36;
            this.lb_Product_Lianglv_11_12.Text = "0";
            this.lb_Product_Lianglv_11_12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label195
            // 
            this.label195.AutoSize = true;
            this.label195.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label195.Location = new System.Drawing.Point(5, 78);
            this.label195.Name = "label195";
            this.label195.Size = new System.Drawing.Size(104, 26);
            this.label195.TabIndex = 24;
            this.label195.Text = "08:00-09:00";
            this.label195.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_10_11
            // 
            this.lb_Product_Total_10_11.AutoSize = true;
            this.lb_Product_Total_10_11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_10_11.Location = new System.Drawing.Point(115, 78);
            this.lb_Product_Total_10_11.Name = "lb_Product_Total_10_11";
            this.lb_Product_Total_10_11.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_10_11.TabIndex = 31;
            this.lb_Product_Total_10_11.Text = "0";
            this.lb_Product_Total_10_11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_10_11
            // 
            this.lb_Product_NG_10_11.AutoSize = true;
            this.lb_Product_NG_10_11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_10_11.Location = new System.Drawing.Point(162, 78);
            this.lb_Product_NG_10_11.Name = "lb_Product_NG_10_11";
            this.lb_Product_NG_10_11.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_10_11.TabIndex = 30;
            this.lb_Product_NG_10_11.Text = "0";
            this.lb_Product_NG_10_11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_10_11
            // 
            this.lb_Product_Lianglv_10_11.AutoSize = true;
            this.lb_Product_Lianglv_10_11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_10_11.Location = new System.Drawing.Point(209, 78);
            this.lb_Product_Lianglv_10_11.Name = "lb_Product_Lianglv_10_11";
            this.lb_Product_Lianglv_10_11.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_10_11.TabIndex = 29;
            this.lb_Product_Lianglv_10_11.Text = "0";
            this.lb_Product_Lianglv_10_11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label199
            // 
            this.label199.AutoSize = true;
            this.label199.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label199.Location = new System.Drawing.Point(5, 52);
            this.label199.Name = "label199";
            this.label199.Size = new System.Drawing.Size(104, 26);
            this.label199.TabIndex = 17;
            this.label199.Text = "07:00-08:00";
            this.label199.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_09_10
            // 
            this.lb_Product_Total_09_10.AutoSize = true;
            this.lb_Product_Total_09_10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_09_10.Location = new System.Drawing.Point(115, 52);
            this.lb_Product_Total_09_10.Name = "lb_Product_Total_09_10";
            this.lb_Product_Total_09_10.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_09_10.TabIndex = 16;
            this.lb_Product_Total_09_10.Text = "0";
            this.lb_Product_Total_09_10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_09_10
            // 
            this.lb_Product_NG_09_10.AutoSize = true;
            this.lb_Product_NG_09_10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_09_10.Location = new System.Drawing.Point(162, 52);
            this.lb_Product_NG_09_10.Name = "lb_Product_NG_09_10";
            this.lb_Product_NG_09_10.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_09_10.TabIndex = 23;
            this.lb_Product_NG_09_10.Text = "0";
            this.lb_Product_NG_09_10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_09_10
            // 
            this.lb_Product_Lianglv_09_10.AutoSize = true;
            this.lb_Product_Lianglv_09_10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_09_10.Location = new System.Drawing.Point(209, 52);
            this.lb_Product_Lianglv_09_10.Name = "lb_Product_Lianglv_09_10";
            this.lb_Product_Lianglv_09_10.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_09_10.TabIndex = 22;
            this.lb_Product_Lianglv_09_10.Text = "0";
            this.lb_Product_Lianglv_09_10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label203
            // 
            this.label203.AutoSize = true;
            this.label203.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label203.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label203.Location = new System.Drawing.Point(5, 26);
            this.label203.Name = "label203";
            this.label203.Size = new System.Drawing.Size(104, 26);
            this.label203.TabIndex = 10;
            this.label203.Text = "06:00-07:00";
            this.label203.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_08_09
            // 
            this.lb_Product_Total_08_09.AutoSize = true;
            this.lb_Product_Total_08_09.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_08_09.Location = new System.Drawing.Point(115, 26);
            this.lb_Product_Total_08_09.Name = "lb_Product_Total_08_09";
            this.lb_Product_Total_08_09.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_08_09.TabIndex = 9;
            this.lb_Product_Total_08_09.Text = "0";
            this.lb_Product_Total_08_09.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_08_09
            // 
            this.lb_Product_NG_08_09.AutoSize = true;
            this.lb_Product_NG_08_09.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_08_09.Location = new System.Drawing.Point(162, 26);
            this.lb_Product_NG_08_09.Name = "lb_Product_NG_08_09";
            this.lb_Product_NG_08_09.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_08_09.TabIndex = 8;
            this.lb_Product_NG_08_09.Text = "0";
            this.lb_Product_NG_08_09.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_08_09
            // 
            this.lb_Product_Lianglv_08_09.AutoSize = true;
            this.lb_Product_Lianglv_08_09.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_08_09.Location = new System.Drawing.Point(209, 26);
            this.lb_Product_Lianglv_08_09.Name = "lb_Product_Lianglv_08_09";
            this.lb_Product_Lianglv_08_09.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_08_09.TabIndex = 15;
            this.lb_Product_Lianglv_08_09.Text = "0";
            this.lb_Product_Lianglv_08_09.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label207
            // 
            this.label207.AutoSize = true;
            this.label207.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label207.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label207.Location = new System.Drawing.Point(209, 0);
            this.label207.Name = "label207";
            this.label207.Size = new System.Drawing.Size(41, 26);
            this.label207.TabIndex = 3;
            this.label207.Text = "良率";
            this.label207.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label208
            // 
            this.label208.AutoSize = true;
            this.label208.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label208.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label208.Location = new System.Drawing.Point(162, 0);
            this.label208.Name = "label208";
            this.label208.Size = new System.Drawing.Size(41, 26);
            this.label208.TabIndex = 2;
            this.label208.Text = "NG数";
            this.label208.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label209
            // 
            this.label209.AutoSize = true;
            this.label209.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label209.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label209.Location = new System.Drawing.Point(115, 0);
            this.label209.Name = "label209";
            this.label209.Size = new System.Drawing.Size(41, 26);
            this.label209.TabIndex = 1;
            this.label209.Text = "产能";
            this.label209.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label210
            // 
            this.label210.AutoSize = true;
            this.label210.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label210.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label210.Location = new System.Drawing.Point(5, 0);
            this.label210.Name = "label210";
            this.label210.Size = new System.Drawing.Size(104, 26);
            this.label210.TabIndex = 0;
            this.label210.Text = "时间段";
            this.label210.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label211
            // 
            this.label211.AutoSize = true;
            this.label211.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label211.Location = new System.Drawing.Point(471, 0);
            this.label211.Name = "label211";
            this.label211.Size = new System.Drawing.Size(41, 26);
            this.label211.TabIndex = 7;
            this.label211.Text = "良率";
            this.label211.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label212
            // 
            this.label212.AutoSize = true;
            this.label212.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label212.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label212.Location = new System.Drawing.Point(424, 0);
            this.label212.Name = "label212";
            this.label212.Size = new System.Drawing.Size(41, 26);
            this.label212.TabIndex = 6;
            this.label212.Text = "NG数";
            this.label212.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label213
            // 
            this.label213.AutoSize = true;
            this.label213.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label213.Location = new System.Drawing.Point(377, 0);
            this.label213.Name = "label213";
            this.label213.Size = new System.Drawing.Size(41, 26);
            this.label213.TabIndex = 5;
            this.label213.Text = "产能";
            this.label213.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label214
            // 
            this.label214.AutoSize = true;
            this.label214.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label214.Location = new System.Drawing.Point(267, 0);
            this.label214.Name = "label214";
            this.label214.Size = new System.Drawing.Size(104, 26);
            this.label214.TabIndex = 4;
            this.label214.Text = "时间段";
            this.label214.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_20_21
            // 
            this.lb_Product_Lianglv_20_21.AutoSize = true;
            this.lb_Product_Lianglv_20_21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_20_21.Location = new System.Drawing.Point(471, 26);
            this.lb_Product_Lianglv_20_21.Name = "lb_Product_Lianglv_20_21";
            this.lb_Product_Lianglv_20_21.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_20_21.TabIndex = 12;
            this.lb_Product_Lianglv_20_21.Text = "0";
            this.lb_Product_Lianglv_20_21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_20_21
            // 
            this.lb_Product_NG_20_21.AutoSize = true;
            this.lb_Product_NG_20_21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_20_21.Location = new System.Drawing.Point(424, 26);
            this.lb_Product_NG_20_21.Name = "lb_Product_NG_20_21";
            this.lb_Product_NG_20_21.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_20_21.TabIndex = 13;
            this.lb_Product_NG_20_21.Text = "0";
            this.lb_Product_NG_20_21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_20_21
            // 
            this.lb_Product_Total_20_21.AutoSize = true;
            this.lb_Product_Total_20_21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_20_21.Location = new System.Drawing.Point(377, 26);
            this.lb_Product_Total_20_21.Name = "lb_Product_Total_20_21";
            this.lb_Product_Total_20_21.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_20_21.TabIndex = 14;
            this.lb_Product_Total_20_21.Text = "0";
            this.lb_Product_Total_20_21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label218
            // 
            this.label218.AutoSize = true;
            this.label218.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label218.Location = new System.Drawing.Point(267, 26);
            this.label218.Name = "label218";
            this.label218.Size = new System.Drawing.Size(104, 26);
            this.label218.TabIndex = 11;
            this.label218.Text = "18:00-19:00";
            this.label218.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_21_22
            // 
            this.lb_Product_Lianglv_21_22.AutoSize = true;
            this.lb_Product_Lianglv_21_22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_21_22.Location = new System.Drawing.Point(471, 52);
            this.lb_Product_Lianglv_21_22.Name = "lb_Product_Lianglv_21_22";
            this.lb_Product_Lianglv_21_22.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_21_22.TabIndex = 20;
            this.lb_Product_Lianglv_21_22.Text = "0";
            this.lb_Product_Lianglv_21_22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_21_22
            // 
            this.lb_Product_NG_21_22.AutoSize = true;
            this.lb_Product_NG_21_22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_21_22.Location = new System.Drawing.Point(424, 52);
            this.lb_Product_NG_21_22.Name = "lb_Product_NG_21_22";
            this.lb_Product_NG_21_22.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_21_22.TabIndex = 21;
            this.lb_Product_NG_21_22.Text = "0";
            this.lb_Product_NG_21_22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_21_22
            // 
            this.lb_Product_Total_21_22.AutoSize = true;
            this.lb_Product_Total_21_22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_21_22.Location = new System.Drawing.Point(377, 52);
            this.lb_Product_Total_21_22.Name = "lb_Product_Total_21_22";
            this.lb_Product_Total_21_22.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_21_22.TabIndex = 18;
            this.lb_Product_Total_21_22.Text = "0";
            this.lb_Product_Total_21_22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label222
            // 
            this.label222.AutoSize = true;
            this.label222.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label222.Location = new System.Drawing.Point(267, 52);
            this.label222.Name = "label222";
            this.label222.Size = new System.Drawing.Size(104, 26);
            this.label222.TabIndex = 19;
            this.label222.Text = "19:00-20:00";
            this.label222.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_22_23
            // 
            this.lb_Product_Lianglv_22_23.AutoSize = true;
            this.lb_Product_Lianglv_22_23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_22_23.Location = new System.Drawing.Point(471, 78);
            this.lb_Product_Lianglv_22_23.Name = "lb_Product_Lianglv_22_23";
            this.lb_Product_Lianglv_22_23.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_22_23.TabIndex = 28;
            this.lb_Product_Lianglv_22_23.Text = "0";
            this.lb_Product_Lianglv_22_23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_22_23
            // 
            this.lb_Product_NG_22_23.AutoSize = true;
            this.lb_Product_NG_22_23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_22_23.Location = new System.Drawing.Point(424, 78);
            this.lb_Product_NG_22_23.Name = "lb_Product_NG_22_23";
            this.lb_Product_NG_22_23.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_22_23.TabIndex = 25;
            this.lb_Product_NG_22_23.Text = "0";
            this.lb_Product_NG_22_23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label226
            // 
            this.label226.AutoSize = true;
            this.label226.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label226.Location = new System.Drawing.Point(267, 78);
            this.label226.Name = "label226";
            this.label226.Size = new System.Drawing.Size(104, 26);
            this.label226.TabIndex = 27;
            this.label226.Text = "20:00-21:00";
            this.label226.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_23_00
            // 
            this.lb_Product_Lianglv_23_00.AutoSize = true;
            this.lb_Product_Lianglv_23_00.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_23_00.Location = new System.Drawing.Point(471, 104);
            this.lb_Product_Lianglv_23_00.Name = "lb_Product_Lianglv_23_00";
            this.lb_Product_Lianglv_23_00.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_23_00.TabIndex = 32;
            this.lb_Product_Lianglv_23_00.Text = "0";
            this.lb_Product_Lianglv_23_00.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_23_00
            // 
            this.lb_Product_Total_23_00.AutoSize = true;
            this.lb_Product_Total_23_00.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_23_00.Location = new System.Drawing.Point(377, 104);
            this.lb_Product_Total_23_00.Name = "lb_Product_Total_23_00";
            this.lb_Product_Total_23_00.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_23_00.TabIndex = 34;
            this.lb_Product_Total_23_00.Text = "0";
            this.lb_Product_Total_23_00.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label229
            // 
            this.label229.AutoSize = true;
            this.label229.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label229.Location = new System.Drawing.Point(267, 104);
            this.label229.Name = "label229";
            this.label229.Size = new System.Drawing.Size(104, 26);
            this.label229.TabIndex = 35;
            this.label229.Text = "21:00-22:00";
            this.label229.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_00_01
            // 
            this.lb_Product_Lianglv_00_01.AutoSize = true;
            this.lb_Product_Lianglv_00_01.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_00_01.Location = new System.Drawing.Point(471, 130);
            this.lb_Product_Lianglv_00_01.Name = "lb_Product_Lianglv_00_01";
            this.lb_Product_Lianglv_00_01.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_00_01.TabIndex = 47;
            this.lb_Product_Lianglv_00_01.Text = "0";
            this.lb_Product_Lianglv_00_01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_00_01
            // 
            this.lb_Product_NG_00_01.AutoSize = true;
            this.lb_Product_NG_00_01.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_00_01.Location = new System.Drawing.Point(424, 130);
            this.lb_Product_NG_00_01.Name = "lb_Product_NG_00_01";
            this.lb_Product_NG_00_01.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_00_01.TabIndex = 40;
            this.lb_Product_NG_00_01.Text = "0";
            this.lb_Product_NG_00_01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_NG_23_00
            // 
            this.lb_Product_NG_23_00.AutoSize = true;
            this.lb_Product_NG_23_00.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_NG_23_00.Location = new System.Drawing.Point(424, 104);
            this.lb_Product_NG_23_00.Name = "lb_Product_NG_23_00";
            this.lb_Product_NG_23_00.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_NG_23_00.TabIndex = 33;
            this.lb_Product_NG_23_00.Text = "0";
            this.lb_Product_NG_23_00.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_00_01
            // 
            this.lb_Product_Total_00_01.AutoSize = true;
            this.lb_Product_Total_00_01.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_00_01.Location = new System.Drawing.Point(377, 130);
            this.lb_Product_Total_00_01.Name = "lb_Product_Total_00_01";
            this.lb_Product_Total_00_01.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_00_01.TabIndex = 41;
            this.lb_Product_Total_00_01.Text = "0";
            this.lb_Product_Total_00_01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label234
            // 
            this.label234.AutoSize = true;
            this.label234.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label234.Location = new System.Drawing.Point(267, 130);
            this.label234.Name = "label234";
            this.label234.Size = new System.Drawing.Size(104, 26);
            this.label234.TabIndex = 42;
            this.label234.Text = "22:00-23:00";
            this.label234.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Lianglv_12_13
            // 
            this.lb_Product_Lianglv_12_13.AutoSize = true;
            this.lb_Product_Lianglv_12_13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Lianglv_12_13.Location = new System.Drawing.Point(209, 130);
            this.lb_Product_Lianglv_12_13.Name = "lb_Product_Lianglv_12_13";
            this.lb_Product_Lianglv_12_13.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Lianglv_12_13.TabIndex = 43;
            this.lb_Product_Lianglv_12_13.Text = "0";
            this.lb_Product_Lianglv_12_13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_Total_22_23
            // 
            this.lb_Product_Total_22_23.AutoSize = true;
            this.lb_Product_Total_22_23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_Total_22_23.Location = new System.Drawing.Point(377, 78);
            this.lb_Product_Total_22_23.Name = "lb_Product_Total_22_23";
            this.lb_Product_Total_22_23.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_Total_22_23.TabIndex = 112;
            this.lb_Product_Total_22_23.Text = "0";
            this.lb_Product_Total_22_23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label71.Location = new System.Drawing.Point(5, 364);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(104, 26);
            this.label71.TabIndex = 113;
            this.label71.Text = "性能稼动";
            this.label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Product_propery
            // 
            this.lb_Product_propery.AutoSize = true;
            this.lb_Product_propery.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Product_propery.Location = new System.Drawing.Point(115, 364);
            this.lb_Product_propery.Name = "lb_Product_propery";
            this.lb_Product_propery.Size = new System.Drawing.Size(41, 26);
            this.lb_Product_propery.TabIndex = 114;
            this.lb_Product_propery.Text = "0.0％";
            this.lb_Product_propery.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 4;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34F));
            this.tableLayoutPanel7.Controls.Add(this.dtp_UPH_Data, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.btn_SelectProductData, 2, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(713, 44);
            this.tableLayoutPanel7.TabIndex = 0;
            // 
            // dtp_UPH_Data
            // 
            this.dtp_UPH_Data.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dtp_UPH_Data.CalendarFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.dtp_UPH_Data.CustomFormat = "yyyy年MM月dd日";
            this.dtp_UPH_Data.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.dtp_UPH_Data.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_UPH_Data.Location = new System.Drawing.Point(242, 7);
            this.dtp_UPH_Data.Margin = new System.Windows.Forms.Padding(0);
            this.dtp_UPH_Data.Name = "dtp_UPH_Data";
            this.dtp_UPH_Data.Size = new System.Drawing.Size(156, 29);
            this.dtp_UPH_Data.TabIndex = 16;
            this.dtp_UPH_Data.ValueChanged += new System.EventHandler(this.dtp_UPH_Data_ValueChanged);
            // 
            // btn_SelectProductData
            // 
            this.btn_SelectProductData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_SelectProductData.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.btn_SelectProductData.Location = new System.Drawing.Point(401, 3);
            this.btn_SelectProductData.Name = "btn_SelectProductData";
            this.btn_SelectProductData.Size = new System.Drawing.Size(65, 38);
            this.btn_SelectProductData.TabIndex = 17;
            this.btn_SelectProductData.Text = "查询";
            this.btn_SelectProductData.UseVisualStyleBackColor = true;
            this.btn_SelectProductData.Click += new System.EventHandler(this.btn_SelectProductData_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage10);
            this.tabControl1.Controls.Add(this.tabPage11);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.tabControl1.ItemSize = new System.Drawing.Size(30, 120);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(861, 500);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 5;
            this.tabControl1.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.tabControl1_DrawItem);
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.splitContainer1);
            this.tabPage11.Location = new System.Drawing.Point(124, 4);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(733, 492);
            this.tabPage11.TabIndex = 4;
            this.tabPage11.Text = "抛料统计";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer3);
            this.splitContainer1.Size = new System.Drawing.Size(727, 486);
            this.splitContainer1.SplitterDistance = 273;
            this.splitContainer1.TabIndex = 0;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.tableLayoutPanel23);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.tableLayoutPanel24);
            this.splitContainer2.Size = new System.Drawing.Size(727, 273);
            this.splitContainer2.SplitterDistance = 37;
            this.splitContainer2.TabIndex = 0;
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.ColumnCount = 7;
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 48.63813F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 51.36187F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 52F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 135F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 63F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 84F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 156F));
            this.tableLayoutPanel23.Controls.Add(this.textBox2, 4, 0);
            this.tableLayoutPanel23.Controls.Add(this.label15, 0, 0);
            this.tableLayoutPanel23.Controls.Add(this.label16, 1, 0);
            this.tableLayoutPanel23.Controls.Add(this.textBox1, 2, 0);
            this.tableLayoutPanel23.Controls.Add(this.label17, 3, 0);
            this.tableLayoutPanel23.Controls.Add(this.button1, 5, 0);
            this.tableLayoutPanel23.Controls.Add(this.checkBox1, 6, 0);
            this.tableLayoutPanel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel23.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 1;
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(727, 37);
            this.tableLayoutPanel23.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox2.Location = new System.Drawing.Point(434, 8);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(40, 21);
            this.textBox2.TabIndex = 4;
            this.textBox2.Text = "5";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Location = new System.Drawing.Point(3, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(109, 37);
            this.label15.TabIndex = 0;
            this.label15.Text = "参数设置";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Location = new System.Drawing.Point(118, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(115, 37);
            this.label16.TabIndex = 1;
            this.label16.Text = "连续NG次数上限";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox1.Location = new System.Drawing.Point(239, 8);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(46, 21);
            this.textBox1.TabIndex = 2;
            this.textBox1.Text = "3";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(311, 12);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(89, 12);
            this.label17.TabIndex = 3;
            this.label17.Text = "累计NG次数上限";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.Location = new System.Drawing.Point(489, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(78, 25);
            this.button1.TabIndex = 5;
            this.button1.Text = "设置";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(588, 10);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(120, 16);
            this.checkBox1.TabIndex = 6;
            this.checkBox1.Text = "双击清除次数启用";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel24
            // 
            this.tableLayoutPanel24.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel24.ColumnCount = 5;
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanel24.Controls.Add(this.label69, 4, 4);
            this.tableLayoutPanel24.Controls.Add(this.label68, 3, 4);
            this.tableLayoutPanel24.Controls.Add(this.label67, 2, 4);
            this.tableLayoutPanel24.Controls.Add(this.label65, 1, 4);
            this.tableLayoutPanel24.Controls.Add(this.label64, 0, 4);
            this.tableLayoutPanel24.Controls.Add(this.label63, 4, 3);
            this.tableLayoutPanel24.Controls.Add(this.label61, 3, 3);
            this.tableLayoutPanel24.Controls.Add(this.label60, 2, 3);
            this.tableLayoutPanel24.Controls.Add(this.label59, 1, 3);
            this.tableLayoutPanel24.Controls.Add(this.label57, 0, 3);
            this.tableLayoutPanel24.Controls.Add(this.label37, 4, 2);
            this.tableLayoutPanel24.Controls.Add(this.label36, 3, 2);
            this.tableLayoutPanel24.Controls.Add(this.label35, 2, 2);
            this.tableLayoutPanel24.Controls.Add(this.label33, 1, 2);
            this.tableLayoutPanel24.Controls.Add(this.label32, 0, 2);
            this.tableLayoutPanel24.Controls.Add(this.label31, 4, 1);
            this.tableLayoutPanel24.Controls.Add(this.label30, 3, 1);
            this.tableLayoutPanel24.Controls.Add(this.label28, 2, 1);
            this.tableLayoutPanel24.Controls.Add(this.label27, 1, 1);
            this.tableLayoutPanel24.Controls.Add(this.label25, 0, 1);
            this.tableLayoutPanel24.Controls.Add(this.label24, 4, 0);
            this.tableLayoutPanel24.Controls.Add(this.label23, 3, 0);
            this.tableLayoutPanel24.Controls.Add(this.label22, 2, 0);
            this.tableLayoutPanel24.Controls.Add(this.label21, 1, 0);
            this.tableLayoutPanel24.Controls.Add(this.label19, 0, 0);
            this.tableLayoutPanel24.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel24.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel24.Name = "tableLayoutPanel24";
            this.tableLayoutPanel24.RowCount = 5;
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel24.Size = new System.Drawing.Size(727, 140);
            this.tableLayoutPanel24.TabIndex = 0;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.BackColor = System.Drawing.Color.Transparent;
            this.label69.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label69.ForeColor = System.Drawing.Color.Black;
            this.label69.Location = new System.Drawing.Point(637, 109);
            this.label69.Margin = new System.Windows.Forms.Padding(0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(89, 30);
            this.label69.TabIndex = 24;
            this.label69.Text = "OK";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label68.Location = new System.Drawing.Point(478, 109);
            this.label68.Margin = new System.Windows.Forms.Padding(0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(158, 30);
            this.label68.TabIndex = 23;
            this.label68.Text = "0";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label68.DoubleClick += new System.EventHandler(this.label28_DoubleClick);
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label67.Location = new System.Drawing.Point(319, 109);
            this.label67.Margin = new System.Windows.Forms.Padding(0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(158, 30);
            this.label67.TabIndex = 22;
            this.label67.Text = "0";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label67.DoubleClick += new System.EventHandler(this.label28_DoubleClick);
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label65.Location = new System.Drawing.Point(163, 109);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(152, 30);
            this.label65.TabIndex = 21;
            this.label65.Text = "2号";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label64.Location = new System.Drawing.Point(4, 109);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(152, 30);
            this.label64.TabIndex = 20;
            this.label64.Text = "2#";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.BackColor = System.Drawing.Color.Transparent;
            this.label63.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label63.ForeColor = System.Drawing.Color.Black;
            this.label63.Location = new System.Drawing.Point(637, 82);
            this.label63.Margin = new System.Windows.Forms.Padding(0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(89, 26);
            this.label63.TabIndex = 19;
            this.label63.Text = "OK";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label61.Location = new System.Drawing.Point(478, 82);
            this.label61.Margin = new System.Windows.Forms.Padding(0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(158, 26);
            this.label61.TabIndex = 18;
            this.label61.Text = "0";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label61.DoubleClick += new System.EventHandler(this.label28_DoubleClick);
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label60.Location = new System.Drawing.Point(319, 82);
            this.label60.Margin = new System.Windows.Forms.Padding(0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(158, 26);
            this.label60.TabIndex = 17;
            this.label60.Text = "0";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label60.DoubleClick += new System.EventHandler(this.label28_DoubleClick);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label59.Location = new System.Drawing.Point(163, 82);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(152, 26);
            this.label59.TabIndex = 16;
            this.label59.Text = "1号";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label57.Location = new System.Drawing.Point(4, 82);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(152, 26);
            this.label57.TabIndex = 15;
            this.label57.Text = "2#";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.Color.Transparent;
            this.label37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label37.ForeColor = System.Drawing.Color.Black;
            this.label37.Location = new System.Drawing.Point(637, 55);
            this.label37.Margin = new System.Windows.Forms.Padding(0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(89, 26);
            this.label37.TabIndex = 14;
            this.label37.Text = "OK";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label36.Location = new System.Drawing.Point(478, 55);
            this.label36.Margin = new System.Windows.Forms.Padding(0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(158, 26);
            this.label36.TabIndex = 13;
            this.label36.Text = "0";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label36.DoubleClick += new System.EventHandler(this.label28_DoubleClick);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label35.Location = new System.Drawing.Point(319, 55);
            this.label35.Margin = new System.Windows.Forms.Padding(0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(158, 26);
            this.label35.TabIndex = 12;
            this.label35.Text = "0";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label35.DoubleClick += new System.EventHandler(this.label28_DoubleClick);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label33.Location = new System.Drawing.Point(163, 55);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(152, 26);
            this.label33.TabIndex = 11;
            this.label33.Text = "2号";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label32.Location = new System.Drawing.Point(4, 55);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(152, 26);
            this.label32.TabIndex = 10;
            this.label32.Text = "1#";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.Transparent;
            this.label31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label31.ForeColor = System.Drawing.Color.Black;
            this.label31.Location = new System.Drawing.Point(637, 28);
            this.label31.Margin = new System.Windows.Forms.Padding(0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(89, 26);
            this.label31.TabIndex = 9;
            this.label31.Text = "OK";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label30.Location = new System.Drawing.Point(478, 28);
            this.label30.Margin = new System.Windows.Forms.Padding(0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(158, 26);
            this.label30.TabIndex = 8;
            this.label30.Text = "0";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label30.DoubleClick += new System.EventHandler(this.label28_DoubleClick);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label28.Location = new System.Drawing.Point(319, 28);
            this.label28.Margin = new System.Windows.Forms.Padding(0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(158, 26);
            this.label28.TabIndex = 7;
            this.label28.Text = "0";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label28.DoubleClick += new System.EventHandler(this.label28_DoubleClick);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.Location = new System.Drawing.Point(163, 28);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(152, 26);
            this.label27.TabIndex = 6;
            this.label27.Text = "1号";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.Location = new System.Drawing.Point(4, 28);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(152, 26);
            this.label25.TabIndex = 5;
            this.label25.Text = "1#";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.label24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label24.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold);
            this.label24.Location = new System.Drawing.Point(637, 1);
            this.label24.Margin = new System.Windows.Forms.Padding(0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(89, 26);
            this.label24.TabIndex = 4;
            this.label24.Text = "状态";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.label23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label23.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold);
            this.label23.Location = new System.Drawing.Point(478, 1);
            this.label23.Margin = new System.Windows.Forms.Padding(0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(158, 26);
            this.label23.TabIndex = 3;
            this.label23.Text = "累计NG次数";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold);
            this.label22.Location = new System.Drawing.Point(319, 1);
            this.label22.Margin = new System.Windows.Forms.Padding(0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(158, 26);
            this.label22.TabIndex = 2;
            this.label22.Text = "连续NG次数";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold);
            this.label21.Location = new System.Drawing.Point(160, 1);
            this.label21.Margin = new System.Windows.Forms.Padding(0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(158, 26);
            this.label21.TabIndex = 1;
            this.label21.Text = "电批";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold);
            this.label19.Location = new System.Drawing.Point(1, 1);
            this.label19.Margin = new System.Windows.Forms.Padding(0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(158, 26);
            this.label19.TabIndex = 0;
            this.label19.Text = "运送";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.tableLayoutPanel25);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.dataGridView1);
            this.splitContainer3.Panel2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.splitContainer3.Size = new System.Drawing.Size(727, 209);
            this.splitContainer3.SplitterDistance = 43;
            this.splitContainer3.TabIndex = 0;
            // 
            // tableLayoutPanel25
            // 
            this.tableLayoutPanel25.ColumnCount = 6;
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38.53503F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 61.46497F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 155F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 79F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 82F));
            this.tableLayoutPanel25.Controls.Add(this.dateTimePicker1, 1, 0);
            this.tableLayoutPanel25.Controls.Add(this.dateTimePicker2, 3, 0);
            this.tableLayoutPanel25.Controls.Add(this.button3, 5, 0);
            this.tableLayoutPanel25.Controls.Add(this.button2, 4, 0);
            this.tableLayoutPanel25.Controls.Add(this.label72, 2, 0);
            this.tableLayoutPanel25.Controls.Add(this.label73, 0, 0);
            this.tableLayoutPanel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel25.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel25.Name = "tableLayoutPanel25";
            this.tableLayoutPanel25.RowCount = 1;
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel25.Size = new System.Drawing.Size(727, 43);
            this.tableLayoutPanel25.TabIndex = 0;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateTimePicker1.Location = new System.Drawing.Point(126, 11);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(149, 21);
            this.dateTimePicker1.TabIndex = 13;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateTimePicker2.Location = new System.Drawing.Point(413, 11);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(149, 21);
            this.dateTimePicker2.TabIndex = 11;
            // 
            // button3
            // 
            this.button3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button3.Location = new System.Drawing.Point(647, 9);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(76, 25);
            this.button3.TabIndex = 7;
            this.button3.Text = "导出";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button2.Location = new System.Drawing.Point(568, 9);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(73, 25);
            this.button2.TabIndex = 6;
            this.button2.Text = "查询";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label72.Location = new System.Drawing.Point(293, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(114, 43);
            this.label72.TabIndex = 8;
            this.label72.Text = "结束时间";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label73.Location = new System.Drawing.Point(3, 0);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(106, 43);
            this.label73.TabIndex = 12;
            this.label73.Text = "开始时间";
            this.label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dataGridView1
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeight = 25;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column4,
            this.Column5,
            this.Column9,
            this.Column6,
            this.Column7,
            this.Column8});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 200;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridView1.RowTemplate.Height = 40;
            this.dataGridView1.Size = new System.Drawing.Size(727, 162);
            this.dataGridView1.TabIndex = 0;
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column4.HeaderText = "序号";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 54;
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column5.HeaderText = "时间";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 54;
            // 
            // Column9
            // 
            this.Column9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column9.HeaderText = "运送";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.Width = 54;
            // 
            // Column6
            // 
            this.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column6.HeaderText = "电批";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 54;
            // 
            // Column7
            // 
            this.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column7.HeaderText = "连续抛料次数";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Width = 102;
            // 
            // Column8
            // 
            this.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column8.HeaderText = "累计抛料次数";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Width = 102;
            // 
            // DataStatisticsFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(861, 500);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DataStatisticsFrm";
            this.Text = "DataStatisticsFrm";
            this.Load += new System.EventHandler(this.DataStatisticsFrm_Load);
            this.tabPage10.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tableLayoutPanel16.ResumeLayout(false);
            this.tableLayoutPanel17.ResumeLayout(false);
            this.tableLayoutPanel17.PerformLayout();
            this.tableLayoutPanel18.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart_FixtureErrorNumber)).EndInit();
            this.tableLayoutPanel19.ResumeLayout(false);
            this.tableLayoutPanel19.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart_DT)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.tableLayoutPanel15.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel14.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart_UPH)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel22.ResumeLayout(false);
            this.tableLayoutPanel22.PerformLayout();
            this.tableLayoutPanel20.ResumeLayout(false);
            this.tableLayoutPanel20.PerformLayout();
            this.tableLayoutPanel21.ResumeLayout(false);
            this.tabControl4.ResumeLayout(false);
            this.tabPage8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_D)).EndInit();
            this.tabPage9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_N)).EndInit();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel11.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage11.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.tableLayoutPanel23.ResumeLayout(false);
            this.tableLayoutPanel23.PerformLayout();
            this.tableLayoutPanel24.ResumeLayout(false);
            this.tableLayoutPanel24.PerformLayout();
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.tableLayoutPanel25.ResumeLayout(false);
            this.tableLayoutPanel25.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel16;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel17;
        private System.Windows.Forms.DateTimePicker dtp_FixtureErrorTOP5Time;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Button btn_SelectFixtureError;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_FixtureErrorNumber;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel19;
        private System.Windows.Forms.Label lb_Number5;
        private System.Windows.Forms.Label lb_FixtureCode5;
        private System.Windows.Forms.Label lb_Number4;
        private System.Windows.Forms.Label lb_FixtureCode4;
        private System.Windows.Forms.Label lb_Number3;
        private System.Windows.Forms.Label lb_FixtureCode3;
        private System.Windows.Forms.Label lb_Number2;
        private System.Windows.Forms.Label lb_FixtureCode2;
        private System.Windows.Forms.Label lb_Number1;
        private System.Windows.Forms.Label lb_FixtureCode1;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.DateTimePicker dtp_DT_Table;
        private System.Windows.Forms.Button btn_SelectDTTable;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_DT;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.DateTimePicker dtp_DT_Data;
        private System.Windows.Forms.Button btn_SelectDTData;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label lb_Product_time;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label lb_RunTime_08_20;
        private System.Windows.Forms.Label lb_ErrorTime_08_20;
        private System.Windows.Forms.Label lb_PendingTime_08_20;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label lb_RunTime_20_08;
        private System.Windows.Forms.Label lb_ErrorTime_20_08;
        private System.Windows.Forms.Label lb_PendingTime_20_08;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label lb_RunTime_19_20;
        private System.Windows.Forms.Label lb_ErrorTime_19_20;
        private System.Windows.Forms.Label lb_PendingTime_19_20;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label lb_RunTime_07_08;
        private System.Windows.Forms.Label lb_ErrorTime_07_08;
        private System.Windows.Forms.Label lb_PendingTime_07_08;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label lb_RunTime_18_19;
        private System.Windows.Forms.Label lb_ErrorTime_18_19;
        private System.Windows.Forms.Label lb_PendingTime_18_19;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label lb_RunTime_06_07;
        private System.Windows.Forms.Label lb_ErrorTime_06_07;
        private System.Windows.Forms.Label lb_PendingTime_06_07;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label lb_RunTime_17_18;
        private System.Windows.Forms.Label lb_ErrorTime_17_18;
        private System.Windows.Forms.Label lb_PendingTime_17_18;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label lb_RunTime_05_06;
        private System.Windows.Forms.Label lb_ErrorTime_05_06;
        private System.Windows.Forms.Label lb_PendingTime_05_06;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label lb_RunTime_16_17;
        private System.Windows.Forms.Label lb_ErrorTime_16_17;
        private System.Windows.Forms.Label lb_PendingTime_16_17;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label lb_RunTime_04_05;
        private System.Windows.Forms.Label lb_ErrorTime_04_05;
        private System.Windows.Forms.Label lb_PendingTime_04_05;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label lb_RunTime_15_16;
        private System.Windows.Forms.Label lb_ErrorTime_15_16;
        private System.Windows.Forms.Label lb_PendingTime_15_16;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label lb_RunTime_03_04;
        private System.Windows.Forms.Label lb_ErrorTime_03_04;
        private System.Windows.Forms.Label lb_PendingTime_03_04;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label lb_RunTime_14_15;
        private System.Windows.Forms.Label lb_ErrorTime_14_15;
        private System.Windows.Forms.Label lb_PendingTime_14_15;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label lb_RunTime_02_03;
        private System.Windows.Forms.Label lb_ErrorTime_02_03;
        private System.Windows.Forms.Label lb_PendingTime_02_03;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label lb_RunTime_13_14;
        private System.Windows.Forms.Label lb_ErrorTime_13_14;
        private System.Windows.Forms.Label lb_PendingTime_13_14;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label lb_RunTime_01_02;
        private System.Windows.Forms.Label lb_ErrorTime_01_02;
        private System.Windows.Forms.Label lb_PendingTime_01_02;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label lb_RunTime_12_13;
        private System.Windows.Forms.Label lb_ErrorTime_12_13;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label lb_RunTime_11_12;
        private System.Windows.Forms.Label lb_ErrorTime_11_12;
        private System.Windows.Forms.Label lb_PendingTime_11_12;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label lb_RunTime_10_11;
        private System.Windows.Forms.Label lb_ErrorTime_10_11;
        private System.Windows.Forms.Label lb_PendingTime_10_11;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lb_RunTime_09_10;
        private System.Windows.Forms.Label lb_ErrorTime_09_10;
        private System.Windows.Forms.Label lb_PendingTime_09_10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lb_RunTime_08_09;
        private System.Windows.Forms.Label lb_ErrorTime_08_09;
        private System.Windows.Forms.Label lb_PendingTime_08_09;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lb_PendingTime_20_21;
        private System.Windows.Forms.Label lb_ErrorTime_20_21;
        private System.Windows.Forms.Label lb_RunTime_20_21;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lb_PendingTime_21_22;
        private System.Windows.Forms.Label lb_ErrorTime_21_22;
        private System.Windows.Forms.Label lb_RunTime_21_22;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lb_PendingTime_22_23;
        private System.Windows.Forms.Label lb_ErrorTime_22_23;
        private System.Windows.Forms.Label lb_RunTime_22_23;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label lb_PendingTime_23_00;
        private System.Windows.Forms.Label lb_RunTime_23_00;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label lb_PendingTime_00_01;
        private System.Windows.Forms.Label lb_ErrorTime_00_01;
        private System.Windows.Forms.Label lb_ErrorTime_23_00;
        private System.Windows.Forms.Label lb_RunTime_00_01;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label lb_PendingTime_12_13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lb_Product_time_N1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.TextBox txt_CT1;
        private System.Windows.Forms.TextBox txt_AverageCT10;
        private System.Windows.Forms.TextBox txt_CT10;
        private System.Windows.Forms.TextBox txt_CT9;
        private System.Windows.Forms.TextBox txt_CT8;
        private System.Windows.Forms.TextBox txt_CT7;
        private System.Windows.Forms.TextBox txt_CT6;
        private System.Windows.Forms.TextBox txt_CT5;
        private System.Windows.Forms.TextBox txt_CT4;
        private System.Windows.Forms.TextBox txt_CT3;
        private System.Windows.Forms.TextBox txt_CT2;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.DateTimePicker dtp_UPH_Table;
        private System.Windows.Forms.Button btn_SelectProductTable;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_UPH;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel22;
        private System.Windows.Forms.RadioButton PF;
        private System.Windows.Forms.RadioButton Yield;
        private System.Windows.Forms.RadioButton All;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel20;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel21;
        private System.Windows.Forms.DateTimePicker EndDay;
        private System.Windows.Forms.DateTimePicker StartDay;
        private System.Windows.Forms.Button outError;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.DataGridView dgv_D;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.DataGridView dgv_N;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.Label lb_Product_propery_N1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label lb_Product_Total_08_20;
        private System.Windows.Forms.Label lb_Product_NG_08_20;
        private System.Windows.Forms.Label lb_Product_Lianglv_08_20;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label lb_Product_Total_20_08;
        private System.Windows.Forms.Label lb_Product_NG_20_08;
        private System.Windows.Forms.Label lb_Product_Lianglv_20_08;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label lb_Product_Total_19_20;
        private System.Windows.Forms.Label lb_Product_NG_19_20;
        private System.Windows.Forms.Label lb_Product_Lianglv_19_20;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.Label lb_Product_Total_07_08;
        private System.Windows.Forms.Label lb_Product_NG_07_08;
        private System.Windows.Forms.Label lb_Product_Lianglv_07_08;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Label lb_Product_Total_18_19;
        private System.Windows.Forms.Label lb_Product_NG_18_19;
        private System.Windows.Forms.Label lb_Product_Lianglv_18_19;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.Label lb_Product_Total_06_07;
        private System.Windows.Forms.Label lb_Product_NG_06_07;
        private System.Windows.Forms.Label lb_Product_Lianglv_06_07;
        private System.Windows.Forms.Label label148;
        private System.Windows.Forms.Label lb_Product_Total_17_18;
        private System.Windows.Forms.Label lb_Product_NG_17_18;
        private System.Windows.Forms.Label lb_Product_Lianglv_17_18;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.Label lb_Product_Total_05_06;
        private System.Windows.Forms.Label lb_Product_NG_05_06;
        private System.Windows.Forms.Label lb_Product_Lianglv_05_06;
        private System.Windows.Forms.Label label156;
        private System.Windows.Forms.Label lb_Product_Total_16_17;
        private System.Windows.Forms.Label lb_Product_NG_16_17;
        private System.Windows.Forms.Label lb_Product_Lianglv_16_17;
        private System.Windows.Forms.Label label160;
        private System.Windows.Forms.Label lb_Product_Total_04_05;
        private System.Windows.Forms.Label lb_Product_NG_04_05;
        private System.Windows.Forms.Label lb_Product_Lianglv_04_05;
        private System.Windows.Forms.Label label164;
        private System.Windows.Forms.Label lb_Product_Total_15_16;
        private System.Windows.Forms.Label lb_Product_NG_15_16;
        private System.Windows.Forms.Label lb_Product_Lianglv_15_16;
        private System.Windows.Forms.Label label168;
        private System.Windows.Forms.Label lb_Product_Total_03_04;
        private System.Windows.Forms.Label lb_Product_NG_03_04;
        private System.Windows.Forms.Label lb_Product_Lianglv_03_04;
        private System.Windows.Forms.Label label172;
        private System.Windows.Forms.Label lb_Product_Total_14_15;
        private System.Windows.Forms.Label lb_Product_NG_14_15;
        private System.Windows.Forms.Label lb_Product_Lianglv_14_15;
        private System.Windows.Forms.Label label176;
        private System.Windows.Forms.Label lb_Product_Total_02_03;
        private System.Windows.Forms.Label lb_Product_NG_02_03;
        private System.Windows.Forms.Label lb_Product_Lianglv_02_03;
        private System.Windows.Forms.Label label180;
        private System.Windows.Forms.Label lb_Product_Total_13_14;
        private System.Windows.Forms.Label lb_Product_NG_13_14;
        private System.Windows.Forms.Label lb_Product_Lianglv_13_14;
        private System.Windows.Forms.Label label184;
        private System.Windows.Forms.Label lb_Product_Total_01_02;
        private System.Windows.Forms.Label lb_Product_NG_01_02;
        private System.Windows.Forms.Label lb_Product_Lianglv_01_02;
        private System.Windows.Forms.Label label188;
        private System.Windows.Forms.Label lb_Product_Total_12_13;
        private System.Windows.Forms.Label lb_Product_NG_12_13;
        private System.Windows.Forms.Label label191;
        private System.Windows.Forms.Label lb_Product_Total_11_12;
        private System.Windows.Forms.Label lb_Product_NG_11_12;
        private System.Windows.Forms.Label lb_Product_Lianglv_11_12;
        private System.Windows.Forms.Label label195;
        private System.Windows.Forms.Label lb_Product_Total_10_11;
        private System.Windows.Forms.Label lb_Product_NG_10_11;
        private System.Windows.Forms.Label lb_Product_Lianglv_10_11;
        private System.Windows.Forms.Label label199;
        private System.Windows.Forms.Label lb_Product_Total_09_10;
        private System.Windows.Forms.Label lb_Product_NG_09_10;
        private System.Windows.Forms.Label lb_Product_Lianglv_09_10;
        private System.Windows.Forms.Label label203;
        private System.Windows.Forms.Label lb_Product_Total_08_09;
        private System.Windows.Forms.Label lb_Product_NG_08_09;
        private System.Windows.Forms.Label lb_Product_Lianglv_08_09;
        private System.Windows.Forms.Label label207;
        private System.Windows.Forms.Label label208;
        private System.Windows.Forms.Label label209;
        private System.Windows.Forms.Label label210;
        private System.Windows.Forms.Label label211;
        private System.Windows.Forms.Label label212;
        private System.Windows.Forms.Label label213;
        private System.Windows.Forms.Label label214;
        private System.Windows.Forms.Label lb_Product_Lianglv_20_21;
        private System.Windows.Forms.Label lb_Product_NG_20_21;
        private System.Windows.Forms.Label lb_Product_Total_20_21;
        private System.Windows.Forms.Label label218;
        private System.Windows.Forms.Label lb_Product_Lianglv_21_22;
        private System.Windows.Forms.Label lb_Product_NG_21_22;
        private System.Windows.Forms.Label lb_Product_Total_21_22;
        private System.Windows.Forms.Label label222;
        private System.Windows.Forms.Label lb_Product_Lianglv_22_23;
        private System.Windows.Forms.Label lb_Product_NG_22_23;
        private System.Windows.Forms.Label label226;
        private System.Windows.Forms.Label lb_Product_Lianglv_23_00;
        private System.Windows.Forms.Label lb_Product_Total_23_00;
        private System.Windows.Forms.Label label229;
        private System.Windows.Forms.Label lb_Product_Lianglv_00_01;
        private System.Windows.Forms.Label lb_Product_NG_00_01;
        private System.Windows.Forms.Label lb_Product_NG_23_00;
        private System.Windows.Forms.Label lb_Product_Total_00_01;
        private System.Windows.Forms.Label label234;
        private System.Windows.Forms.Label lb_Product_Lianglv_12_13;
        private System.Windows.Forms.Label lb_Product_Total_22_23;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label lb_Product_propery;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.DateTimePicker dtp_UPH_Data;
        private System.Windows.Forms.Button btn_SelectProductData;
        public System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel23;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel24;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel25;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
    }
}