﻿using System.Windows.Forms;

namespace 卓汇数据追溯系统
{
    partial class frmManual
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.stcManual = new DevComponents.DotNetBar.SuperTabControl();
            this.superTabControlPanel6 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.tabCtlDplus = new DevComponents.DotNetBar.SuperTabControl();
            this.tabCtlPanelReal = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.panelReal = new System.Windows.Forms.Panel();
            this.panelRealWave = new System.Windows.Forms.Panel();
            this.gPanelRealWave = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.scottRealWaveR = new ScottPlot.FormsPlot();
            this.scottRealWaveL = new ScottPlot.FormsPlot();
            this.lbRealWaveTitle = new System.Windows.Forms.Label();
            this.panelBottomRealWave = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.groupPanel6 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.dplusRTB = new System.Windows.Forms.RichTextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label47 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.tabItemReal = new DevComponents.DotNetBar.SuperTabItem();
            this.tabCtlPanelHistoryWave = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.panelHistoryResult = new System.Windows.Forms.Panel();
            this.panelHistoryWave = new System.Windows.Forms.Panel();
            this.scottRealWave3 = new ScottPlot.FormsPlot();
            this.scottRealWave2 = new ScottPlot.FormsPlot();
            this.scottRealWave1 = new ScottPlot.FormsPlot();
            this.panelHistoryDplus = new System.Windows.Forms.Panel();
            this.lbScrewNo3 = new System.Windows.Forms.Label();
            this.lbAlarm3 = new System.Windows.Forms.Label();
            this.lbTightenStatus3 = new System.Windows.Forms.Label();
            this.lbTotalMsecTime3 = new System.Windows.Forms.Label();
            this.lbMaxTorque3 = new System.Windows.Forms.Label();
            this.lbCycles3 = new System.Windows.Forms.Label();
            this.lbScrewNo2 = new System.Windows.Forms.Label();
            this.lbAlarm2 = new System.Windows.Forms.Label();
            this.lbTightenStatus2 = new System.Windows.Forms.Label();
            this.lbTotalMsecTime2 = new System.Windows.Forms.Label();
            this.lbMaxTorque2 = new System.Windows.Forms.Label();
            this.lbCycles2 = new System.Windows.Forms.Label();
            this.lbScrewNo1 = new System.Windows.Forms.Label();
            this.lbTitleScrewNo = new System.Windows.Forms.Label();
            this.lbAlarm1 = new System.Windows.Forms.Label();
            this.lbTightenStatus1 = new System.Windows.Forms.Label();
            this.lbTotalMsecTime1 = new System.Windows.Forms.Label();
            this.lbMaxTorque1 = new System.Windows.Forms.Label();
            this.lbCycles1 = new System.Windows.Forms.Label();
            this.lbTitleAlarm = new System.Windows.Forms.Label();
            this.lbTitleTightenStatus = new System.Windows.Forms.Label();
            this.lbTitleTotalMsecTime = new System.Windows.Forms.Label();
            this.lbTitleMaxTorque = new System.Windows.Forms.Label();
            this.lbTitleCycles = new System.Windows.Forms.Label();
            this.panelHistoryQuery = new System.Windows.Forms.Panel();
            this.btnQueryWave = new System.Windows.Forms.Button();
            this.txbBandSnWave = new System.Windows.Forms.TextBox();
            this.lbpanelHistoryBandSN = new System.Windows.Forms.Label();
            this.tabItemHistory = new DevComponents.DotNetBar.SuperTabItem();
            this.stiDPlusManual = new DevComponents.DotNetBar.SuperTabItem();
            ((System.ComponentModel.ISupportInitialize)(this.stcManual)).BeginInit();
            this.stcManual.SuspendLayout();
            this.superTabControlPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabCtlDplus)).BeginInit();
            this.tabCtlDplus.SuspendLayout();
            this.tabCtlPanelReal.SuspendLayout();
            this.panelReal.SuspendLayout();
            this.panelRealWave.SuspendLayout();
            this.gPanelRealWave.SuspendLayout();
            this.panel11.SuspendLayout();
            this.groupPanel6.SuspendLayout();
            this.panel10.SuspendLayout();
            this.tabCtlPanelHistoryWave.SuspendLayout();
            this.panelHistoryResult.SuspendLayout();
            this.panelHistoryWave.SuspendLayout();
            this.panelHistoryDplus.SuspendLayout();
            this.panelHistoryQuery.SuspendLayout();
            this.SuspendLayout();
            // 
            // stcManual
            // 
            this.stcManual.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            // 
            // 
            // 
            this.stcManual.ControlBox.CloseBox.Name = "";
            // 
            // 
            // 
            this.stcManual.ControlBox.MenuBox.Name = "";
            this.stcManual.ControlBox.Name = "";
            this.stcManual.ControlBox.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.stcManual.ControlBox.MenuBox,
            this.stcManual.ControlBox.CloseBox});
            this.stcManual.Controls.Add(this.superTabControlPanel6);
            this.stcManual.Dock = System.Windows.Forms.DockStyle.Fill;
            this.stcManual.ForeColor = System.Drawing.Color.Black;
            this.stcManual.Location = new System.Drawing.Point(0, 0);
            this.stcManual.Name = "stcManual";
            this.stcManual.ReorderTabsEnabled = true;
            this.stcManual.SelectedTabFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold);
            this.stcManual.SelectedTabIndex = 0;
            this.stcManual.Size = new System.Drawing.Size(1028, 583);
            this.stcManual.TabAlignment = DevComponents.DotNetBar.eTabStripAlignment.Bottom;
            this.stcManual.TabFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.stcManual.TabIndex = 40;
            this.stcManual.Tabs.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.stiDPlusManual});
            this.stcManual.TabsVisible = false;
            // 
            // superTabControlPanel6
            // 
            this.superTabControlPanel6.Controls.Add(this.tabCtlDplus);
            this.superTabControlPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel6.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel6.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.superTabControlPanel6.Name = "superTabControlPanel6";
            this.superTabControlPanel6.Size = new System.Drawing.Size(1028, 583);
            this.superTabControlPanel6.TabIndex = 0;
            this.superTabControlPanel6.TabItem = this.stiDPlusManual;
            // 
            // tabCtlDplus
            // 
            this.tabCtlDplus.AutoCloseTabs = false;
            this.tabCtlDplus.CloseButtonOnTabsAlwaysDisplayed = false;
            // 
            // 
            // 
            // 
            // 
            // 
            this.tabCtlDplus.ControlBox.CloseBox.Name = "";
            // 
            // 
            // 
            this.tabCtlDplus.ControlBox.MenuBox.Name = "";
            this.tabCtlDplus.ControlBox.Name = "";
            this.tabCtlDplus.ControlBox.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.tabCtlDplus.ControlBox.MenuBox,
            this.tabCtlDplus.ControlBox.CloseBox});
            this.tabCtlDplus.Controls.Add(this.tabCtlPanelReal);
            this.tabCtlDplus.Controls.Add(this.tabCtlPanelHistoryWave);
            this.tabCtlDplus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabCtlDplus.Location = new System.Drawing.Point(0, 0);
            this.tabCtlDplus.Margin = new System.Windows.Forms.Padding(2);
            this.tabCtlDplus.Name = "tabCtlDplus";
            this.tabCtlDplus.ReorderTabsEnabled = true;
            this.tabCtlDplus.SelectedTabFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold);
            this.tabCtlDplus.SelectedTabIndex = 0;
            this.tabCtlDplus.Size = new System.Drawing.Size(1028, 583);
            this.tabCtlDplus.TabFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabCtlDplus.TabIndex = 5;
            this.tabCtlDplus.Tabs.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.tabItemReal,
            this.tabItemHistory});
            this.tabCtlDplus.Text = "superTabControl1";
            // 
            // tabCtlPanelReal
            // 
            this.tabCtlPanelReal.Controls.Add(this.panelReal);
            this.tabCtlPanelReal.Controls.Add(this.panel10);
            this.tabCtlPanelReal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabCtlPanelReal.Location = new System.Drawing.Point(0, 28);
            this.tabCtlPanelReal.Margin = new System.Windows.Forms.Padding(2);
            this.tabCtlPanelReal.Name = "tabCtlPanelReal";
            this.tabCtlPanelReal.Size = new System.Drawing.Size(1028, 555);
            this.tabCtlPanelReal.TabIndex = 1;
            this.tabCtlPanelReal.TabItem = this.tabItemReal;
            // 
            // panelReal
            // 
            this.panelReal.Controls.Add(this.panelRealWave);
            this.panelReal.Controls.Add(this.panel11);
            this.panelReal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelReal.Location = new System.Drawing.Point(0, 89);
            this.panelReal.Margin = new System.Windows.Forms.Padding(2);
            this.panelReal.Name = "panelReal";
            this.panelReal.Size = new System.Drawing.Size(1028, 466);
            this.panelReal.TabIndex = 4;
            // 
            // panelRealWave
            // 
            this.panelRealWave.Controls.Add(this.gPanelRealWave);
            this.panelRealWave.Controls.Add(this.panelBottomRealWave);
            this.panelRealWave.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelRealWave.Location = new System.Drawing.Point(0, 0);
            this.panelRealWave.Margin = new System.Windows.Forms.Padding(2);
            this.panelRealWave.Name = "panelRealWave";
            this.panelRealWave.Size = new System.Drawing.Size(558, 466);
            this.panelRealWave.TabIndex = 3;
            // 
            // gPanelRealWave
            // 
            this.gPanelRealWave.BackColor = System.Drawing.Color.WhiteSmoke;
            this.gPanelRealWave.CanvasColor = System.Drawing.SystemColors.Control;
            this.gPanelRealWave.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.gPanelRealWave.Controls.Add(this.scottRealWaveR);
            this.gPanelRealWave.Controls.Add(this.scottRealWaveL);
            this.gPanelRealWave.Controls.Add(this.lbRealWaveTitle);
            this.gPanelRealWave.DisabledBackColor = System.Drawing.Color.Empty;
            this.gPanelRealWave.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gPanelRealWave.Location = new System.Drawing.Point(0, 0);
            this.gPanelRealWave.Margin = new System.Windows.Forms.Padding(2);
            this.gPanelRealWave.Name = "gPanelRealWave";
            this.gPanelRealWave.Size = new System.Drawing.Size(558, 450);
            // 
            // 
            // 
            this.gPanelRealWave.Style.BackColor = System.Drawing.Color.WhiteSmoke;
            this.gPanelRealWave.Style.BackColor2 = System.Drawing.Color.WhiteSmoke;
            this.gPanelRealWave.Style.BackColorGradientAngle = 90;
            this.gPanelRealWave.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.gPanelRealWave.Style.BorderBottomWidth = 1;
            this.gPanelRealWave.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.MenuUnusedSide;
            this.gPanelRealWave.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.gPanelRealWave.Style.BorderLeftWidth = 1;
            this.gPanelRealWave.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.gPanelRealWave.Style.BorderRightWidth = 1;
            this.gPanelRealWave.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.gPanelRealWave.Style.BorderTopWidth = 1;
            this.gPanelRealWave.Style.CornerDiameter = 4;
            this.gPanelRealWave.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.gPanelRealWave.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.gPanelRealWave.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.gPanelRealWave.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.gPanelRealWave.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.gPanelRealWave.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.gPanelRealWave.TabIndex = 2;
            // 
            // scottRealWaveR
            // 
            this.scottRealWaveR.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.scottRealWaveR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scottRealWaveR.Location = new System.Drawing.Point(0, 222);
            this.scottRealWaveR.Margin = new System.Windows.Forms.Padding(2);
            this.scottRealWaveR.Name = "scottRealWaveR";
            this.scottRealWaveR.Size = new System.Drawing.Size(552, 222);
            this.scottRealWaveR.TabIndex = 14;
            // 
            // scottRealWaveL
            // 
            this.scottRealWaveL.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.scottRealWaveL.Dock = System.Windows.Forms.DockStyle.Top;
            this.scottRealWaveL.Location = new System.Drawing.Point(0, 26);
            this.scottRealWaveL.Margin = new System.Windows.Forms.Padding(2);
            this.scottRealWaveL.Name = "scottRealWaveL";
            this.scottRealWaveL.Size = new System.Drawing.Size(552, 196);
            this.scottRealWaveL.TabIndex = 13;
            this.scottRealWaveL.Load += new System.EventHandler(this.scottRealWaveL_Load);
            // 
            // lbRealWaveTitle
            // 
            this.lbRealWaveTitle.BackColor = System.Drawing.SystemColors.Control;
            this.lbRealWaveTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbRealWaveTitle.Font = new System.Drawing.Font("宋体", 12F);
            this.lbRealWaveTitle.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbRealWaveTitle.Location = new System.Drawing.Point(0, 0);
            this.lbRealWaveTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbRealWaveTitle.Name = "lbRealWaveTitle";
            this.lbRealWaveTitle.Size = new System.Drawing.Size(552, 26);
            this.lbRealWaveTitle.TabIndex = 12;
            this.lbRealWaveTitle.Text = "实时波形";
            this.lbRealWaveTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbRealWaveTitle.Click += new System.EventHandler(this.lbRealWaveTitle_Click);
            // 
            // panelBottomRealWave
            // 
            this.panelBottomRealWave.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBottomRealWave.Location = new System.Drawing.Point(0, 450);
            this.panelBottomRealWave.Margin = new System.Windows.Forms.Padding(2);
            this.panelBottomRealWave.Name = "panelBottomRealWave";
            this.panelBottomRealWave.Size = new System.Drawing.Size(558, 16);
            this.panelBottomRealWave.TabIndex = 13;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.groupPanel6);
            this.panel11.Controls.Add(this.panel12);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel11.Location = new System.Drawing.Point(558, 0);
            this.panel11.Margin = new System.Windows.Forms.Padding(2);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(470, 466);
            this.panel11.TabIndex = 2;
            // 
            // groupPanel6
            // 
            this.groupPanel6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupPanel6.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel6.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel6.Controls.Add(this.dplusRTB);
            this.groupPanel6.Controls.Add(this.label25);
            this.groupPanel6.DisabledBackColor = System.Drawing.Color.Empty;
            this.groupPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupPanel6.Location = new System.Drawing.Point(0, 0);
            this.groupPanel6.Margin = new System.Windows.Forms.Padding(2);
            this.groupPanel6.Name = "groupPanel6";
            this.groupPanel6.Size = new System.Drawing.Size(470, 450);
            // 
            // 
            // 
            this.groupPanel6.Style.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupPanel6.Style.BackColor2 = System.Drawing.Color.WhiteSmoke;
            this.groupPanel6.Style.BackColorGradientAngle = 90;
            this.groupPanel6.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel6.Style.BorderBottomWidth = 1;
            this.groupPanel6.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.MenuUnusedSide;
            this.groupPanel6.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel6.Style.BorderLeftWidth = 1;
            this.groupPanel6.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel6.Style.BorderRightWidth = 1;
            this.groupPanel6.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel6.Style.BorderTopWidth = 1;
            this.groupPanel6.Style.CornerDiameter = 4;
            this.groupPanel6.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel6.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel6.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel6.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel6.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel6.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel6.TabIndex = 2;
            // 
            // dplusRTB
            // 
            this.dplusRTB.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dplusRTB.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dplusRTB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dplusRTB.ForeColor = System.Drawing.Color.White;
            this.dplusRTB.Location = new System.Drawing.Point(0, 26);
            this.dplusRTB.Margin = new System.Windows.Forms.Padding(2);
            this.dplusRTB.Name = "dplusRTB";
            this.dplusRTB.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.dplusRTB.Size = new System.Drawing.Size(464, 418);
            this.dplusRTB.TabIndex = 93;
            this.dplusRTB.Text = "";
            this.dplusRTB.TextChanged += new System.EventHandler(this.dplusRTB_TextChanged);
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.SystemColors.Control;
            this.label25.Dock = System.Windows.Forms.DockStyle.Top;
            this.label25.Font = new System.Drawing.Font("宋体", 12F);
            this.label25.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label25.Location = new System.Drawing.Point(0, 0);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(464, 26);
            this.label25.TabIndex = 12;
            this.label25.Text = "电批记录";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label25.Click += new System.EventHandler(this.label25_Click);
            // 
            // panel12
            // 
            this.panel12.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel12.Location = new System.Drawing.Point(0, 450);
            this.panel12.Margin = new System.Windows.Forms.Padding(2);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(470, 16);
            this.panel12.TabIndex = 13;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel10.Controls.Add(this.label47);
            this.panel10.Controls.Add(this.label52);
            this.panel10.Controls.Add(this.label53);
            this.panel10.Controls.Add(this.label54);
            this.panel10.Controls.Add(this.label55);
            this.panel10.Controls.Add(this.label56);
            this.panel10.Controls.Add(this.label57);
            this.panel10.Controls.Add(this.label60);
            this.panel10.Controls.Add(this.label59);
            this.panel10.Controls.Add(this.label58);
            this.panel10.Controls.Add(this.label36);
            this.panel10.Controls.Add(this.label37);
            this.panel10.Controls.Add(this.label38);
            this.panel10.Controls.Add(this.label39);
            this.panel10.Controls.Add(this.label40);
            this.panel10.Controls.Add(this.label41);
            this.panel10.Controls.Add(this.label42);
            this.panel10.Controls.Add(this.label35);
            this.panel10.Controls.Add(this.label34);
            this.panel10.Controls.Add(this.label33);
            this.panel10.Controls.Add(this.label32);
            this.panel10.Controls.Add(this.label31);
            this.panel10.Controls.Add(this.label30);
            this.panel10.Controls.Add(this.label24);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel10.Location = new System.Drawing.Point(0, 0);
            this.panel10.Margin = new System.Windows.Forms.Padding(2);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(1028, 89);
            this.panel10.TabIndex = 1;
            // 
            // label47
            // 
            this.label47.BackColor = System.Drawing.Color.Gray;
            this.label47.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label47.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label47.ForeColor = System.Drawing.Color.LimeGreen;
            this.label47.Location = new System.Drawing.Point(277, 58);
            this.label47.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(73, 30);
            this.label47.TabIndex = 309;
            this.label47.Text = "0";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label47.Click += new System.EventHandler(this.label47_Click);
            // 
            // label52
            // 
            this.label52.BackColor = System.Drawing.Color.Gray;
            this.label52.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label52.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label52.ForeColor = System.Drawing.Color.LimeGreen;
            this.label52.Location = new System.Drawing.Point(820, 58);
            this.label52.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(263, 30);
            this.label52.TabIndex = 308;
            this.label52.Text = "无";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label52.Click += new System.EventHandler(this.label52_Click);
            // 
            // label53
            // 
            this.label53.BackColor = System.Drawing.Color.Gray;
            this.label53.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label53.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label53.ForeColor = System.Drawing.Color.LimeGreen;
            this.label53.Location = new System.Drawing.Point(0, 58);
            this.label53.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(55, 30);
            this.label53.TabIndex = 307;
            this.label53.Text = "右";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label53.Click += new System.EventHandler(this.label53_Click);
            // 
            // label54
            // 
            this.label54.BackColor = System.Drawing.Color.Gray;
            this.label54.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label54.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label54.ForeColor = System.Drawing.Color.Red;
            this.label54.Location = new System.Drawing.Point(719, 58);
            this.label54.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(102, 30);
            this.label54.TabIndex = 306;
            this.label54.Text = "未知";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label54.Click += new System.EventHandler(this.label54_Click);
            // 
            // label55
            // 
            this.label55.BackColor = System.Drawing.Color.Gray;
            this.label55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label55.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label55.ForeColor = System.Drawing.Color.LimeGreen;
            this.label55.Location = new System.Drawing.Point(624, 58);
            this.label55.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(96, 30);
            this.label55.TabIndex = 305;
            this.label55.Text = "0";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label55.Click += new System.EventHandler(this.label55_Click);
            // 
            // label56
            // 
            this.label56.BackColor = System.Drawing.Color.Gray;
            this.label56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label56.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label56.ForeColor = System.Drawing.Color.LimeGreen;
            this.label56.Location = new System.Drawing.Point(437, 58);
            this.label56.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(188, 30);
            this.label56.TabIndex = 304;
            this.label56.Text = "0.00";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label56.Click += new System.EventHandler(this.label56_Click);
            // 
            // label57
            // 
            this.label57.BackColor = System.Drawing.Color.Gray;
            this.label57.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label57.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label57.ForeColor = System.Drawing.Color.LimeGreen;
            this.label57.Location = new System.Drawing.Point(349, 58);
            this.label57.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(89, 30);
            this.label57.TabIndex = 303;
            this.label57.Text = "0.00";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label57.Click += new System.EventHandler(this.label57_Click);
            // 
            // label60
            // 
            this.label60.BackColor = System.Drawing.Color.Gray;
            this.label60.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label60.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label60.ForeColor = System.Drawing.Color.LimeGreen;
            this.label60.Location = new System.Drawing.Point(54, 58);
            this.label60.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(225, 30);
            this.label60.TabIndex = 302;
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label60.Click += new System.EventHandler(this.label60_Click);
            // 
            // label59
            // 
            this.label59.BackColor = System.Drawing.Color.Gray;
            this.label59.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label59.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label59.ForeColor = System.Drawing.Color.LimeGreen;
            this.label59.Location = new System.Drawing.Point(277, 30);
            this.label59.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(73, 30);
            this.label59.TabIndex = 301;
            this.label59.Text = "0";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label59.Click += new System.EventHandler(this.label59_Click);
            // 
            // label58
            // 
            this.label58.BackColor = System.Drawing.Color.MistyRose;
            this.label58.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label58.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label58.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label58.Location = new System.Drawing.Point(277, 1);
            this.label58.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(73, 30);
            this.label58.TabIndex = 300;
            this.label58.Text = "编号";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label58.Click += new System.EventHandler(this.label58_Click);
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.Color.Gray;
            this.label36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label36.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label36.ForeColor = System.Drawing.Color.LimeGreen;
            this.label36.Location = new System.Drawing.Point(820, 30);
            this.label36.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(263, 30);
            this.label36.TabIndex = 292;
            this.label36.Text = "无";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label36.Click += new System.EventHandler(this.label36_Click);
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.Gray;
            this.label37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label37.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label37.ForeColor = System.Drawing.Color.LimeGreen;
            this.label37.Location = new System.Drawing.Point(0, 30);
            this.label37.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(55, 30);
            this.label37.TabIndex = 291;
            this.label37.Text = "左";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label37.Click += new System.EventHandler(this.label37_Click);
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.Color.Gray;
            this.label38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label38.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label38.ForeColor = System.Drawing.Color.Red;
            this.label38.Location = new System.Drawing.Point(719, 30);
            this.label38.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(102, 30);
            this.label38.TabIndex = 290;
            this.label38.Text = "未知";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label38.Click += new System.EventHandler(this.label38_Click);
            // 
            // label39
            // 
            this.label39.BackColor = System.Drawing.Color.Gray;
            this.label39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label39.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label39.ForeColor = System.Drawing.Color.LimeGreen;
            this.label39.Location = new System.Drawing.Point(624, 30);
            this.label39.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(96, 30);
            this.label39.TabIndex = 289;
            this.label39.Text = "0";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label39.Click += new System.EventHandler(this.label39_Click);
            // 
            // label40
            // 
            this.label40.BackColor = System.Drawing.Color.Gray;
            this.label40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label40.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label40.ForeColor = System.Drawing.Color.LimeGreen;
            this.label40.Location = new System.Drawing.Point(437, 30);
            this.label40.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(188, 30);
            this.label40.TabIndex = 288;
            this.label40.Text = "0.00";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label40.Click += new System.EventHandler(this.label40_Click);
            // 
            // label41
            // 
            this.label41.BackColor = System.Drawing.Color.Gray;
            this.label41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label41.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label41.ForeColor = System.Drawing.Color.LimeGreen;
            this.label41.Location = new System.Drawing.Point(349, 30);
            this.label41.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(89, 30);
            this.label41.TabIndex = 287;
            this.label41.Text = "0.00";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label41.Click += new System.EventHandler(this.label41_Click);
            // 
            // label42
            // 
            this.label42.BackColor = System.Drawing.Color.Gray;
            this.label42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label42.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label42.ForeColor = System.Drawing.Color.LimeGreen;
            this.label42.Location = new System.Drawing.Point(54, 30);
            this.label42.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(225, 30);
            this.label42.TabIndex = 286;
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label42.Click += new System.EventHandler(this.label42_Click);
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.Color.MistyRose;
            this.label35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label35.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label35.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label35.Location = new System.Drawing.Point(820, 1);
            this.label35.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(263, 30);
            this.label35.TabIndex = 285;
            this.label35.Text = "警报";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label35.Click += new System.EventHandler(this.label35_Click);
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.Color.MistyRose;
            this.label34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label34.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label34.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label34.Location = new System.Drawing.Point(0, 1);
            this.label34.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(55, 30);
            this.label34.TabIndex = 284;
            this.label34.Text = "工位";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label34.Click += new System.EventHandler(this.label34_Click);
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.Color.MistyRose;
            this.label33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label33.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label33.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label33.Location = new System.Drawing.Point(719, 1);
            this.label33.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(102, 30);
            this.label33.TabIndex = 283;
            this.label33.Text = "拧紧结果";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label33.Click += new System.EventHandler(this.label33_Click);
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.Color.MistyRose;
            this.label32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label32.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label32.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label32.Location = new System.Drawing.Point(624, 1);
            this.label32.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(96, 30);
            this.label32.TabIndex = 282;
            this.label32.Text = "耗时(ms)";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label32.Click += new System.EventHandler(this.label32_Click);
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.MistyRose;
            this.label31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label31.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label31.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label31.Location = new System.Drawing.Point(437, 1);
            this.label31.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(188, 30);
            this.label31.TabIndex = 281;
            this.label31.Text = "最大扭力(kgf.cm)";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label31.Click += new System.EventHandler(this.label31_Click);
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.MistyRose;
            this.label30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label30.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label30.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label30.Location = new System.Drawing.Point(349, 1);
            this.label30.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(89, 30);
            this.label30.TabIndex = 280;
            this.label30.Text = "圈数(r)";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label30.Click += new System.EventHandler(this.label30_Click);
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.Color.MistyRose;
            this.label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label24.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label24.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label24.Location = new System.Drawing.Point(54, 1);
            this.label24.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(225, 30);
            this.label24.TabIndex = 279;
            this.label24.Text = "产品码";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label24.Click += new System.EventHandler(this.label24_Click);
            // 
            // tabItemReal
            // 
            this.tabItemReal.AttachedControl = this.tabCtlPanelReal;
            this.tabItemReal.GlobalItem = false;
            this.tabItemReal.Name = "tabItemReal";
            this.tabItemReal.Text = "电批实测";
            // 
            // tabCtlPanelHistoryWave
            // 
            this.tabCtlPanelHistoryWave.Controls.Add(this.panelHistoryResult);
            this.tabCtlPanelHistoryWave.Controls.Add(this.panelHistoryQuery);
            this.tabCtlPanelHistoryWave.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabCtlPanelHistoryWave.Location = new System.Drawing.Point(0, 28);
            this.tabCtlPanelHistoryWave.Margin = new System.Windows.Forms.Padding(2);
            this.tabCtlPanelHistoryWave.Name = "tabCtlPanelHistoryWave";
            this.tabCtlPanelHistoryWave.Size = new System.Drawing.Size(875, 529);
            this.tabCtlPanelHistoryWave.TabIndex = 0;
            this.tabCtlPanelHistoryWave.TabItem = this.tabItemHistory;
            this.tabCtlPanelHistoryWave.Visible = false;
            // 
            // panelHistoryResult
            // 
            this.panelHistoryResult.Controls.Add(this.panelHistoryWave);
            this.panelHistoryResult.Controls.Add(this.panelHistoryDplus);
            this.panelHistoryResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelHistoryResult.Location = new System.Drawing.Point(0, 45);
            this.panelHistoryResult.Margin = new System.Windows.Forms.Padding(2);
            this.panelHistoryResult.Name = "panelHistoryResult";
            this.panelHistoryResult.Size = new System.Drawing.Size(875, 484);
            this.panelHistoryResult.TabIndex = 2;
            // 
            // panelHistoryWave
            // 
            this.panelHistoryWave.AutoScroll = true;
            this.panelHistoryWave.Controls.Add(this.scottRealWave3);
            this.panelHistoryWave.Controls.Add(this.scottRealWave2);
            this.panelHistoryWave.Controls.Add(this.scottRealWave1);
            this.panelHistoryWave.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelHistoryWave.Location = new System.Drawing.Point(0, 120);
            this.panelHistoryWave.Margin = new System.Windows.Forms.Padding(2);
            this.panelHistoryWave.Name = "panelHistoryWave";
            this.panelHistoryWave.Size = new System.Drawing.Size(875, 364);
            this.panelHistoryWave.TabIndex = 15;
            // 
            // scottRealWave3
            // 
            this.scottRealWave3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.scottRealWave3.Dock = System.Windows.Forms.DockStyle.Top;
            this.scottRealWave3.Location = new System.Drawing.Point(0, 360);
            this.scottRealWave3.Margin = new System.Windows.Forms.Padding(2);
            this.scottRealWave3.Name = "scottRealWave3";
            this.scottRealWave3.Size = new System.Drawing.Size(858, 180);
            this.scottRealWave3.TabIndex = 16;
            // 
            // scottRealWave2
            // 
            this.scottRealWave2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.scottRealWave2.Dock = System.Windows.Forms.DockStyle.Top;
            this.scottRealWave2.Location = new System.Drawing.Point(0, 180);
            this.scottRealWave2.Margin = new System.Windows.Forms.Padding(2);
            this.scottRealWave2.Name = "scottRealWave2";
            this.scottRealWave2.Size = new System.Drawing.Size(858, 180);
            this.scottRealWave2.TabIndex = 15;
            // 
            // scottRealWave1
            // 
            this.scottRealWave1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.scottRealWave1.Dock = System.Windows.Forms.DockStyle.Top;
            this.scottRealWave1.Location = new System.Drawing.Point(0, 0);
            this.scottRealWave1.Margin = new System.Windows.Forms.Padding(2);
            this.scottRealWave1.Name = "scottRealWave1";
            this.scottRealWave1.Size = new System.Drawing.Size(858, 180);
            this.scottRealWave1.TabIndex = 14;
            // 
            // panelHistoryDplus
            // 
            this.panelHistoryDplus.Controls.Add(this.lbScrewNo3);
            this.panelHistoryDplus.Controls.Add(this.lbAlarm3);
            this.panelHistoryDplus.Controls.Add(this.lbTightenStatus3);
            this.panelHistoryDplus.Controls.Add(this.lbTotalMsecTime3);
            this.panelHistoryDplus.Controls.Add(this.lbMaxTorque3);
            this.panelHistoryDplus.Controls.Add(this.lbCycles3);
            this.panelHistoryDplus.Controls.Add(this.lbScrewNo2);
            this.panelHistoryDplus.Controls.Add(this.lbAlarm2);
            this.panelHistoryDplus.Controls.Add(this.lbTightenStatus2);
            this.panelHistoryDplus.Controls.Add(this.lbTotalMsecTime2);
            this.panelHistoryDplus.Controls.Add(this.lbMaxTorque2);
            this.panelHistoryDplus.Controls.Add(this.lbCycles2);
            this.panelHistoryDplus.Controls.Add(this.lbScrewNo1);
            this.panelHistoryDplus.Controls.Add(this.lbTitleScrewNo);
            this.panelHistoryDplus.Controls.Add(this.lbAlarm1);
            this.panelHistoryDplus.Controls.Add(this.lbTightenStatus1);
            this.panelHistoryDplus.Controls.Add(this.lbTotalMsecTime1);
            this.panelHistoryDplus.Controls.Add(this.lbMaxTorque1);
            this.panelHistoryDplus.Controls.Add(this.lbCycles1);
            this.panelHistoryDplus.Controls.Add(this.lbTitleAlarm);
            this.panelHistoryDplus.Controls.Add(this.lbTitleTightenStatus);
            this.panelHistoryDplus.Controls.Add(this.lbTitleTotalMsecTime);
            this.panelHistoryDplus.Controls.Add(this.lbTitleMaxTorque);
            this.panelHistoryDplus.Controls.Add(this.lbTitleCycles);
            this.panelHistoryDplus.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHistoryDplus.Location = new System.Drawing.Point(0, 0);
            this.panelHistoryDplus.Margin = new System.Windows.Forms.Padding(2);
            this.panelHistoryDplus.Name = "panelHistoryDplus";
            this.panelHistoryDplus.Size = new System.Drawing.Size(875, 120);
            this.panelHistoryDplus.TabIndex = 1;
            // 
            // lbScrewNo3
            // 
            this.lbScrewNo3.BackColor = System.Drawing.Color.Gray;
            this.lbScrewNo3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbScrewNo3.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbScrewNo3.ForeColor = System.Drawing.Color.LimeGreen;
            this.lbScrewNo3.Location = new System.Drawing.Point(2, 89);
            this.lbScrewNo3.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbScrewNo3.Name = "lbScrewNo3";
            this.lbScrewNo3.Size = new System.Drawing.Size(86, 30);
            this.lbScrewNo3.TabIndex = 339;
            this.lbScrewNo3.Text = "0";
            this.lbScrewNo3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbAlarm3
            // 
            this.lbAlarm3.BackColor = System.Drawing.Color.Gray;
            this.lbAlarm3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbAlarm3.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbAlarm3.ForeColor = System.Drawing.Color.LimeGreen;
            this.lbAlarm3.Location = new System.Drawing.Point(607, 89);
            this.lbAlarm3.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbAlarm3.Name = "lbAlarm3";
            this.lbAlarm3.Size = new System.Drawing.Size(460, 30);
            this.lbAlarm3.TabIndex = 338;
            this.lbAlarm3.Text = "无";
            this.lbAlarm3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbTightenStatus3
            // 
            this.lbTightenStatus3.BackColor = System.Drawing.Color.Gray;
            this.lbTightenStatus3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTightenStatus3.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbTightenStatus3.ForeColor = System.Drawing.Color.Red;
            this.lbTightenStatus3.Location = new System.Drawing.Point(489, 89);
            this.lbTightenStatus3.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbTightenStatus3.Name = "lbTightenStatus3";
            this.lbTightenStatus3.Size = new System.Drawing.Size(119, 30);
            this.lbTightenStatus3.TabIndex = 337;
            this.lbTightenStatus3.Text = "未知";
            this.lbTightenStatus3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbTotalMsecTime3
            // 
            this.lbTotalMsecTime3.BackColor = System.Drawing.Color.Gray;
            this.lbTotalMsecTime3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTotalMsecTime3.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbTotalMsecTime3.ForeColor = System.Drawing.Color.LimeGreen;
            this.lbTotalMsecTime3.Location = new System.Drawing.Point(376, 89);
            this.lbTotalMsecTime3.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbTotalMsecTime3.Name = "lbTotalMsecTime3";
            this.lbTotalMsecTime3.Size = new System.Drawing.Size(114, 30);
            this.lbTotalMsecTime3.TabIndex = 336;
            this.lbTotalMsecTime3.Text = "0";
            this.lbTotalMsecTime3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbMaxTorque3
            // 
            this.lbMaxTorque3.BackColor = System.Drawing.Color.Gray;
            this.lbMaxTorque3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbMaxTorque3.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbMaxTorque3.ForeColor = System.Drawing.Color.LimeGreen;
            this.lbMaxTorque3.Location = new System.Drawing.Point(194, 89);
            this.lbMaxTorque3.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbMaxTorque3.Name = "lbMaxTorque3";
            this.lbMaxTorque3.Size = new System.Drawing.Size(183, 30);
            this.lbMaxTorque3.TabIndex = 335;
            this.lbMaxTorque3.Text = "0.00";
            this.lbMaxTorque3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbCycles3
            // 
            this.lbCycles3.BackColor = System.Drawing.Color.Gray;
            this.lbCycles3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbCycles3.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbCycles3.ForeColor = System.Drawing.Color.LimeGreen;
            this.lbCycles3.Location = new System.Drawing.Point(87, 89);
            this.lbCycles3.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbCycles3.Name = "lbCycles3";
            this.lbCycles3.Size = new System.Drawing.Size(108, 30);
            this.lbCycles3.TabIndex = 334;
            this.lbCycles3.Text = "0.00";
            this.lbCycles3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbScrewNo2
            // 
            this.lbScrewNo2.BackColor = System.Drawing.Color.Gray;
            this.lbScrewNo2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbScrewNo2.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbScrewNo2.ForeColor = System.Drawing.Color.LimeGreen;
            this.lbScrewNo2.Location = new System.Drawing.Point(2, 60);
            this.lbScrewNo2.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbScrewNo2.Name = "lbScrewNo2";
            this.lbScrewNo2.Size = new System.Drawing.Size(86, 30);
            this.lbScrewNo2.TabIndex = 333;
            this.lbScrewNo2.Text = "0";
            this.lbScrewNo2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbAlarm2
            // 
            this.lbAlarm2.BackColor = System.Drawing.Color.Gray;
            this.lbAlarm2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbAlarm2.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbAlarm2.ForeColor = System.Drawing.Color.LimeGreen;
            this.lbAlarm2.Location = new System.Drawing.Point(607, 60);
            this.lbAlarm2.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbAlarm2.Name = "lbAlarm2";
            this.lbAlarm2.Size = new System.Drawing.Size(460, 30);
            this.lbAlarm2.TabIndex = 332;
            this.lbAlarm2.Text = "无";
            this.lbAlarm2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbTightenStatus2
            // 
            this.lbTightenStatus2.BackColor = System.Drawing.Color.Gray;
            this.lbTightenStatus2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTightenStatus2.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbTightenStatus2.ForeColor = System.Drawing.Color.Red;
            this.lbTightenStatus2.Location = new System.Drawing.Point(489, 60);
            this.lbTightenStatus2.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbTightenStatus2.Name = "lbTightenStatus2";
            this.lbTightenStatus2.Size = new System.Drawing.Size(119, 30);
            this.lbTightenStatus2.TabIndex = 330;
            this.lbTightenStatus2.Text = "未知";
            this.lbTightenStatus2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbTotalMsecTime2
            // 
            this.lbTotalMsecTime2.BackColor = System.Drawing.Color.Gray;
            this.lbTotalMsecTime2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTotalMsecTime2.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbTotalMsecTime2.ForeColor = System.Drawing.Color.LimeGreen;
            this.lbTotalMsecTime2.Location = new System.Drawing.Point(376, 60);
            this.lbTotalMsecTime2.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbTotalMsecTime2.Name = "lbTotalMsecTime2";
            this.lbTotalMsecTime2.Size = new System.Drawing.Size(114, 30);
            this.lbTotalMsecTime2.TabIndex = 329;
            this.lbTotalMsecTime2.Text = "0";
            this.lbTotalMsecTime2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbMaxTorque2
            // 
            this.lbMaxTorque2.BackColor = System.Drawing.Color.Gray;
            this.lbMaxTorque2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbMaxTorque2.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbMaxTorque2.ForeColor = System.Drawing.Color.LimeGreen;
            this.lbMaxTorque2.Location = new System.Drawing.Point(194, 60);
            this.lbMaxTorque2.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbMaxTorque2.Name = "lbMaxTorque2";
            this.lbMaxTorque2.Size = new System.Drawing.Size(183, 30);
            this.lbMaxTorque2.TabIndex = 328;
            this.lbMaxTorque2.Text = "0.00";
            this.lbMaxTorque2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbCycles2
            // 
            this.lbCycles2.BackColor = System.Drawing.Color.Gray;
            this.lbCycles2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbCycles2.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbCycles2.ForeColor = System.Drawing.Color.LimeGreen;
            this.lbCycles2.Location = new System.Drawing.Point(87, 60);
            this.lbCycles2.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbCycles2.Name = "lbCycles2";
            this.lbCycles2.Size = new System.Drawing.Size(108, 30);
            this.lbCycles2.TabIndex = 327;
            this.lbCycles2.Text = "0.00";
            this.lbCycles2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbScrewNo1
            // 
            this.lbScrewNo1.BackColor = System.Drawing.Color.Gray;
            this.lbScrewNo1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbScrewNo1.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbScrewNo1.ForeColor = System.Drawing.Color.LimeGreen;
            this.lbScrewNo1.Location = new System.Drawing.Point(2, 31);
            this.lbScrewNo1.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbScrewNo1.Name = "lbScrewNo1";
            this.lbScrewNo1.Size = new System.Drawing.Size(86, 30);
            this.lbScrewNo1.TabIndex = 325;
            this.lbScrewNo1.Text = "0";
            this.lbScrewNo1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbTitleScrewNo
            // 
            this.lbTitleScrewNo.BackColor = System.Drawing.Color.MistyRose;
            this.lbTitleScrewNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTitleScrewNo.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbTitleScrewNo.ForeColor = System.Drawing.Color.DodgerBlue;
            this.lbTitleScrewNo.Location = new System.Drawing.Point(2, 2);
            this.lbTitleScrewNo.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbTitleScrewNo.Name = "lbTitleScrewNo";
            this.lbTitleScrewNo.Size = new System.Drawing.Size(86, 30);
            this.lbTitleScrewNo.TabIndex = 324;
            this.lbTitleScrewNo.Text = "编号";
            this.lbTitleScrewNo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbAlarm1
            // 
            this.lbAlarm1.BackColor = System.Drawing.Color.Gray;
            this.lbAlarm1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbAlarm1.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbAlarm1.ForeColor = System.Drawing.Color.LimeGreen;
            this.lbAlarm1.Location = new System.Drawing.Point(607, 31);
            this.lbAlarm1.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbAlarm1.Name = "lbAlarm1";
            this.lbAlarm1.Size = new System.Drawing.Size(460, 30);
            this.lbAlarm1.TabIndex = 323;
            this.lbAlarm1.Text = "无";
            this.lbAlarm1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbTightenStatus1
            // 
            this.lbTightenStatus1.BackColor = System.Drawing.Color.Gray;
            this.lbTightenStatus1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTightenStatus1.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbTightenStatus1.ForeColor = System.Drawing.Color.Red;
            this.lbTightenStatus1.Location = new System.Drawing.Point(489, 31);
            this.lbTightenStatus1.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbTightenStatus1.Name = "lbTightenStatus1";
            this.lbTightenStatus1.Size = new System.Drawing.Size(119, 30);
            this.lbTightenStatus1.TabIndex = 321;
            this.lbTightenStatus1.Text = "未知";
            this.lbTightenStatus1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbTotalMsecTime1
            // 
            this.lbTotalMsecTime1.BackColor = System.Drawing.Color.Gray;
            this.lbTotalMsecTime1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTotalMsecTime1.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbTotalMsecTime1.ForeColor = System.Drawing.Color.LimeGreen;
            this.lbTotalMsecTime1.Location = new System.Drawing.Point(376, 31);
            this.lbTotalMsecTime1.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbTotalMsecTime1.Name = "lbTotalMsecTime1";
            this.lbTotalMsecTime1.Size = new System.Drawing.Size(114, 30);
            this.lbTotalMsecTime1.TabIndex = 320;
            this.lbTotalMsecTime1.Text = "0";
            this.lbTotalMsecTime1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbMaxTorque1
            // 
            this.lbMaxTorque1.BackColor = System.Drawing.Color.Gray;
            this.lbMaxTorque1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbMaxTorque1.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbMaxTorque1.ForeColor = System.Drawing.Color.LimeGreen;
            this.lbMaxTorque1.Location = new System.Drawing.Point(194, 31);
            this.lbMaxTorque1.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbMaxTorque1.Name = "lbMaxTorque1";
            this.lbMaxTorque1.Size = new System.Drawing.Size(183, 30);
            this.lbMaxTorque1.TabIndex = 319;
            this.lbMaxTorque1.Text = "0.00";
            this.lbMaxTorque1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbCycles1
            // 
            this.lbCycles1.BackColor = System.Drawing.Color.Gray;
            this.lbCycles1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbCycles1.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbCycles1.ForeColor = System.Drawing.Color.LimeGreen;
            this.lbCycles1.Location = new System.Drawing.Point(87, 31);
            this.lbCycles1.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbCycles1.Name = "lbCycles1";
            this.lbCycles1.Size = new System.Drawing.Size(108, 30);
            this.lbCycles1.TabIndex = 318;
            this.lbCycles1.Text = "0.00";
            this.lbCycles1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbTitleAlarm
            // 
            this.lbTitleAlarm.BackColor = System.Drawing.Color.MistyRose;
            this.lbTitleAlarm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTitleAlarm.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbTitleAlarm.ForeColor = System.Drawing.Color.DodgerBlue;
            this.lbTitleAlarm.Location = new System.Drawing.Point(607, 2);
            this.lbTitleAlarm.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbTitleAlarm.Name = "lbTitleAlarm";
            this.lbTitleAlarm.Size = new System.Drawing.Size(460, 30);
            this.lbTitleAlarm.TabIndex = 316;
            this.lbTitleAlarm.Text = "警报";
            this.lbTitleAlarm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbTitleTightenStatus
            // 
            this.lbTitleTightenStatus.BackColor = System.Drawing.Color.MistyRose;
            this.lbTitleTightenStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTitleTightenStatus.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbTitleTightenStatus.ForeColor = System.Drawing.Color.DodgerBlue;
            this.lbTitleTightenStatus.Location = new System.Drawing.Point(489, 2);
            this.lbTitleTightenStatus.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbTitleTightenStatus.Name = "lbTitleTightenStatus";
            this.lbTitleTightenStatus.Size = new System.Drawing.Size(119, 30);
            this.lbTitleTightenStatus.TabIndex = 314;
            this.lbTitleTightenStatus.Text = "拧紧结果";
            this.lbTitleTightenStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbTitleTotalMsecTime
            // 
            this.lbTitleTotalMsecTime.BackColor = System.Drawing.Color.MistyRose;
            this.lbTitleTotalMsecTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTitleTotalMsecTime.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbTitleTotalMsecTime.ForeColor = System.Drawing.Color.DodgerBlue;
            this.lbTitleTotalMsecTime.Location = new System.Drawing.Point(376, 2);
            this.lbTitleTotalMsecTime.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbTitleTotalMsecTime.Name = "lbTitleTotalMsecTime";
            this.lbTitleTotalMsecTime.Size = new System.Drawing.Size(114, 30);
            this.lbTitleTotalMsecTime.TabIndex = 313;
            this.lbTitleTotalMsecTime.Text = "耗时(ms)";
            this.lbTitleTotalMsecTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbTitleMaxTorque
            // 
            this.lbTitleMaxTorque.BackColor = System.Drawing.Color.MistyRose;
            this.lbTitleMaxTorque.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTitleMaxTorque.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbTitleMaxTorque.ForeColor = System.Drawing.Color.DodgerBlue;
            this.lbTitleMaxTorque.Location = new System.Drawing.Point(194, 2);
            this.lbTitleMaxTorque.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbTitleMaxTorque.Name = "lbTitleMaxTorque";
            this.lbTitleMaxTorque.Size = new System.Drawing.Size(183, 30);
            this.lbTitleMaxTorque.TabIndex = 312;
            this.lbTitleMaxTorque.Text = "最大扭力(kgf.cm)";
            this.lbTitleMaxTorque.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbTitleCycles
            // 
            this.lbTitleCycles.BackColor = System.Drawing.Color.MistyRose;
            this.lbTitleCycles.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTitleCycles.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbTitleCycles.ForeColor = System.Drawing.Color.DodgerBlue;
            this.lbTitleCycles.Location = new System.Drawing.Point(87, 2);
            this.lbTitleCycles.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbTitleCycles.Name = "lbTitleCycles";
            this.lbTitleCycles.Size = new System.Drawing.Size(108, 30);
            this.lbTitleCycles.TabIndex = 311;
            this.lbTitleCycles.Text = "圈数(r)";
            this.lbTitleCycles.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelHistoryQuery
            // 
            this.panelHistoryQuery.Controls.Add(this.btnQueryWave);
            this.panelHistoryQuery.Controls.Add(this.txbBandSnWave);
            this.panelHistoryQuery.Controls.Add(this.lbpanelHistoryBandSN);
            this.panelHistoryQuery.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHistoryQuery.Location = new System.Drawing.Point(0, 0);
            this.panelHistoryQuery.Margin = new System.Windows.Forms.Padding(2);
            this.panelHistoryQuery.Name = "panelHistoryQuery";
            this.panelHistoryQuery.Size = new System.Drawing.Size(875, 45);
            this.panelHistoryQuery.TabIndex = 1;
            // 
            // btnQueryWave
            // 
            this.btnQueryWave.Location = new System.Drawing.Point(0, 0);
            this.btnQueryWave.Name = "btnQueryWave";
            this.btnQueryWave.Size = new System.Drawing.Size(75, 23);
            this.btnQueryWave.TabIndex = 0;
            // 
            // txbBandSnWave
            // 
            this.txbBandSnWave.BackColor = System.Drawing.Color.White;
            this.txbBandSnWave.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txbBandSnWave.Location = new System.Drawing.Point(174, 8);
            this.txbBandSnWave.Margin = new System.Windows.Forms.Padding(2);
            this.txbBandSnWave.Name = "txbBandSnWave";
            this.txbBandSnWave.Size = new System.Drawing.Size(320, 26);
            this.txbBandSnWave.TabIndex = 49;
            // 
            // lbpanelHistoryBandSN
            // 
            this.lbpanelHistoryBandSN.BackColor = System.Drawing.Color.Transparent;
            this.lbpanelHistoryBandSN.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbpanelHistoryBandSN.Location = new System.Drawing.Point(86, 15);
            this.lbpanelHistoryBandSN.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.lbpanelHistoryBandSN.Name = "lbpanelHistoryBandSN";
            this.lbpanelHistoryBandSN.Size = new System.Drawing.Size(83, 19);
            this.lbpanelHistoryBandSN.TabIndex = 48;
            this.lbpanelHistoryBandSN.Text = "Band SN：";
            this.lbpanelHistoryBandSN.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tabItemHistory
            // 
            this.tabItemHistory.AttachedControl = this.tabCtlPanelHistoryWave;
            this.tabItemHistory.GlobalItem = false;
            this.tabItemHistory.Name = "tabItemHistory";
            this.tabItemHistory.Text = "电批历史";
            // 
            // stiDPlusManual
            // 
            this.stiDPlusManual.AttachedControl = this.superTabControlPanel6;
            this.stiDPlusManual.GlobalItem = false;
            this.stiDPlusManual.Name = "stiDPlusManual";
            // 
            // frmManual
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 583);
            this.Controls.Add(this.stcManual);
            this.Name = "frmManual";
            this.Text = "frmManual";
            this.Load += new System.EventHandler(this.frmManual_Load);
            ((System.ComponentModel.ISupportInitialize)(this.stcManual)).EndInit();
            this.stcManual.ResumeLayout(false);
            this.superTabControlPanel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tabCtlDplus)).EndInit();
            this.tabCtlDplus.ResumeLayout(false);
            this.tabCtlPanelReal.ResumeLayout(false);
            this.panelReal.ResumeLayout(false);
            this.panelRealWave.ResumeLayout(false);
            this.gPanelRealWave.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.groupPanel6.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.tabCtlPanelHistoryWave.ResumeLayout(false);
            this.panelHistoryResult.ResumeLayout(false);
            this.panelHistoryWave.ResumeLayout(false);
            this.panelHistoryDplus.ResumeLayout(false);
            this.panelHistoryQuery.ResumeLayout(false);
            this.panelHistoryQuery.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        
        private DevComponents.DotNetBar.SuperTabControl stcManual;
        
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel6;
        private DevComponents.DotNetBar.SuperTabItem stiDPlusManual;
        private Panel panel11;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel6;
        private Label label25;
        private Panel panel12;
        private Panel panel10;
        private RichTextBox dplusRTB;
        private Label label36;
        private Label label37;
        private Label label38;
        private Label label39;
        private Label label40;
        private Label label41;
        private Label label42;
        private Label label35;
        private Label label34;
        private Label label33;
        private Label label32;
        private Label label31;
        private Label label30;
        private Label label24;
        private Label label58;
        private Label label47;
        private Label label52;
        private Label label53;
        private Label label54;
        private Label label55;
        private Label label56;
        private Label label57;
        private Label label60;
        private Label label59;
        private Panel panelRealWave;
        private DevComponents.DotNetBar.Controls.GroupPanel gPanelRealWave;
        private Label lbRealWaveTitle;
        private ScottPlot.FormsPlot scottRealWaveL;
        private ScottPlot.FormsPlot scottRealWaveR;
        private Panel panelBottomRealWave;
        private DevComponents.DotNetBar.SuperTabControl tabCtlDplus;
        private DevComponents.DotNetBar.SuperTabControlPanel tabCtlPanelReal;
        private Panel panelReal;
        private DevComponents.DotNetBar.SuperTabItem tabItemReal;
        private DevComponents.DotNetBar.SuperTabControlPanel tabCtlPanelHistoryWave;
        private DevComponents.DotNetBar.SuperTabItem tabItemHistory;
        private Panel panelHistoryResult;
        private Panel panelHistoryWave;
        private Panel panelHistoryDplus;
        private Label lbScrewNo3;
        private Label lbAlarm3;
        private Label lbTightenStatus3;
        private Label lbTotalMsecTime3;
        private Label lbMaxTorque3;
        private Label lbCycles3;
        private Label lbScrewNo2;
        private Label lbAlarm2;
        private Label lbTightenStatus2;
        private Label lbTotalMsecTime2;
        private Label lbMaxTorque2;
        private Label lbCycles2;
        private Label lbScrewNo1;
        private Label lbTitleScrewNo;
        private Label lbAlarm1;
        private Label lbTightenStatus1;
        private Label lbTotalMsecTime1;
        private Label lbMaxTorque1;
        private Label lbCycles1;
        private Label lbTitleAlarm;
        private Label lbTitleTightenStatus;
        private Label lbTitleTotalMsecTime;
        private Label lbTitleMaxTorque;
        private Label lbTitleCycles;
        private Panel panelHistoryQuery;
        private Button btnQueryWave;
        private TextBox txbBandSnWave;
        private Label lbpanelHistoryBandSN;
        private ScottPlot.FormsPlot scottRealWave3;
        private ScottPlot.FormsPlot scottRealWave2;
        private ScottPlot.FormsPlot scottRealWave1;
    }
}