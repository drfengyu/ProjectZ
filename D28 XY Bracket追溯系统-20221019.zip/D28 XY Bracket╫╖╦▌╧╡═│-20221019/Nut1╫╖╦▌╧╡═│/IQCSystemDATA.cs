﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 卓汇数据追溯系统
{
    public class IQCSystemDATA
    {
        /// <summary>
        /// 厂区名称
        /// </summary>
        public string Plant_Organization_Name { get; set; }
        /// <summary>
        /// OP名称
        /// </summary>
        public string BG_Organization_Name { get; set; }
        /// <summary>
        /// 功能厂名称 可空
        /// </summary>
        public string FunPlant_Organization_Name { get; set; }
        /// <summary>
        /// 专案名称
        /// </summary>
        public string Project_Name { get; set; }
        /// <summary>
        /// 工站名
        /// </summary>
        public string WorkStation_Name { get; set; }
    }

    public class MachineParameterUpdate
    {
        /// <summary>
        /// 厂区名称
        /// </summary>
        public string SiteName { get; set; }
        /// <summary>
        /// EMT
        /// </summary>
        public string EMT { get; set; }
        /// <summary>
        /// TraceIP/OEE IP
        /// </summary>
        public string TraceIP { get; set; }
        /// <summary>
        /// TraceStationID
        /// </summary>
        public string TraceStationID { get; set; }
        /// <summary>
        /// MacAddress
        /// </summary>
        public string MacAddress { get; set; }
    }
    public class MachineParameterQuery
    {
        public MacAddress MacAddress
        {
            get;
            set;
        }
        public SiteName SiteName
        {
            get;
            set;
        }
        public EMT EMT
        {
            get;
            set;
        }
        public TraceIP TraceIP
        {
            get;
            set;
        }

        public TraceStationID TraceStationID
        {
            get;
            set;
        }

    }
    public class MacAddress
    {
        public bool IsMatch
        {
            get;
            set;
        }
        public string FromJMCC
        {
            get;
            set;
        }
        public string FromMachine
        {
            get;
            set;
        }
    }
    public class SiteName
    {
        public bool IsMatch
        {
            get;
            set;
        }
        public string FromJMCC
        {
            get;
            set;
        }
        public string FromMachine
        {
            get;
            set;
        }
    }
    public class EMT
    {
        public bool IsMatch
        {
            get;
            set;
        }
        public string FromJMCC
        {
            get;
            set;
        }
        public string FromMachine
        {
            get;
            set;
        }
    }
    public class TraceIP
    {
        public bool IsMatch
        {
            get;
            set;
        }
        public string FromJMCC
        {
            get;
            set;
        }
        public string FromMachine
        {
            get;
            set;
        }
    }
    public class TraceStationID
    {
        public bool IsMatch
        {
            get;
            set;
        }
        public string FromJMCC
        {
            get;
            set;
        }
        public string FromMachine
        {
            get;
            set;
        }
    }
}
