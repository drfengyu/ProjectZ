﻿namespace 卓汇数据追溯系统
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label152 = new System.Windows.Forms.Label();
            this.label160 = new System.Windows.Forms.Label();
            this.label166 = new System.Windows.Forms.Label();
            this.label167 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.72004F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.27996F));
            this.tableLayoutPanel1.Controls.Add(this.label167, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel6, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(943, 450);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.label166);
            this.panel6.Controls.Add(this.label152);
            this.panel6.Controls.Add(this.label160);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(3, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(444, 219);
            this.panel6.TabIndex = 102;
            // 
            // label152
            // 
            this.label152.BackColor = System.Drawing.Color.Gray;
            this.label152.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label152.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label152.ForeColor = System.Drawing.Color.LimeGreen;
            this.label152.Location = new System.Drawing.Point(-135, 36);
            this.label152.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(55, 30);
            this.label152.TabIndex = 322;
            this.label152.Text = "左";
            this.label152.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label160
            // 
            this.label160.BackColor = System.Drawing.Color.MistyRose;
            this.label160.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label160.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label160.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label160.Location = new System.Drawing.Point(-135, 7);
            this.label160.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label160.Name = "label160";
            this.label160.Size = new System.Drawing.Size(55, 30);
            this.label160.TabIndex = 315;
            this.label160.Text = "工位";
            this.label160.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label166
            // 
            this.label166.AutoSize = true;
            this.label166.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label166.Location = new System.Drawing.Point(0, 0);
            this.label166.Name = "label166";
            this.label166.Size = new System.Drawing.Size(53, 12);
            this.label166.TabIndex = 323;
            this.label166.Text = "实时波形";
            this.label166.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label167
            // 
            this.label167.AutoSize = true;
            this.label167.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label167.Location = new System.Drawing.Point(453, 0);
            this.label167.Name = "label167";
            this.label167.Size = new System.Drawing.Size(487, 225);
            this.label167.TabIndex = 103;
            this.label167.Text = "电批记录";
            this.label167.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(943, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.Label label160;
        private System.Windows.Forms.Label label166;
        private System.Windows.Forms.Label label167;
    }
}