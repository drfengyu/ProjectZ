﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 卓汇数据追溯系统
{
    /// <summary>
    /// 电批地址常量
    /// </summary>
    public class AddressConsts
    {
        /// <summary>
        /// 开始地址
        /// </summary>
        public const int Start = 60625;
        /// <summary>
        /// 警报地址
        /// </summary>
        public const int AlarmCode = 60638;
        /// <summary>
        /// 最大扭力值地址
        /// </summary>
        public const int MaxTorque = 60628;
        /// <summary>
        /// 总拧紧时长地址
        /// </summary>
        public const int TotalMSecTime = 60629;
        /// <summary>
        /// 最终拧紧结果地址
        /// </summary>
        public const int TightenStatus = 60630;
        /// <summary>
        /// 采集波形长度地址
        /// </summary>
        public const int WaveLength = 60635;
        /// <summary>
        /// 实时运行圈数地址
        /// </summary>
        public const int RealCycles = 60653;
        /// <summary>
        /// 统计螺丝总量
        /// </summary>
        public const int TotalScrew = 60631;
        /// <summary>
        /// 波形数据地址 通道二 10600-扭力 10000-圈数
        /// </summary>
        public const int WaveData = 10600;
    }
}
