﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 卓汇数据追溯系统
{
    /// <summary>
    /// 警报编码
    /// </summary>
    public enum AlarmCodeEnum
    {
        /// <summary>
        /// 其他为正常
        /// </summary>
        [Description("无")]
        None = 0,
        /// <summary>
        /// =1,浮高；
        /// </summary>
        [Description("浮高")]
        FuGao = 1,
        /// <summary>
        /// =2，滑牙；
        /// </summary>
        [Description("滑牙")]
        HuaYa = 2,
        /// <summary>
        /// =3，过流（断电重启）
        /// </summary>
        [Description("过流（断电重启）")]
        GuoLiu = 3,
        /// <summary>
        /// =4，过压（检查供电电压是否偏高）；
        /// </summary>
        [Description("过压（检查供电电压是否偏高）")]
        GuoYa = 4,
        /// <summary>
        /// =5，欠压（检查供电电压是否偏低）；
        /// </summary>
        [Description("欠压（检查供电电压是否偏低）")]
        QianYa = 5,
        /// <summary>
        /// =6，飞车；
        /// </summary>
        [Description("飞车")]
        FeiChe = 6,
        /// <summary>
        /// =7，I2T过热（检查批头是否打滑，螺丝是否打滑）;
        /// </summary>
        [Description("I2T过热（检查批头是否打滑，螺丝是否打滑）")]
        I2T_GuoRe = 7,
        /// <summary>
        /// =8，反转不到位；
        /// </summary>
        [Description("反转不到位")]
        FanZhuanBuDaoWei = 8,
        /// <summary>
        /// =9，位置偏差过大（检测电机线与encoder线接触是否良好）；
        /// </summary>
        [Description("位置偏差过大（检测电机线与encoder线接触是否良好）")]
        WeiZhiPianChaGuoDa = 9
    }

}
