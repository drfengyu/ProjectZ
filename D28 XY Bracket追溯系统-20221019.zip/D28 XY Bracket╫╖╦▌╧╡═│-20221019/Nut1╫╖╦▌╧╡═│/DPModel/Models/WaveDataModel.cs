﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 卓汇数据追溯系统
{
    public class WaveDataModel
    {
        /// <summary>
        /// 开始时间
        /// </summary>
        public DateTime BeginTime { get; set; } = DateTime.Now;
        /// <summary>
        /// 扭力数据
        /// </summary>
        public List<int> Datas { get; set; } = new List<int>();
        /// <summary>
        /// 数据间隔ms
        /// </summary>
        public double Interval { get; set; }
    }
}
