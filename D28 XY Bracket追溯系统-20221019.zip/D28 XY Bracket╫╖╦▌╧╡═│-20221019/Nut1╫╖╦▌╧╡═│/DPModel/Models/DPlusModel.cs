﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 卓汇数据追溯系统
{
    /// <summary>
    /// DPlus数据
    /// </summary>
    public class DPlusModel
    {
        /// <summary>
        /// 警报
        /// </summary>
        public AlarmCodeEnum AlarmCode { get; set; }
        /// <summary>
        /// 最大扭力值 mN.m=0.001N.m  1N.m=10 kgf．cm
        /// </summary>
        public int MaxTorque { get; set; }
        /// <summary>
        /// 总拧紧时长
        /// </summary>
        public int TotalMSecTime { get; set; }
        /// <summary>
        /// 最终拧紧结果
        /// </summary>
        public TightenStatusEnum TightenStatus { get; set; }
        /// <summary>
        /// 实时运行圈数
        /// </summary>
        public int RealCycles { get; set; }
        /// <summary>
        /// 采集波形长度地址
        /// </summary>
        public int WaveLength { get; set; }
        /// <summary>
        /// 统计螺丝总量
        /// </summary>
        public int TotalScrew { get; set; }
        /// <summary>
        /// 波形数据
        /// </summary>
        public List<short> WaveDatas { get; set; } = new List<short>();
        public List<short> WaveDatasB { get; set; } = new List<short>();
    }
}
