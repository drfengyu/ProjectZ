﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 卓汇数据追溯系统
{
    /// <summary>
    /// 拧紧状态枚举
    /// </summary>
    public enum TightenStatusEnum
    {
        /// <summary>
        /// NG
        /// </summary>
        [Description("NG")]
        NG = 0x4AAA,
        /// <summary>
        /// OK
        /// </summary>
        [Description("OK")]
        OK = 0x4BBB,
        /// <summary>
        /// 未完成
        /// </summary>
        [Description("未完成")]
        NotFinish = 0x4CCC
    }
}
