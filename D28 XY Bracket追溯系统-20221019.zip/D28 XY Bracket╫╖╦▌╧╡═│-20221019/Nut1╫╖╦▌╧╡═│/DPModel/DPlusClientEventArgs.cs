﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 卓汇数据追溯系统
{
    /// <summary>
    /// DPlusClient
    /// </summary>
    /// <typeparam name="T">参数</typeparam>
    public class DPlusClientEventArgs<T> : EventArgs
    {
        public DPlusClientEventArgs(T value)
        {
            Value = value;
        }

        public T Value { get; }
    }
}
