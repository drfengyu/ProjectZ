﻿using EasyModbus;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 卓汇数据追溯系统
{
    /// <summary>
    /// 读取电批扩展
    /// </summary>
    public static class ReadExtensions
    {
        /// <summary>
        /// 读取警报代码
        /// </summary>
        /// <param name="registers"></param>
        /// <returns></returns>
        public static AlarmCodeEnum ReadAlarmCode(this int[] registers)
        {
            var index = AddressConsts.AlarmCode - AddressConsts.Start;
            var alarmCodeValue = registers[index];
            if (alarmCodeValue >= 1 && alarmCodeValue <= 9)
            {
                return (AlarmCodeEnum)registers[index];
            }
            return AlarmCodeEnum.None;
        }
        /// <summary>
        /// 读取拧紧结果
        /// </summary>
        /// <param name="registers"></param>
        /// <returns></returns>
        public static TightenStatusEnum ReadTightenStatus(this int[] registers)
        {
            var index = AddressConsts.TightenStatus - AddressConsts.Start;
            return (TightenStatusEnum)registers[index];
        }
        /// <summary>
        /// 读取最大扭力值，单位：nM.m
        /// </summary>
        /// <param name="registers"></param>
        /// <returns></returns>
        public static int ReadMaxTorque(this int[] registers)
        {
            var index = AddressConsts.MaxTorque - AddressConsts.Start;
            return registers[index];
        }
        /// <summary>
        /// 读取实时运行圈数（0.01r）
        /// </summary>
        /// <param name="registers"></param>
        /// <returns></returns>
        public static int ReadRealCycles(this int[] registers)
        {
            var index = AddressConsts.RealCycles - AddressConsts.Start;
            return registers[index];
        }
        /// <summary>
        /// 读取此次波形采集数量
        /// </summary>
        /// <param name="registers"></param>
        /// <returns></returns>
        public static int ReadWaveLength(this int[] registers)
        {
            var index = AddressConsts.WaveLength - AddressConsts.Start;
            return registers[index];
        }
        /// <summary>
        /// 读取总拧紧时间，单位：ms
        /// </summary>
        /// <param name="registers"></param>
        /// <returns></returns>
        public static int ReadTotalMSecTime(this int[] registers)
        {
            var index = AddressConsts.TotalMSecTime - AddressConsts.Start;
            return registers[index];
        }
        /// <summary>
        /// 读取螺丝总量
        /// </summary>
        /// <param name="registers"></param>
        /// <returns></returns>
        public static int ReadTotalScrew(this int[] registers)
        {
            var index = AddressConsts.TotalScrew - AddressConsts.Start;
            int[] totalScrewRegisters = new int[2];
            Array.Copy(registers, index, totalScrewRegisters, 0, 2);
            return ModbusClient.ConvertRegistersToInt(totalScrewRegisters, ModbusClient.RegisterOrder.HighLow);
        }
    }
}
