﻿using EasyModbus;

using Nito.AsyncEx;
using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace 卓汇数据追溯系统
{
    public class DPlusModbusRtuClient
    {
        private CancellationTokenSource _cts = null;
        /// <summary>
        /// 启动的时候需要初始化螺丝总数，用于监测是否当前拧紧是否完成
        /// </summary>
        public int? TotalScrew { get; set; } = null;
        /// <summary>
        /// 实时数据
        /// </summary>
        private DPlusModel _dPlusModel = null;
        /// <summary>
        /// 波形数据
        /// </summary>
        private WaveDataModel _wave = null;
        /// <summary>
        /// 读取超时
        /// </summary>
        private const int _readTimeout = 1000;
        /// <summary>
        /// 读取波形数据超时
        /// </summary>
        private const int _readWaveTimeout = 3000;
        /// <summary>
        /// 是否读取完成
        /// </summary>
        private bool _isCompleted = false;
        /// <summary>
        /// 是否读取波形数据完成
        /// </summary>
        private bool _isWaveCompleted = false;
        /// <summary>
        /// 串口号
        /// </summary>
        private string _portName = null;

        private Parity _parity = Parity.None;

        private readonly AsyncLock _mutex = new AsyncLock();

        private readonly AsyncLock _mutexWave = new AsyncLock();

        public readonly ModbusClient _modbusClient = null;

        public ModbusClient ModbusClient => _modbusClient;

        /// <summary>
        /// 螺丝枪串口客户端
        /// </summary>
        /// <param name="portName">端口号</param>
        /// <param name="baudRate">波特率</param>
        /// <param name="stopBits">停止位</param>
        /// <param name="parity">校验</param>
        /// <param name="dataBits">数据位</param>
        public DPlusModbusRtuClient(int baudRate = 115200, StopBits stopBits = StopBits.One, Parity parity = Parity.None, byte unitIdentifier = 1)
        {
            _modbusClient = new ModbusClient();
            _modbusClient.Baudrate = baudRate;
            _modbusClient.StopBits = stopBits;
            _parity = parity;
            _modbusClient.UnitIdentifier = unitIdentifier;
        }

        private TaskCompletionSource<DPlusModel> _tcs = null;

        /// <summary>
        /// 读取电批数据
        /// </summary>
        /// <returns></returns>
        public async Task<DPlusModel> ReadRealDataAsync()
        {
            using (await _mutex.LockAsync())
            {
                if (_modbusClient.Connected)
                {
                    if (null != _tcs)
                    {
                        try
                        {
                            CancellationTokenSource cts = new CancellationTokenSource(_readTimeout);
                            var result = await _tcs.Task.WaitAsync(cts.Token);
                            Log.WriteOEELog($"MachineNo【{_portName}】step-3,电批停止：读取电批数据成功");
                            return result;
                        }
                        catch (TaskCanceledException ex)
                        {
                            Log.WriteOEELog($"【{nameof(ReadRealDataAsync)}】电批停止：读取电批数据发生超时【{_readTimeout}】:{ex}");
                        }
                        catch (Exception ex)
                        {
                            Log.WriteOEELog($"【{nameof(ReadRealDataAsync)}】电批停止：读取电批数据发生异常:{ex}");
                        }
                        finally
                        {
                            _tcs = null;
                        }
                    }
                }
            }
            return null;
        }
        /// <summary>
        /// 开始锁螺丝初始化状态
        /// </summary>
        /// <returns></returns>
        public async Task InitScrewDataAsync()
        {
            using (await _mutex.LockAsync())
            {
                _tcs = new TaskCompletionSource<DPlusModel>();
                Log.WriteOEELog($"MachineNo【{_portName}】step-1,电批启动，等待电批数据");
            }
        }

        /// <summary>
        /// 读取实时数据
        /// </summary>
        /// <returns></returns>
        [Obsolete]
        public async Task<DPlusModel> ReadRealDataAsync_1()
        {
            using (await _mutex.LockAsync())
            {
                DPlusModel dPlus = null;
                if (_modbusClient.Connected)
                {
                    var time = DateTime.Now;

                    while (!_cts.IsCancellationRequested)
                    {
                        try
                        {

                            if (DateTime.Now.Subtract(time).TotalMilliseconds > _readTimeout) break;

                            if (_dPlusModel != null)
                            {
                                dPlus = new DPlusModel()
                                {
                                    MaxTorque = _dPlusModel.MaxTorque,
                                    AlarmCode = _dPlusModel.AlarmCode,
                                    TightenStatus = _dPlusModel.TightenStatus,
                                    TotalMSecTime = _dPlusModel.TotalMSecTime,
                                    RealCycles = _dPlusModel.RealCycles
                                };
                                dPlus.WaveDatas.AddRange(_dPlusModel.WaveDatas);
                                break;
                            }

                            Thread.Sleep(10);

                        }
                        catch (Exception ex)
                        {
                            Log.WriteOEELog($"【{nameof(DPlusModbusRtuClient.ReadRealDataAsync)}，MachineNo【{_portName}】:{ex}");
                        }
                    }
                }
                _dPlusModel = null;
                return dPlus;
            }
        }
        [Obsolete]
        public async Task BeginReadWaveDataAsync()
        {
            using (await _mutex.LockAsync())
            {
                _wave = new WaveDataModel();
                _isWaveCompleted = false;
            }
        }
        [Obsolete]
        public async Task<WaveDataModel> GetWaveDataAsync()
        {
            using (await _mutexWave.LockAsync())
            {
                WaveDataModel data = null;
                if (_modbusClient.Connected)
                {
                    var time = DateTime.Now;
                    while (!_cts.IsCancellationRequested)
                    {
                        try
                        {
                            if (DateTime.Now.Subtract(time).TotalMilliseconds > _readWaveTimeout) break;

                            if (_isWaveCompleted && _wave != null)
                            {
                                int[] datas = new int[_wave.Datas.Count];
                                _wave.Datas.CopyTo(datas, 0);
                                data = new WaveDataModel()
                                {
                                    BeginTime = _wave.BeginTime,
                                    Datas = datas.ToList(),
                                    Interval = _wave.Interval
                                };
                                break;
                            }

                            Thread.Sleep(10);
                        }
                        catch (Exception ex)
                        {

                            Log.WriteOEELog($"【{nameof(DPlusModbusRtuClient.GetWaveDataAsync)}，MachineNo【{_portName}】:{ex}");

                        }

                    }
                }
                _wave = null;
                return data;
            }
        }

        public async Task<bool> ConnectAsync(string portName)
        {
            try
            {
                //首次连接不需要，改变串口 50ms后重新连接
                if (null != _portName && _portName != portName)
                {
                    await this.DisConnectedAsync();
                    Thread.Sleep(100);
                }
                if (!_modbusClient.Connected)
                {
                    _modbusClient.SerialPort = portName;
                    //必须初始化串口后赋值
                    _modbusClient.Parity = _parity;
                    TotalScrew = null;
                    _modbusClient.Connect();
                    _portName = portName;
                    if (null == _cts || _cts.IsCancellationRequested)
                    {
                        _cts = new CancellationTokenSource();
                        //_ = Listening(_cts.Token);
                    }
                    ClientStatusChanged?.Invoke(this, new DPlusClientEventArgs<DPlusStatusInfo>(
                        new DPlusStatusInfo()
                        {
                            IsConnected = _modbusClient.Connected,
                            Msg = $"{DateTime.Now.ToString("yyyy-M-d HH:mm:ss")},电批-串口[{_modbusClient.SerialPort}],连接成功"
                        }));
                }

                return true;
            }
            catch (Exception ex)
            {
                ClientStatusChanged?.Invoke(this, new DPlusClientEventArgs<DPlusStatusInfo>(
                      new DPlusStatusInfo()
                      {
                          IsConnected = _modbusClient.Connected,
                          Msg = $"{DateTime.Now.ToString("yyyy-M-d HH:mm:ss")},电批-串口[{_modbusClient.SerialPort}],连接异常[{ex.Message}]"
                      }));

                Log.WriteOEELog($"【{nameof(DPlusModbusRtuClient.ConnectAsync)}，MachineNo【{_portName}】:{ex}");


                return false;
            }
        }
        public Task DisConnectedAsync()
        {
            try
            {
                _cts?.Cancel();
                if (_modbusClient.Connected)
                {
                    _modbusClient.Disconnect();
                    System.Diagnostics.Debug.WriteLine($"【{nameof(DisConnectedAsync)}-[{Thread.CurrentThread.ManagedThreadId}]");
                    ClientStatusChanged?.Invoke(this, new DPlusClientEventArgs<DPlusStatusInfo>(
                      new DPlusStatusInfo()
                      {
                          IsConnected = _modbusClient.Connected,
                          Msg = $"{DateTime.Now.ToString("yyyy-M-d HH:mm:ss")},电批-串口[{_modbusClient.SerialPort}],连接断开"
                      }));
                }

            }
            catch (Exception ex)
            {
                ClientStatusChanged?.Invoke(this, new DPlusClientEventArgs<DPlusStatusInfo>(
                      new DPlusStatusInfo()
                      {
                          IsConnected = _modbusClient.Connected,
                          Msg = $"{DateTime.Now.ToString("yyyy-M-d HH:mm:ss")},电批-串口[{_modbusClient.SerialPort}],连接断开异常[{ex.Message}]"
                      }));

                Log.WriteOEELog($"【{nameof(DPlusModbusRtuClient.DisConnectedAsync)}，MachineNo【{_portName}】:{ex}");

            }

            return Task.FromResult(0);

        }
        private async Task Listening(CancellationToken token)
        {
            await Task.Factory.StartNew(() =>
            {
                while (!token.IsCancellationRequested)
                {
                    if (_modbusClient.Connected)
                    {
                        try
                        {
                            //从60625开始，读取32个
                            var registers = _modbusClient.ReadHoldingRegisters(AddressConsts.Start, 32);
                            var currentTotalScrew = registers.ReadTotalScrew();
                            if (!TotalScrew.HasValue)
                            {
                                TotalScrew = currentTotalScrew;
                                continue;
                            }
                            if (TotalScrew.Value != currentTotalScrew)
                            {
                                var diff = currentTotalScrew - TotalScrew.Value;
                                if (diff != 1)
                                {
                                    Log.WriteOEELog($"【{nameof(DPlusModbusRtuClient.Listening)}】螺丝总量变化异常【{diff}】，[{TotalScrew.Value}->{currentTotalScrew}]");
                                }

                                TotalScrew = currentTotalScrew;
                                //读取电批的数据
                                var dPlusModel = new DPlusModel()
                                {
                                    MaxTorque = registers.ReadMaxTorque(),
                                    AlarmCode = registers.ReadAlarmCode(),
                                    TightenStatus = registers.ReadTightenStatus(),
                                    TotalMSecTime = registers.ReadTotalMSecTime(),
                                    RealCycles = registers.ReadRealCycles()
                                };

                                var len = registers.ReadWaveLength();
                                if (len > 0)
                                {
                                    //一次读100个
                                    var cnt = len / 100;
                                    var startAddress = AddressConsts.WaveData;
                                    for (int i = 0; i < cnt; i++)
                                    {
                                        //dPlusModel.WaveDatas.AddRange(_modbusClient.ReadHoldingRegisters(startAddress, 100));
                                        startAddress += 100;
                                    }
                                    var mod = len % 100;

                                    if (mod != 0)
                                    {
                                        //dPlusModel.WaveDatas.AddRange(_modbusClient.ReadHoldingRegisters(startAddress, mod));
                                    };

                                    if (_tcs != null && _tcs.TrySetResult(dPlusModel))
                                    {
                                        Log.WriteOEELog($"MachineNo【{_portName}】step-2,数据读取：电批数据抓取完成！");
                                    }
                                }
                                else
                                {
                                    Log.WriteOEELog($"【{nameof(DPlusModbusRtuClient.Listening)}】波形数据长度为:0");
                                }
                                /* 全局变量方式，否发引发异常发生
                                //读取电批的数据
                                _dPlusModel = new DPlusModel()
                                {
                                    MaxTorque = registers.ReadMaxTorque(),
                                    AlarmCode = registers.ReadAlarmCode(),
                                    TightenStatus = registers.ReadTightenStatus(),
                                    TotalMSecTime = registers.ReadTotalMSecTime(),
                                    RealCycles = registers.ReadRealCycles()
                                };

                                var len = registers.ReadWaveLength();
                                if (len > 0)
                                {
                                    //一次读100个
                                    var cnt = len / 100;
                                    var startAddress = AddressConsts.WaveData;
                                    for (int i = 0; i < cnt; i++)
                                    {
                                        _dPlusModel.WaveDatas.AddRange(_modbusClient.ReadHoldingRegisters(startAddress, 100));
                                        startAddress += 100;
                                    }
                                    var mod = len % 100;

                                    if (mod != 0)
                                    {
                                        _dPlusModel.WaveDatas.AddRange(_modbusClient.ReadHoldingRegisters(startAddress, mod));
                                    };
                                }

                                //*/
                            }
                        }
                        catch (Exception ex)
                        {
                            Log.WriteOEELog($"【{nameof(DPlusModbusRtuClient.Listening)}，MachineNo【{_portName}】:{ex}");

                        }

                        Thread.Sleep(10);
                    }
                }
            }, token, TaskCreationOptions.LongRunning, TaskScheduler.Current);
        }

        public event ClientStatusChangedHandler ClientStatusChanged;
    }

    public delegate void ClientStatusChangedHandler(object sender, DPlusClientEventArgs<DPlusStatusInfo> args);
}
