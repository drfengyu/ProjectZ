﻿namespace 卓汇数据追溯系统
{
    partial class HomeFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel26 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel27 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel28 = new System.Windows.Forms.TableLayoutPanel();
            this.button4 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.tableLayoutPanel29 = new System.Windows.Forms.TableLayoutPanel();
            this.txt_Count = new System.Windows.Forms.TextBox();
            this.txt_NGcount = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txt_lianglv = new System.Windows.Forms.TextBox();
            this.txt_paoliao = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.txt_CT = new System.Windows.Forms.TextBox();
            this.txt_paoliaolv = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.tableLayoutPanel30 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel31 = new System.Windows.Forms.TableLayoutPanel();
            this.label78 = new System.Windows.Forms.Label();
            this.tableLayoutPanel32 = new System.Windows.Forms.TableLayoutPanel();
            this.label94 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.tableLayoutPanel33 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label110 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel34 = new System.Windows.Forms.TableLayoutPanel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel49 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel50 = new System.Windows.Forms.TableLayoutPanel();
            this.label135 = new System.Windows.Forms.Label();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel51 = new System.Windows.Forms.TableLayoutPanel();
            this.label136 = new System.Windows.Forms.Label();
            this.button16 = new System.Windows.Forms.Button();
            this.tableLayoutPanel52 = new System.Windows.Forms.TableLayoutPanel();
            this.button17 = new System.Windows.Forms.Button();
            this.label137 = new System.Windows.Forms.Label();
            this.tableLayoutPanel53 = new System.Windows.Forms.TableLayoutPanel();
            this.label138 = new System.Windows.Forms.Label();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel54 = new System.Windows.Forms.TableLayoutPanel();
            this.label139 = new System.Windows.Forms.Label();
            this.button18 = new System.Windows.Forms.Button();
            this.label140 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel43 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel44 = new System.Windows.Forms.TableLayoutPanel();
            this.label129 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel45 = new System.Windows.Forms.TableLayoutPanel();
            this.label130 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.tableLayoutPanel46 = new System.Windows.Forms.TableLayoutPanel();
            this.button14 = new System.Windows.Forms.Button();
            this.label131 = new System.Windows.Forms.Label();
            this.tableLayoutPanel47 = new System.Windows.Forms.TableLayoutPanel();
            this.label132 = new System.Windows.Forms.Label();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel48 = new System.Windows.Forms.TableLayoutPanel();
            this.label133 = new System.Windows.Forms.Label();
            this.button15 = new System.Windows.Forms.Button();
            this.label134 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel37 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel38 = new System.Windows.Forms.TableLayoutPanel();
            this.label81 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel39 = new System.Windows.Forms.TableLayoutPanel();
            this.label124 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.tableLayoutPanel40 = new System.Windows.Forms.TableLayoutPanel();
            this.button11 = new System.Windows.Forms.Button();
            this.label125 = new System.Windows.Forms.Label();
            this.tableLayoutPanel41 = new System.Windows.Forms.TableLayoutPanel();
            this.label126 = new System.Windows.Forms.Label();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel42 = new System.Windows.Forms.TableLayoutPanel();
            this.label127 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.label128 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel35 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel36 = new System.Windows.Forms.TableLayoutPanel();
            this.label122 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel55 = new System.Windows.Forms.TableLayoutPanel();
            this.label121 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.tableLayoutPanel56 = new System.Windows.Forms.TableLayoutPanel();
            this.button8 = new System.Windows.Forms.Button();
            this.label120 = new System.Windows.Forms.Label();
            this.tableLayoutPanel57 = new System.Windows.Forms.TableLayoutPanel();
            this.label118 = new System.Windows.Forms.Label();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel58 = new System.Windows.Forms.TableLayoutPanel();
            this.label119 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.label117 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_Trace_actual_weld_ct_la = new System.Windows.Forms.TextBox();
            this.txt_Trace_sp_la = new System.Windows.Forms.TextBox();
            this.txt_Trace_test_result_xy = new System.Windows.Forms.TextBox();
            this.txt_Trace_test_result_la = new System.Windows.Forms.TextBox();
            this.txt_Trace_unit_serial_number_xy = new System.Windows.Forms.TextBox();
            this.txt_Trace_unit_serial_number_la = new System.Windows.Forms.TextBox();
            this.txt_Trace_fixture_id_xy = new System.Windows.Forms.TextBox();
            this.txt_Trace_fixture_id_la = new System.Windows.Forms.TextBox();
            this.txt_Trace_uut_start_zy = new System.Windows.Forms.TextBox();
            this.txt_Trace_uut_start_la = new System.Windows.Forms.TextBox();
            this.txt_Trace_assy_start_time_xy = new System.Windows.Forms.TextBox();
            this.txt_Trace_weld_start_time_la = new System.Windows.Forms.TextBox();
            this.txt_Trace_assy_stop_time_xy = new System.Windows.Forms.TextBox();
            this.txt_Trace_weld_stop_time_la = new System.Windows.Forms.TextBox();
            this.txt_Trace_uut_stop_xy = new System.Windows.Forms.TextBox();
            this.txt_Trace_uut_stop_la = new System.Windows.Forms.TextBox();
            this.txt_Trace_assy_ct_xy = new System.Windows.Forms.TextBox();
            this.txt_Trace_weld_wait_ct_la = new System.Windows.Forms.TextBox();
            this.txt_Trace_actual_weld_ct_ua = new System.Windows.Forms.TextBox();
            this.lb_Trace_XY_SendStatus = new System.Windows.Forms.Label();
            this.lb_Trace_LA_SendStatus = new System.Windows.Forms.Label();
            this.txt_Trace_band_xy = new System.Windows.Forms.TextBox();
            this.rtx_TraceMsg = new System.Windows.Forms.RichTextBox();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.lb_TraceLANG = new System.Windows.Forms.Label();
            this.lb_TraceXYNG = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.lb_TraceXYOK = new System.Windows.Forms.Label();
            this.lb_TraceSendNG = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lb_TraceLAOK = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.Paoliaolv = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.Paoliaoshu = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.Lianglv = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.NGCount = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.TotalCount = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.CT = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.splitContainer7 = new System.Windows.Forms.SplitContainer();
            this.tableLayoutPanel23 = new System.Windows.Forms.TableLayoutPanel();
            this.label97 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.txt_PDCA_actual_weld_ct_la = new System.Windows.Forms.TextBox();
            this.txt_PDCA_sp_la = new System.Windows.Forms.TextBox();
            this.txt_PDCA_test_result_ua = new System.Windows.Forms.TextBox();
            this.txt_PDCA_test_result_la = new System.Windows.Forms.TextBox();
            this.txt_PDCA_unit_serial_number_ua = new System.Windows.Forms.TextBox();
            this.txt_PDCA_unit_serial_number_la = new System.Windows.Forms.TextBox();
            this.txt_PDCA_fixture_id_ua = new System.Windows.Forms.TextBox();
            this.txt_PDCA_fixture_id_la = new System.Windows.Forms.TextBox();
            this.txt_PDCA_uut_start_ua = new System.Windows.Forms.TextBox();
            this.txt_PDCA_uut_start_la = new System.Windows.Forms.TextBox();
            this.txt_PDCA_weld_start_time_ua = new System.Windows.Forms.TextBox();
            this.txt_PDCA_weld_start_time_la = new System.Windows.Forms.TextBox();
            this.txt_PDCA_weld_stop_time_ua = new System.Windows.Forms.TextBox();
            this.txt_PDCA_weld_stop_time_la = new System.Windows.Forms.TextBox();
            this.txt_PDCA_uut_stop_ua = new System.Windows.Forms.TextBox();
            this.txt_PDCA_uut_stop_la = new System.Windows.Forms.TextBox();
            this.txt_PDCA_weld_wait_ct_ua = new System.Windows.Forms.TextBox();
            this.txt_PDCA_weld_wait_ct_la = new System.Windows.Forms.TextBox();
            this.txt_PDCA_actual_weld_ct_ua = new System.Windows.Forms.TextBox();
            this.lb_PDCA_UA_SendStatus = new System.Windows.Forms.Label();
            this.lb_PDCA_LA_SendStatus = new System.Windows.Forms.Label();
            this.txt_PDCA_sp_ua = new System.Windows.Forms.TextBox();
            this.rtx_PDCAMsg = new System.Windows.Forms.RichTextBox();
            this.tableLayoutPanel24 = new System.Windows.Forms.TableLayoutPanel();
            this.lb_PDCALANG = new System.Windows.Forms.Label();
            this.lb_PDCALAOK = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.lb_PDCAUANG = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.lb_PDCAUAOK = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.lb_PDCASendNG = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.txtOEE_SerialNumber = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.txtOEE_Fixture = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.txtOEE_StartTime = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.txtOEE_EndTime = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.txtOEE_Status = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.txtOEE_ActualCT = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.txtOEE_sw = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.txtOEE_ScanCount = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.lb_OEE_UA_SendStatus = new System.Windows.Forms.Label();
            this.lb_OEE_LA_SendStatus = new System.Windows.Forms.Label();
            this.rtx_OEEDefaultMsg = new System.Windows.Forms.RichTextBox();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.lb_OEELANG = new System.Windows.Forms.Label();
            this.lb_OEELAOK = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.lb_OEEOK = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.lb_OEENG = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.lb_OEESendNG = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rtx_HeartBeatMsg = new System.Windows.Forms.RichTextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rtx_DownTimeMsg = new System.Windows.Forms.RichTextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.rtx_OEEMateriel = new System.Windows.Forms.RichTextBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.lb_Materiel_AllOK = new System.Windows.Forms.Label();
            this.lb_Materiel_Nut = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.lb_Materiel_Total = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.lb_Materiel_AllNut = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.lb_Materiel_OK = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel25 = new System.Windows.Forms.TableLayoutPanel();
            this.label16 = new System.Windows.Forms.Label();
            this.OEE_index = new System.Windows.Forms.TextBox();
            this.OEE_labal = new System.Windows.Forms.Label();
            this.OEE_upload = new System.Windows.Forms.Button();
            this.OEE_uploadAll = new System.Windows.Forms.Button();
            this.rtx_OEEMsg = new System.Windows.Forms.RichTextBox();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.splitContainer5 = new System.Windows.Forms.SplitContainer();
            this.tableLayoutPanel17 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox31 = new System.Windows.Forms.GroupBox();
            this.rtx_ProcessControlErrorMsg = new System.Windows.Forms.RichTextBox();
            this.tableLayoutPanel19 = new System.Windows.Forms.TableLayoutPanel();
            this.label123 = new System.Windows.Forms.Label();
            this.txt_ProcessControl_SN = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.txt_ProcessControl_Status = new System.Windows.Forms.Label();
            this.rtx_ProcessControl = new System.Windows.Forms.RichTextBox();
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.lb_ProcessControlNG = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.lb_ProcessControlOK = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel20 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel21 = new System.Windows.Forms.TableLayoutPanel();
            this.CB_Station = new System.Windows.Forms.ComboBox();
            this.CB_project = new System.Windows.Forms.ComboBox();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.CB_Type = new System.Windows.Forms.ComboBox();
            this.button19 = new System.Windows.Forms.Button();
            this.tableLayoutPanel22 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.list_IQCFixture = new System.Windows.Forms.ListBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.list_FixtureMsg = new System.Windows.Forms.ListBox();
            this.tableLayoutPanel59 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.list_IQCFixtureNG = new System.Windows.Forms.ListBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.list_FixtureMsgNG = new System.Windows.Forms.ListBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel60 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel61 = new System.Windows.Forms.TableLayoutPanel();
            this.label92 = new System.Windows.Forms.Label();
            this.txt_Fixture_Mantain_Count = new System.Windows.Forms.TextBox();
            this.label93 = new System.Windows.Forms.Label();
            this.txt_Fixture_Mantain_Time = new System.Windows.Forms.TextBox();
            this.btn_Fixture_Clear = new System.Windows.Forms.Button();
            this.btn_Fixture_Add = new System.Windows.Forms.Button();
            this.btn_Fixture_Delete = new System.Windows.Forms.Button();
            this.btn_Fixture_Out = new System.Windows.Forms.Button();
            this.grid_AllFixture = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel62 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel63 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel64 = new System.Windows.Forms.TableLayoutPanel();
            this.grid_TossingFixture = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel65 = new System.Windows.Forms.TableLayoutPanel();
            this.txt_Fixture_CountNG = new System.Windows.Forms.ComboBox();
            this.button24 = new System.Windows.Forms.Button();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.btn_Setting_Limit = new System.Windows.Forms.Button();
            this.txt_Fixture_ContinuationNG = new System.Windows.Forms.ComboBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.btn_Outputfixture = new System.Windows.Forms.Button();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel66 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel67 = new System.Windows.Forms.TableLayoutPanel();
            this.label96 = new System.Windows.Forms.Label();
            this.label141 = new System.Windows.Forms.Label();
            this.txt_SelectFixture = new System.Windows.Forms.TextBox();
            this.dtp_SelectFixture = new System.Windows.Forms.DateTimePicker();
            this.btn_SelectFixture = new System.Windows.Forms.Button();
            this.list_FixtureNG = new System.Windows.Forms.ListBox();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel68 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel72 = new System.Windows.Forms.TableLayoutPanel();
            this.label183 = new System.Windows.Forms.Label();
            this.label185 = new System.Windows.Forms.Label();
            this.label186 = new System.Windows.Forms.Label();
            this.label187 = new System.Windows.Forms.Label();
            this.label188 = new System.Windows.Forms.Label();
            this.label190 = new System.Windows.Forms.Label();
            this.label192 = new System.Windows.Forms.Label();
            this.label193 = new System.Windows.Forms.Label();
            this.label195 = new System.Windows.Forms.Label();
            this.label196 = new System.Windows.Forms.Label();
            this.label197 = new System.Windows.Forms.Label();
            this.label198 = new System.Windows.Forms.Label();
            this.label199 = new System.Windows.Forms.Label();
            this.label202 = new System.Windows.Forms.Label();
            this.label203 = new System.Windows.Forms.Label();
            this.tableLayoutPanel69 = new System.Windows.Forms.TableLayoutPanel();
            this.label155 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.label153 = new System.Windows.Forms.Label();
            this.label146 = new System.Windows.Forms.Label();
            this.label145 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label144 = new System.Windows.Forms.Label();
            this.label151 = new System.Windows.Forms.Label();
            this.label154 = new System.Windows.Forms.Label();
            this.label156 = new System.Windows.Forms.Label();
            this.label159 = new System.Windows.Forms.Label();
            this.label161 = new System.Windows.Forms.Label();
            this.label162 = new System.Windows.Forms.Label();
            this.label163 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label148 = new System.Windows.Forms.Label();
            this.label147 = new System.Windows.Forms.Label();
            this.label158 = new System.Windows.Forms.Label();
            this.label164 = new System.Windows.Forms.Label();
            this.label149 = new System.Windows.Forms.Label();
            this.label165 = new System.Windows.Forms.Label();
            this.label167 = new System.Windows.Forms.Label();
            this.scottRealWaveL = new ScottPlot.FormsPlot();
            this.scottRealWaveR = new ScottPlot.FormsPlot();
            this.dplusRTB = new System.Windows.Forms.RichTextBox();
            this.label166 = new System.Windows.Forms.Label();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel70 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel71 = new System.Windows.Forms.TableLayoutPanel();
            this.label116 = new System.Windows.Forms.Label();
            this.label142 = new System.Windows.Forms.Label();
            this.label150 = new System.Windows.Forms.Label();
            this.label152 = new System.Windows.Forms.Label();
            this.label157 = new System.Windows.Forms.Label();
            this.label160 = new System.Windows.Forms.Label();
            this.label168 = new System.Windows.Forms.Label();
            this.label169 = new System.Windows.Forms.Label();
            this.label170 = new System.Windows.Forms.Label();
            this.label171 = new System.Windows.Forms.Label();
            this.label172 = new System.Windows.Forms.Label();
            this.label173 = new System.Windows.Forms.Label();
            this.label174 = new System.Windows.Forms.Label();
            this.label175 = new System.Windows.Forms.Label();
            this.label176 = new System.Windows.Forms.Label();
            this.label177 = new System.Windows.Forms.Label();
            this.label178 = new System.Windows.Forms.Label();
            this.label179 = new System.Windows.Forms.Label();
            this.label180 = new System.Windows.Forms.Label();
            this.label181 = new System.Windows.Forms.Label();
            this.label182 = new System.Windows.Forms.Label();
            this.formsPlot1 = new ScottPlot.FormsPlot();
            this.formsPlot2 = new ScottPlot.FormsPlot();
            this.label184 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button20 = new System.Windows.Forms.Button();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.label70 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tableLayoutPanel26.SuspendLayout();
            this.tableLayoutPanel27.SuspendLayout();
            this.tableLayoutPanel28.SuspendLayout();
            this.tableLayoutPanel29.SuspendLayout();
            this.tableLayoutPanel30.SuspendLayout();
            this.tableLayoutPanel31.SuspendLayout();
            this.tableLayoutPanel32.SuspendLayout();
            this.tableLayoutPanel33.SuspendLayout();
            this.tableLayoutPanel34.SuspendLayout();
            this.panel5.SuspendLayout();
            this.tableLayoutPanel49.SuspendLayout();
            this.tableLayoutPanel50.SuspendLayout();
            this.tableLayoutPanel51.SuspendLayout();
            this.tableLayoutPanel52.SuspendLayout();
            this.tableLayoutPanel53.SuspendLayout();
            this.tableLayoutPanel54.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tableLayoutPanel43.SuspendLayout();
            this.tableLayoutPanel44.SuspendLayout();
            this.tableLayoutPanel45.SuspendLayout();
            this.tableLayoutPanel46.SuspendLayout();
            this.tableLayoutPanel47.SuspendLayout();
            this.tableLayoutPanel48.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel37.SuspendLayout();
            this.tableLayoutPanel38.SuspendLayout();
            this.tableLayoutPanel39.SuspendLayout();
            this.tableLayoutPanel40.SuspendLayout();
            this.tableLayoutPanel41.SuspendLayout();
            this.tableLayoutPanel42.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel35.SuspendLayout();
            this.tableLayoutPanel36.SuspendLayout();
            this.tableLayoutPanel55.SuspendLayout();
            this.tableLayoutPanel56.SuspendLayout();
            this.tableLayoutPanel57.SuspendLayout();
            this.tableLayoutPanel58.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).BeginInit();
            this.splitContainer7.Panel1.SuspendLayout();
            this.splitContainer7.Panel2.SuspendLayout();
            this.splitContainer7.SuspendLayout();
            this.tableLayoutPanel23.SuspendLayout();
            this.tableLayoutPanel24.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel25.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).BeginInit();
            this.splitContainer5.Panel1.SuspendLayout();
            this.splitContainer5.Panel2.SuspendLayout();
            this.splitContainer5.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.groupBox31.SuspendLayout();
            this.tableLayoutPanel19.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tableLayoutPanel20.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.tableLayoutPanel59.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.tableLayoutPanel60.SuspendLayout();
            this.tableLayoutPanel61.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid_AllFixture)).BeginInit();
            this.tabPage13.SuspendLayout();
            this.tableLayoutPanel62.SuspendLayout();
            this.tableLayoutPanel63.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.tableLayoutPanel64.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid_TossingFixture)).BeginInit();
            this.tableLayoutPanel65.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.tableLayoutPanel66.SuspendLayout();
            this.tableLayoutPanel67.SuspendLayout();
            this.tabPage14.SuspendLayout();
            this.tabControl4.SuspendLayout();
            this.tabPage15.SuspendLayout();
            this.tableLayoutPanel68.SuspendLayout();
            this.tableLayoutPanel72.SuspendLayout();
            this.tableLayoutPanel69.SuspendLayout();
            this.tabPage16.SuspendLayout();
            this.tableLayoutPanel70.SuspendLayout();
            this.tableLayoutPanel71.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage10);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage11);
            this.tabControl1.Controls.Add(this.tabPage12);
            this.tabControl1.Controls.Add(this.tabPage14);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.tabControl1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.ItemSize = new System.Drawing.Size(30, 120);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(969, 500);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 1;
            this.tabControl1.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.tabControl1_DrawItem);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.tableLayoutPanel26);
            this.tabPage5.Location = new System.Drawing.Point(124, 4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(841, 492);
            this.tabPage5.TabIndex = 7;
            this.tabPage5.Text = "主界面";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel26
            // 
            this.tableLayoutPanel26.ColumnCount = 2;
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel26.Controls.Add(this.tableLayoutPanel27, 0, 0);
            this.tableLayoutPanel26.Controls.Add(this.tableLayoutPanel34, 1, 0);
            this.tableLayoutPanel26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel26.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel26.Name = "tableLayoutPanel26";
            this.tableLayoutPanel26.RowCount = 1;
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel26.Size = new System.Drawing.Size(841, 492);
            this.tableLayoutPanel26.TabIndex = 1;
            // 
            // tableLayoutPanel27
            // 
            this.tableLayoutPanel27.ColumnCount = 1;
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel27.Controls.Add(this.tableLayoutPanel28, 0, 0);
            this.tableLayoutPanel27.Controls.Add(this.tableLayoutPanel29, 0, 1);
            this.tableLayoutPanel27.Controls.Add(this.tableLayoutPanel30, 0, 2);
            this.tableLayoutPanel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel27.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel27.Name = "tableLayoutPanel27";
            this.tableLayoutPanel27.RowCount = 3;
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel27.Size = new System.Drawing.Size(414, 486);
            this.tableLayoutPanel27.TabIndex = 0;
            // 
            // tableLayoutPanel28
            // 
            this.tableLayoutPanel28.ColumnCount = 3;
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel28.Controls.Add(this.button4, 0, 1);
            this.tableLayoutPanel28.Controls.Add(this.button6, 2, 1);
            this.tableLayoutPanel28.Controls.Add(this.button5, 1, 1);
            this.tableLayoutPanel28.Controls.Add(this.button3, 2, 0);
            this.tableLayoutPanel28.Controls.Add(this.button2, 1, 0);
            this.tableLayoutPanel28.Controls.Add(this.button1, 0, 0);
            this.tableLayoutPanel28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel28.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel28.Name = "tableLayoutPanel28";
            this.tableLayoutPanel28.RowCount = 2;
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel28.Size = new System.Drawing.Size(408, 139);
            this.tableLayoutPanel28.TabIndex = 0;
            // 
            // button4
            // 
            this.button4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button4.Location = new System.Drawing.Point(14, 82);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(108, 43);
            this.button4.TabIndex = 6;
            this.button4.Text = "保留";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button6.Location = new System.Drawing.Point(286, 82);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(108, 43);
            this.button6.TabIndex = 5;
            this.button6.Text = "数据清零";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button5.Location = new System.Drawing.Point(150, 82);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(108, 43);
            this.button5.TabIndex = 4;
            this.button5.Text = "复位Robot";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button3.Location = new System.Drawing.Point(286, 13);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(108, 43);
            this.button3.TabIndex = 2;
            this.button3.Text = "照明灯开关";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button2.Location = new System.Drawing.Point(150, 13);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(108, 43);
            this.button2.TabIndex = 1;
            this.button2.Text = "复位";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.Location = new System.Drawing.Point(14, 13);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(108, 43);
            this.button1.TabIndex = 0;
            this.button1.Text = "初始化";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel29
            // 
            this.tableLayoutPanel29.ColumnCount = 6;
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel29.Controls.Add(this.txt_Count, 1, 1);
            this.tableLayoutPanel29.Controls.Add(this.txt_NGcount, 1, 2);
            this.tableLayoutPanel29.Controls.Add(this.label20, 0, 1);
            this.tableLayoutPanel29.Controls.Add(this.label22, 0, 2);
            this.tableLayoutPanel29.Controls.Add(this.label24, 0, 3);
            this.tableLayoutPanel29.Controls.Add(this.label58, 0, 4);
            this.tableLayoutPanel29.Controls.Add(this.label18, 0, 5);
            this.tableLayoutPanel29.Controls.Add(this.txt_lianglv, 1, 3);
            this.tableLayoutPanel29.Controls.Add(this.txt_paoliao, 1, 4);
            this.tableLayoutPanel29.Controls.Add(this.label73, 0, 0);
            this.tableLayoutPanel29.Controls.Add(this.txt_CT, 1, 0);
            this.tableLayoutPanel29.Controls.Add(this.txt_paoliaolv, 1, 5);
            this.tableLayoutPanel29.Controls.Add(this.textBox13, 3, 0);
            this.tableLayoutPanel29.Controls.Add(this.textBox14, 3, 1);
            this.tableLayoutPanel29.Controls.Add(this.textBox8, 3, 2);
            this.tableLayoutPanel29.Controls.Add(this.label79, 2, 0);
            this.tableLayoutPanel29.Controls.Add(this.label80, 2, 1);
            this.tableLayoutPanel29.Controls.Add(this.label75, 2, 2);
            this.tableLayoutPanel29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel29.Location = new System.Drawing.Point(3, 148);
            this.tableLayoutPanel29.Name = "tableLayoutPanel29";
            this.tableLayoutPanel29.RowCount = 6;
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel29.Size = new System.Drawing.Size(408, 188);
            this.tableLayoutPanel29.TabIndex = 1;
            // 
            // txt_Count
            // 
            this.txt_Count.Location = new System.Drawing.Point(70, 34);
            this.txt_Count.Name = "txt_Count";
            this.txt_Count.Size = new System.Drawing.Size(61, 22);
            this.txt_Count.TabIndex = 2;
            this.txt_Count.Text = "0";
            this.txt_Count.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt_NGcount
            // 
            this.txt_NGcount.Location = new System.Drawing.Point(70, 65);
            this.txt_NGcount.Name = "txt_NGcount";
            this.txt_NGcount.Size = new System.Drawing.Size(61, 22);
            this.txt_NGcount.TabIndex = 3;
            this.txt_NGcount.Text = "0";
            this.txt_NGcount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Location = new System.Drawing.Point(3, 31);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(61, 31);
            this.label20.TabIndex = 4;
            this.label20.Text = "生产总数";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.Location = new System.Drawing.Point(3, 62);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(61, 31);
            this.label22.TabIndex = 5;
            this.label22.Text = "生产NG数";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label24.Location = new System.Drawing.Point(3, 93);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(61, 31);
            this.label24.TabIndex = 6;
            this.label24.Text = "生产良率";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label58.Location = new System.Drawing.Point(3, 124);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(61, 31);
            this.label58.TabIndex = 7;
            this.label58.Text = "抛料数";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Location = new System.Drawing.Point(3, 155);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(61, 33);
            this.label18.TabIndex = 8;
            this.label18.Text = "抛料率";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txt_lianglv
            // 
            this.txt_lianglv.Location = new System.Drawing.Point(70, 96);
            this.txt_lianglv.Name = "txt_lianglv";
            this.txt_lianglv.Size = new System.Drawing.Size(61, 22);
            this.txt_lianglv.TabIndex = 21;
            this.txt_lianglv.Text = "0.00";
            this.txt_lianglv.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt_paoliao
            // 
            this.txt_paoliao.Location = new System.Drawing.Point(70, 127);
            this.txt_paoliao.Name = "txt_paoliao";
            this.txt_paoliao.Size = new System.Drawing.Size(61, 22);
            this.txt_paoliao.TabIndex = 22;
            this.txt_paoliao.Text = "0";
            this.txt_paoliao.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label73.Location = new System.Drawing.Point(3, 0);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(61, 31);
            this.label73.TabIndex = 32;
            this.label73.Text = "CT(S)";
            this.label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txt_CT
            // 
            this.txt_CT.Location = new System.Drawing.Point(70, 3);
            this.txt_CT.Name = "txt_CT";
            this.txt_CT.Size = new System.Drawing.Size(61, 22);
            this.txt_CT.TabIndex = 23;
            this.txt_CT.Text = "0.0";
            this.txt_CT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt_paoliaolv
            // 
            this.txt_paoliaolv.Location = new System.Drawing.Point(70, 158);
            this.txt_paoliaolv.Name = "txt_paoliaolv";
            this.txt_paoliaolv.Size = new System.Drawing.Size(61, 22);
            this.txt_paoliaolv.TabIndex = 33;
            this.txt_paoliaolv.Text = "0.00";
            this.txt_paoliaolv.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(204, 3);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(61, 22);
            this.textBox13.TabIndex = 30;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(204, 34);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(61, 22);
            this.textBox14.TabIndex = 31;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(204, 65);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(61, 22);
            this.textBox8.TabIndex = 35;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label79.Location = new System.Drawing.Point(137, 0);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(61, 31);
            this.label79.TabIndex = 15;
            this.label79.Text = "Trace状态";
            this.label79.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label80.Location = new System.Drawing.Point(137, 31);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(61, 31);
            this.label80.TabIndex = 16;
            this.label80.Text = "PDCA状态";
            this.label80.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label75.Location = new System.Drawing.Point(137, 62);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(61, 31);
            this.label75.TabIndex = 34;
            this.label75.Text = "OEE状态";
            this.label75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel30
            // 
            this.tableLayoutPanel30.ColumnCount = 2;
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel30.Controls.Add(this.tableLayoutPanel31, 0, 0);
            this.tableLayoutPanel30.Controls.Add(this.tableLayoutPanel33, 1, 0);
            this.tableLayoutPanel30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel30.Location = new System.Drawing.Point(3, 342);
            this.tableLayoutPanel30.Name = "tableLayoutPanel30";
            this.tableLayoutPanel30.RowCount = 1;
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel30.Size = new System.Drawing.Size(408, 141);
            this.tableLayoutPanel30.TabIndex = 2;
            // 
            // tableLayoutPanel31
            // 
            this.tableLayoutPanel31.ColumnCount = 1;
            this.tableLayoutPanel31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel31.Controls.Add(this.label78, 0, 1);
            this.tableLayoutPanel31.Controls.Add(this.tableLayoutPanel32, 0, 0);
            this.tableLayoutPanel31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel31.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel31.Name = "tableLayoutPanel31";
            this.tableLayoutPanel31.RowCount = 2;
            this.tableLayoutPanel31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 82.96296F));
            this.tableLayoutPanel31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.03704F));
            this.tableLayoutPanel31.Size = new System.Drawing.Size(198, 135);
            this.tableLayoutPanel31.TabIndex = 0;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label78.Location = new System.Drawing.Point(3, 111);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(192, 24);
            this.label78.TabIndex = 0;
            this.label78.Text = "料盘穴位分布";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel32
            // 
            this.tableLayoutPanel32.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel32.ColumnCount = 2;
            this.tableLayoutPanel32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel32.Controls.Add(this.label94, 1, 1);
            this.tableLayoutPanel32.Controls.Add(this.label76, 0, 1);
            this.tableLayoutPanel32.Controls.Add(this.label87, 1, 0);
            this.tableLayoutPanel32.Controls.Add(this.label77, 0, 0);
            this.tableLayoutPanel32.Controls.Add(this.label84, 1, 2);
            this.tableLayoutPanel32.Controls.Add(this.label85, 0, 2);
            this.tableLayoutPanel32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel32.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel32.Name = "tableLayoutPanel32";
            this.tableLayoutPanel32.RowCount = 3;
            this.tableLayoutPanel32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel32.Size = new System.Drawing.Size(192, 105);
            this.tableLayoutPanel32.TabIndex = 1;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label94.Location = new System.Drawing.Point(99, 35);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(89, 33);
            this.label94.TabIndex = 5;
            this.label94.Text = "③";
            this.label94.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label76.Location = new System.Drawing.Point(4, 35);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(88, 33);
            this.label76.TabIndex = 4;
            this.label76.Text = "④";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label87.Location = new System.Drawing.Point(99, 1);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(89, 33);
            this.label87.TabIndex = 3;
            this.label87.Text = "⑤";
            this.label87.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label77.Location = new System.Drawing.Point(4, 1);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(88, 33);
            this.label77.TabIndex = 2;
            this.label77.Text = "⑥";
            this.label77.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label84.Location = new System.Drawing.Point(99, 69);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(89, 35);
            this.label84.TabIndex = 0;
            this.label84.Text = "①";
            this.label84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label85.Location = new System.Drawing.Point(4, 69);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(88, 35);
            this.label85.TabIndex = 1;
            this.label85.Text = "②";
            this.label85.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel33
            // 
            this.tableLayoutPanel33.ColumnCount = 2;
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel33.Controls.Add(this.textBox18, 1, 1);
            this.tableLayoutPanel33.Controls.Add(this.label110, 0, 0);
            this.tableLayoutPanel33.Controls.Add(this.label113, 0, 1);
            this.tableLayoutPanel33.Controls.Add(this.textBox12, 1, 0);
            this.tableLayoutPanel33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel33.Location = new System.Drawing.Point(207, 3);
            this.tableLayoutPanel33.Name = "tableLayoutPanel33";
            this.tableLayoutPanel33.RowCount = 3;
            this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel33.Size = new System.Drawing.Size(198, 135);
            this.tableLayoutPanel33.TabIndex = 1;
            // 
            // textBox18
            // 
            this.textBox18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox18.Location = new System.Drawing.Point(62, 56);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(133, 22);
            this.textBox18.TabIndex = 4;
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label110.Location = new System.Drawing.Point(3, 0);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(53, 45);
            this.label110.TabIndex = 0;
            this.label110.Text = "产品码";
            this.label110.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label113.Location = new System.Drawing.Point(3, 45);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(53, 45);
            this.label113.TabIndex = 1;
            this.label113.Text = "治具码";
            this.label113.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox12
            // 
            this.textBox12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox12.Location = new System.Drawing.Point(62, 11);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(133, 22);
            this.textBox12.TabIndex = 3;
            // 
            // tableLayoutPanel34
            // 
            this.tableLayoutPanel34.ColumnCount = 2;
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel34.Controls.Add(this.panel5, 1, 1);
            this.tableLayoutPanel34.Controls.Add(this.panel4, 0, 1);
            this.tableLayoutPanel34.Controls.Add(this.panel3, 1, 0);
            this.tableLayoutPanel34.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel34.Location = new System.Drawing.Point(423, 3);
            this.tableLayoutPanel34.Name = "tableLayoutPanel34";
            this.tableLayoutPanel34.RowCount = 2;
            this.tableLayoutPanel34.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel34.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel34.Size = new System.Drawing.Size(415, 486);
            this.tableLayoutPanel34.TabIndex = 1;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.tableLayoutPanel49);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(210, 246);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(202, 237);
            this.panel5.TabIndex = 3;
            // 
            // tableLayoutPanel49
            // 
            this.tableLayoutPanel49.ColumnCount = 1;
            this.tableLayoutPanel49.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel49.Controls.Add(this.tableLayoutPanel50, 0, 5);
            this.tableLayoutPanel49.Controls.Add(this.tableLayoutPanel51, 0, 4);
            this.tableLayoutPanel49.Controls.Add(this.tableLayoutPanel52, 0, 3);
            this.tableLayoutPanel49.Controls.Add(this.tableLayoutPanel53, 0, 1);
            this.tableLayoutPanel49.Controls.Add(this.tableLayoutPanel54, 0, 2);
            this.tableLayoutPanel49.Controls.Add(this.label140, 0, 0);
            this.tableLayoutPanel49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel49.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel49.Name = "tableLayoutPanel49";
            this.tableLayoutPanel49.RowCount = 6;
            this.tableLayoutPanel49.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel49.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel49.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel49.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel49.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel49.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel49.Size = new System.Drawing.Size(200, 235);
            this.tableLayoutPanel49.TabIndex = 1;
            // 
            // tableLayoutPanel50
            // 
            this.tableLayoutPanel50.ColumnCount = 2;
            this.tableLayoutPanel50.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel50.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel50.Controls.Add(this.label135, 0, 0);
            this.tableLayoutPanel50.Controls.Add(this.textBox32, 1, 0);
            this.tableLayoutPanel50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel50.Location = new System.Drawing.Point(3, 198);
            this.tableLayoutPanel50.Name = "tableLayoutPanel50";
            this.tableLayoutPanel50.RowCount = 1;
            this.tableLayoutPanel50.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel50.Size = new System.Drawing.Size(194, 34);
            this.tableLayoutPanel50.TabIndex = 3;
            // 
            // label135
            // 
            this.label135.AutoSize = true;
            this.label135.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label135.Location = new System.Drawing.Point(3, 0);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(91, 34);
            this.label135.TabIndex = 3;
            this.label135.Text = "CT";
            this.label135.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox32
            // 
            this.textBox32.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox32.Location = new System.Drawing.Point(118, 6);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(54, 22);
            this.textBox32.TabIndex = 4;
            this.textBox32.Text = "0";
            this.textBox32.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tableLayoutPanel51
            // 
            this.tableLayoutPanel51.ColumnCount = 2;
            this.tableLayoutPanel51.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel51.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel51.Controls.Add(this.label136, 0, 0);
            this.tableLayoutPanel51.Controls.Add(this.button16, 1, 0);
            this.tableLayoutPanel51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel51.Location = new System.Drawing.Point(3, 159);
            this.tableLayoutPanel51.Name = "tableLayoutPanel51";
            this.tableLayoutPanel51.RowCount = 1;
            this.tableLayoutPanel51.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel51.Size = new System.Drawing.Size(194, 33);
            this.tableLayoutPanel51.TabIndex = 3;
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label136.Location = new System.Drawing.Point(3, 0);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(91, 33);
            this.label136.TabIndex = 2;
            this.label136.Text = "产品正反";
            this.label136.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button16
            // 
            this.button16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button16.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button16.Location = new System.Drawing.Point(108, 5);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(75, 23);
            this.button16.TabIndex = 3;
            this.button16.Text = "正";
            this.button16.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel52
            // 
            this.tableLayoutPanel52.ColumnCount = 2;
            this.tableLayoutPanel52.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel52.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel52.Controls.Add(this.button17, 1, 0);
            this.tableLayoutPanel52.Controls.Add(this.label137, 0, 0);
            this.tableLayoutPanel52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel52.Location = new System.Drawing.Point(3, 120);
            this.tableLayoutPanel52.Name = "tableLayoutPanel52";
            this.tableLayoutPanel52.RowCount = 1;
            this.tableLayoutPanel52.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel52.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel52.Size = new System.Drawing.Size(194, 33);
            this.tableLayoutPanel52.TabIndex = 3;
            // 
            // button17
            // 
            this.button17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button17.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button17.Location = new System.Drawing.Point(108, 5);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(75, 23);
            this.button17.TabIndex = 2;
            this.button17.Text = "正";
            this.button17.UseVisualStyleBackColor = false;
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label137.Location = new System.Drawing.Point(3, 0);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(91, 33);
            this.label137.TabIndex = 1;
            this.label137.Text = "物料正反";
            this.label137.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel53
            // 
            this.tableLayoutPanel53.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel53.ColumnCount = 2;
            this.tableLayoutPanel53.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.5F));
            this.tableLayoutPanel53.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 74.5F));
            this.tableLayoutPanel53.Controls.Add(this.label138, 0, 0);
            this.tableLayoutPanel53.Controls.Add(this.textBox34, 1, 0);
            this.tableLayoutPanel53.Location = new System.Drawing.Point(3, 42);
            this.tableLayoutPanel53.Name = "tableLayoutPanel53";
            this.tableLayoutPanel53.RowCount = 1;
            this.tableLayoutPanel53.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel53.Size = new System.Drawing.Size(194, 33);
            this.tableLayoutPanel53.TabIndex = 1;
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label138.Location = new System.Drawing.Point(3, 0);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(43, 33);
            this.label138.TabIndex = 0;
            this.label138.Text = "状态:";
            this.label138.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox34
            // 
            this.textBox34.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox34.Location = new System.Drawing.Point(52, 5);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(139, 22);
            this.textBox34.TabIndex = 1;
            // 
            // tableLayoutPanel54
            // 
            this.tableLayoutPanel54.ColumnCount = 2;
            this.tableLayoutPanel54.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.76303F));
            this.tableLayoutPanel54.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.23697F));
            this.tableLayoutPanel54.Controls.Add(this.label139, 0, 0);
            this.tableLayoutPanel54.Controls.Add(this.button18, 1, 0);
            this.tableLayoutPanel54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel54.Location = new System.Drawing.Point(3, 81);
            this.tableLayoutPanel54.Name = "tableLayoutPanel54";
            this.tableLayoutPanel54.RowCount = 1;
            this.tableLayoutPanel54.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel54.Size = new System.Drawing.Size(194, 33);
            this.tableLayoutPanel54.TabIndex = 2;
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label139.Location = new System.Drawing.Point(3, 0);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(90, 33);
            this.label139.TabIndex = 0;
            this.label139.Text = "物料";
            this.label139.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button18
            // 
            this.button18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button18.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button18.Location = new System.Drawing.Point(107, 5);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(75, 23);
            this.button18.TabIndex = 1;
            this.button18.Text = "有料";
            this.button18.UseVisualStyleBackColor = false;
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label140.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label140.Location = new System.Drawing.Point(3, 0);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(194, 39);
            this.label140.TabIndex = 4;
            this.label140.Text = "4#工位";
            this.label140.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.tableLayoutPanel43);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(3, 246);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(201, 237);
            this.panel4.TabIndex = 2;
            // 
            // tableLayoutPanel43
            // 
            this.tableLayoutPanel43.ColumnCount = 1;
            this.tableLayoutPanel43.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel43.Controls.Add(this.tableLayoutPanel44, 0, 5);
            this.tableLayoutPanel43.Controls.Add(this.tableLayoutPanel45, 0, 4);
            this.tableLayoutPanel43.Controls.Add(this.tableLayoutPanel46, 0, 3);
            this.tableLayoutPanel43.Controls.Add(this.tableLayoutPanel47, 0, 1);
            this.tableLayoutPanel43.Controls.Add(this.tableLayoutPanel48, 0, 2);
            this.tableLayoutPanel43.Controls.Add(this.label134, 0, 0);
            this.tableLayoutPanel43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel43.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel43.Name = "tableLayoutPanel43";
            this.tableLayoutPanel43.RowCount = 6;
            this.tableLayoutPanel43.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel43.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel43.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel43.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel43.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel43.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel43.Size = new System.Drawing.Size(199, 235);
            this.tableLayoutPanel43.TabIndex = 1;
            // 
            // tableLayoutPanel44
            // 
            this.tableLayoutPanel44.ColumnCount = 2;
            this.tableLayoutPanel44.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel44.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel44.Controls.Add(this.label129, 0, 0);
            this.tableLayoutPanel44.Controls.Add(this.textBox28, 1, 0);
            this.tableLayoutPanel44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel44.Location = new System.Drawing.Point(3, 198);
            this.tableLayoutPanel44.Name = "tableLayoutPanel44";
            this.tableLayoutPanel44.RowCount = 1;
            this.tableLayoutPanel44.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel44.Size = new System.Drawing.Size(193, 34);
            this.tableLayoutPanel44.TabIndex = 3;
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label129.Location = new System.Drawing.Point(3, 0);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(90, 34);
            this.label129.TabIndex = 3;
            this.label129.Text = "CT";
            this.label129.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox28
            // 
            this.textBox28.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox28.Location = new System.Drawing.Point(117, 6);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(54, 22);
            this.textBox28.TabIndex = 4;
            this.textBox28.Text = "0";
            this.textBox28.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tableLayoutPanel45
            // 
            this.tableLayoutPanel45.ColumnCount = 2;
            this.tableLayoutPanel45.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel45.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel45.Controls.Add(this.label130, 0, 0);
            this.tableLayoutPanel45.Controls.Add(this.button13, 1, 0);
            this.tableLayoutPanel45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel45.Location = new System.Drawing.Point(3, 159);
            this.tableLayoutPanel45.Name = "tableLayoutPanel45";
            this.tableLayoutPanel45.RowCount = 1;
            this.tableLayoutPanel45.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel45.Size = new System.Drawing.Size(193, 33);
            this.tableLayoutPanel45.TabIndex = 3;
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label130.Location = new System.Drawing.Point(3, 0);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(90, 33);
            this.label130.TabIndex = 2;
            this.label130.Text = "产品正反";
            this.label130.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button13
            // 
            this.button13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button13.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button13.Location = new System.Drawing.Point(107, 5);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(75, 23);
            this.button13.TabIndex = 3;
            this.button13.Text = "正";
            this.button13.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel46
            // 
            this.tableLayoutPanel46.ColumnCount = 2;
            this.tableLayoutPanel46.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel46.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel46.Controls.Add(this.button14, 1, 0);
            this.tableLayoutPanel46.Controls.Add(this.label131, 0, 0);
            this.tableLayoutPanel46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel46.Location = new System.Drawing.Point(3, 120);
            this.tableLayoutPanel46.Name = "tableLayoutPanel46";
            this.tableLayoutPanel46.RowCount = 1;
            this.tableLayoutPanel46.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel46.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel46.Size = new System.Drawing.Size(193, 33);
            this.tableLayoutPanel46.TabIndex = 3;
            // 
            // button14
            // 
            this.button14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button14.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button14.Location = new System.Drawing.Point(107, 5);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(75, 23);
            this.button14.TabIndex = 2;
            this.button14.Text = "正";
            this.button14.UseVisualStyleBackColor = false;
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label131.Location = new System.Drawing.Point(3, 0);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(90, 33);
            this.label131.TabIndex = 1;
            this.label131.Text = "物料正反";
            this.label131.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel47
            // 
            this.tableLayoutPanel47.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel47.ColumnCount = 2;
            this.tableLayoutPanel47.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.5F));
            this.tableLayoutPanel47.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 74.5F));
            this.tableLayoutPanel47.Controls.Add(this.label132, 0, 0);
            this.tableLayoutPanel47.Controls.Add(this.textBox30, 1, 0);
            this.tableLayoutPanel47.Location = new System.Drawing.Point(3, 42);
            this.tableLayoutPanel47.Name = "tableLayoutPanel47";
            this.tableLayoutPanel47.RowCount = 1;
            this.tableLayoutPanel47.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel47.Size = new System.Drawing.Size(193, 33);
            this.tableLayoutPanel47.TabIndex = 1;
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label132.Location = new System.Drawing.Point(3, 0);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(43, 33);
            this.label132.TabIndex = 0;
            this.label132.Text = "状态:";
            this.label132.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox30
            // 
            this.textBox30.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox30.Location = new System.Drawing.Point(52, 5);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(138, 22);
            this.textBox30.TabIndex = 1;
            // 
            // tableLayoutPanel48
            // 
            this.tableLayoutPanel48.ColumnCount = 2;
            this.tableLayoutPanel48.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.76303F));
            this.tableLayoutPanel48.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.23697F));
            this.tableLayoutPanel48.Controls.Add(this.label133, 0, 0);
            this.tableLayoutPanel48.Controls.Add(this.button15, 1, 0);
            this.tableLayoutPanel48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel48.Location = new System.Drawing.Point(3, 81);
            this.tableLayoutPanel48.Name = "tableLayoutPanel48";
            this.tableLayoutPanel48.RowCount = 1;
            this.tableLayoutPanel48.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel48.Size = new System.Drawing.Size(193, 33);
            this.tableLayoutPanel48.TabIndex = 2;
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label133.Location = new System.Drawing.Point(3, 0);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(90, 33);
            this.label133.TabIndex = 0;
            this.label133.Text = "物料";
            this.label133.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button15
            // 
            this.button15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button15.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button15.Location = new System.Drawing.Point(107, 5);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(75, 23);
            this.button15.TabIndex = 1;
            this.button15.Text = "有料";
            this.button15.UseVisualStyleBackColor = false;
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label134.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label134.Location = new System.Drawing.Point(3, 0);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(193, 39);
            this.label134.TabIndex = 4;
            this.label134.Text = "3#工位";
            this.label134.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.tableLayoutPanel37);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(210, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(202, 237);
            this.panel3.TabIndex = 1;
            // 
            // tableLayoutPanel37
            // 
            this.tableLayoutPanel37.ColumnCount = 1;
            this.tableLayoutPanel37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel37.Controls.Add(this.tableLayoutPanel38, 0, 5);
            this.tableLayoutPanel37.Controls.Add(this.tableLayoutPanel39, 0, 4);
            this.tableLayoutPanel37.Controls.Add(this.tableLayoutPanel40, 0, 3);
            this.tableLayoutPanel37.Controls.Add(this.tableLayoutPanel41, 0, 1);
            this.tableLayoutPanel37.Controls.Add(this.tableLayoutPanel42, 0, 2);
            this.tableLayoutPanel37.Controls.Add(this.label128, 0, 0);
            this.tableLayoutPanel37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel37.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel37.Name = "tableLayoutPanel37";
            this.tableLayoutPanel37.RowCount = 6;
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel37.Size = new System.Drawing.Size(200, 235);
            this.tableLayoutPanel37.TabIndex = 1;
            // 
            // tableLayoutPanel38
            // 
            this.tableLayoutPanel38.ColumnCount = 2;
            this.tableLayoutPanel38.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel38.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel38.Controls.Add(this.label81, 0, 0);
            this.tableLayoutPanel38.Controls.Add(this.textBox24, 1, 0);
            this.tableLayoutPanel38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel38.Location = new System.Drawing.Point(3, 198);
            this.tableLayoutPanel38.Name = "tableLayoutPanel38";
            this.tableLayoutPanel38.RowCount = 1;
            this.tableLayoutPanel38.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel38.Size = new System.Drawing.Size(194, 34);
            this.tableLayoutPanel38.TabIndex = 3;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label81.Location = new System.Drawing.Point(3, 0);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(91, 34);
            this.label81.TabIndex = 3;
            this.label81.Text = "CT";
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox24
            // 
            this.textBox24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox24.Location = new System.Drawing.Point(118, 6);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(54, 22);
            this.textBox24.TabIndex = 4;
            this.textBox24.Text = "0";
            this.textBox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tableLayoutPanel39
            // 
            this.tableLayoutPanel39.ColumnCount = 2;
            this.tableLayoutPanel39.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel39.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel39.Controls.Add(this.label124, 0, 0);
            this.tableLayoutPanel39.Controls.Add(this.button10, 1, 0);
            this.tableLayoutPanel39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel39.Location = new System.Drawing.Point(3, 159);
            this.tableLayoutPanel39.Name = "tableLayoutPanel39";
            this.tableLayoutPanel39.RowCount = 1;
            this.tableLayoutPanel39.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel39.Size = new System.Drawing.Size(194, 33);
            this.tableLayoutPanel39.TabIndex = 3;
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label124.Location = new System.Drawing.Point(3, 0);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(91, 33);
            this.label124.TabIndex = 2;
            this.label124.Text = "产品正反";
            this.label124.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button10
            // 
            this.button10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button10.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button10.Location = new System.Drawing.Point(108, 5);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 23);
            this.button10.TabIndex = 3;
            this.button10.Text = "正";
            this.button10.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel40
            // 
            this.tableLayoutPanel40.ColumnCount = 2;
            this.tableLayoutPanel40.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel40.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel40.Controls.Add(this.button11, 1, 0);
            this.tableLayoutPanel40.Controls.Add(this.label125, 0, 0);
            this.tableLayoutPanel40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel40.Location = new System.Drawing.Point(3, 120);
            this.tableLayoutPanel40.Name = "tableLayoutPanel40";
            this.tableLayoutPanel40.RowCount = 1;
            this.tableLayoutPanel40.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel40.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel40.Size = new System.Drawing.Size(194, 33);
            this.tableLayoutPanel40.TabIndex = 3;
            // 
            // button11
            // 
            this.button11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button11.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button11.Location = new System.Drawing.Point(108, 5);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 23);
            this.button11.TabIndex = 2;
            this.button11.Text = "正";
            this.button11.UseVisualStyleBackColor = false;
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label125.Location = new System.Drawing.Point(3, 0);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(91, 33);
            this.label125.TabIndex = 1;
            this.label125.Text = "物料正反";
            this.label125.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel41
            // 
            this.tableLayoutPanel41.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel41.ColumnCount = 2;
            this.tableLayoutPanel41.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.5F));
            this.tableLayoutPanel41.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 74.5F));
            this.tableLayoutPanel41.Controls.Add(this.label126, 0, 0);
            this.tableLayoutPanel41.Controls.Add(this.textBox26, 1, 0);
            this.tableLayoutPanel41.Location = new System.Drawing.Point(3, 42);
            this.tableLayoutPanel41.Name = "tableLayoutPanel41";
            this.tableLayoutPanel41.RowCount = 1;
            this.tableLayoutPanel41.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel41.Size = new System.Drawing.Size(194, 32);
            this.tableLayoutPanel41.TabIndex = 1;
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label126.Location = new System.Drawing.Point(3, 0);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(43, 32);
            this.label126.TabIndex = 0;
            this.label126.Text = "状态:";
            this.label126.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox26
            // 
            this.textBox26.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox26.Location = new System.Drawing.Point(52, 5);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(139, 22);
            this.textBox26.TabIndex = 1;
            // 
            // tableLayoutPanel42
            // 
            this.tableLayoutPanel42.ColumnCount = 2;
            this.tableLayoutPanel42.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.76303F));
            this.tableLayoutPanel42.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.23697F));
            this.tableLayoutPanel42.Controls.Add(this.label127, 0, 0);
            this.tableLayoutPanel42.Controls.Add(this.button12, 1, 0);
            this.tableLayoutPanel42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel42.Location = new System.Drawing.Point(3, 81);
            this.tableLayoutPanel42.Name = "tableLayoutPanel42";
            this.tableLayoutPanel42.RowCount = 1;
            this.tableLayoutPanel42.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel42.Size = new System.Drawing.Size(194, 33);
            this.tableLayoutPanel42.TabIndex = 2;
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label127.Location = new System.Drawing.Point(3, 0);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(90, 33);
            this.label127.TabIndex = 0;
            this.label127.Text = "物料";
            this.label127.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button12
            // 
            this.button12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button12.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button12.Location = new System.Drawing.Point(107, 5);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 23);
            this.button12.TabIndex = 1;
            this.button12.Text = "有料";
            this.button12.UseVisualStyleBackColor = false;
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label128.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label128.Location = new System.Drawing.Point(3, 0);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(194, 39);
            this.label128.TabIndex = 4;
            this.label128.Text = "2#工位";
            this.label128.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.tableLayoutPanel35);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(201, 237);
            this.panel2.TabIndex = 0;
            // 
            // tableLayoutPanel35
            // 
            this.tableLayoutPanel35.ColumnCount = 1;
            this.tableLayoutPanel35.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel35.Controls.Add(this.tableLayoutPanel36, 0, 5);
            this.tableLayoutPanel35.Controls.Add(this.tableLayoutPanel55, 0, 4);
            this.tableLayoutPanel35.Controls.Add(this.tableLayoutPanel56, 0, 3);
            this.tableLayoutPanel35.Controls.Add(this.tableLayoutPanel57, 0, 1);
            this.tableLayoutPanel35.Controls.Add(this.tableLayoutPanel58, 0, 2);
            this.tableLayoutPanel35.Controls.Add(this.label117, 0, 0);
            this.tableLayoutPanel35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel35.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel35.Name = "tableLayoutPanel35";
            this.tableLayoutPanel35.RowCount = 6;
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel35.Size = new System.Drawing.Size(199, 235);
            this.tableLayoutPanel35.TabIndex = 1;
            // 
            // tableLayoutPanel36
            // 
            this.tableLayoutPanel36.ColumnCount = 2;
            this.tableLayoutPanel36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel36.Controls.Add(this.label122, 0, 0);
            this.tableLayoutPanel36.Controls.Add(this.textBox22, 1, 0);
            this.tableLayoutPanel36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel36.Location = new System.Drawing.Point(3, 198);
            this.tableLayoutPanel36.Name = "tableLayoutPanel36";
            this.tableLayoutPanel36.RowCount = 1;
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel36.Size = new System.Drawing.Size(193, 34);
            this.tableLayoutPanel36.TabIndex = 3;
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label122.Location = new System.Drawing.Point(3, 0);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(90, 34);
            this.label122.TabIndex = 3;
            this.label122.Text = "CT";
            this.label122.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox22
            // 
            this.textBox22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox22.Location = new System.Drawing.Point(117, 6);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(54, 22);
            this.textBox22.TabIndex = 4;
            this.textBox22.Text = "0";
            this.textBox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tableLayoutPanel55
            // 
            this.tableLayoutPanel55.ColumnCount = 2;
            this.tableLayoutPanel55.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel55.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel55.Controls.Add(this.label121, 0, 0);
            this.tableLayoutPanel55.Controls.Add(this.button9, 1, 0);
            this.tableLayoutPanel55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel55.Location = new System.Drawing.Point(3, 159);
            this.tableLayoutPanel55.Name = "tableLayoutPanel55";
            this.tableLayoutPanel55.RowCount = 1;
            this.tableLayoutPanel55.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel55.Size = new System.Drawing.Size(193, 33);
            this.tableLayoutPanel55.TabIndex = 3;
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label121.Location = new System.Drawing.Point(3, 0);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(90, 33);
            this.label121.TabIndex = 2;
            this.label121.Text = "产品正反";
            this.label121.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button9
            // 
            this.button9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button9.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button9.Location = new System.Drawing.Point(107, 5);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 3;
            this.button9.Text = "正";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel56
            // 
            this.tableLayoutPanel56.ColumnCount = 2;
            this.tableLayoutPanel56.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel56.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel56.Controls.Add(this.button8, 1, 0);
            this.tableLayoutPanel56.Controls.Add(this.label120, 0, 0);
            this.tableLayoutPanel56.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel56.Location = new System.Drawing.Point(3, 120);
            this.tableLayoutPanel56.Name = "tableLayoutPanel56";
            this.tableLayoutPanel56.RowCount = 1;
            this.tableLayoutPanel56.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel56.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel56.Size = new System.Drawing.Size(193, 33);
            this.tableLayoutPanel56.TabIndex = 3;
            // 
            // button8
            // 
            this.button8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button8.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button8.Location = new System.Drawing.Point(107, 5);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 2;
            this.button8.Text = "正";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label120.Location = new System.Drawing.Point(3, 0);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(90, 33);
            this.label120.TabIndex = 1;
            this.label120.Text = "物料正反";
            this.label120.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel57
            // 
            this.tableLayoutPanel57.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel57.ColumnCount = 2;
            this.tableLayoutPanel57.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.5F));
            this.tableLayoutPanel57.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 74.5F));
            this.tableLayoutPanel57.Controls.Add(this.label118, 0, 0);
            this.tableLayoutPanel57.Controls.Add(this.textBox20, 1, 0);
            this.tableLayoutPanel57.Location = new System.Drawing.Point(3, 42);
            this.tableLayoutPanel57.Name = "tableLayoutPanel57";
            this.tableLayoutPanel57.RowCount = 1;
            this.tableLayoutPanel57.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel57.Size = new System.Drawing.Size(193, 32);
            this.tableLayoutPanel57.TabIndex = 1;
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label118.Location = new System.Drawing.Point(3, 0);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(43, 32);
            this.label118.TabIndex = 0;
            this.label118.Text = "状态:";
            this.label118.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox20
            // 
            this.textBox20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox20.Location = new System.Drawing.Point(52, 5);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(138, 22);
            this.textBox20.TabIndex = 1;
            // 
            // tableLayoutPanel58
            // 
            this.tableLayoutPanel58.ColumnCount = 2;
            this.tableLayoutPanel58.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.76303F));
            this.tableLayoutPanel58.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.23697F));
            this.tableLayoutPanel58.Controls.Add(this.label119, 0, 0);
            this.tableLayoutPanel58.Controls.Add(this.button7, 1, 0);
            this.tableLayoutPanel58.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel58.Location = new System.Drawing.Point(3, 81);
            this.tableLayoutPanel58.Name = "tableLayoutPanel58";
            this.tableLayoutPanel58.RowCount = 1;
            this.tableLayoutPanel58.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel58.Size = new System.Drawing.Size(193, 33);
            this.tableLayoutPanel58.TabIndex = 2;
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label119.Location = new System.Drawing.Point(3, 0);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(90, 33);
            this.label119.TabIndex = 0;
            this.label119.Text = "物料";
            this.label119.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button7
            // 
            this.button7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button7.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button7.Location = new System.Drawing.Point(107, 5);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 1;
            this.button7.Text = "有料";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label117.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label117.Location = new System.Drawing.Point(3, 0);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(193, 39);
            this.label117.TabIndex = 4;
            this.label117.Text = "1#工位";
            this.label117.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tabPage1
            // 
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage1.Controls.Add(this.tableLayoutPanel9);
            this.tabPage1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(124, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(841, 492);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Trace";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 1;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Controls.Add(this.groupBox9, 0, 2);
            this.tableLayoutPanel9.Controls.Add(this.tableLayoutPanel8, 0, 1);
            this.tableLayoutPanel9.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 3;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(833, 484);
            this.tableLayoutPanel9.TabIndex = 6;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.splitContainer1);
            this.groupBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox9.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox9.Location = new System.Drawing.Point(3, 99);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(827, 382);
            this.groupBox9.TabIndex = 5;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "数据区";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(3, 19);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tableLayoutPanel1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.rtx_TraceMsg);
            this.splitContainer1.Size = new System.Drawing.Size(821, 360);
            this.splitContainer1.SplitterDistance = 492;
            this.splitContainer1.TabIndex = 1;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.30282F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.49296F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38F));
            this.tableLayoutPanel1.Controls.Add(this.label2, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label6, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.label9, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.label10, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.label11, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.label12, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.txt_Trace_actual_weld_ct_la, 2, 10);
            this.tableLayoutPanel1.Controls.Add(this.txt_Trace_sp_la, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.txt_Trace_test_result_xy, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.txt_Trace_test_result_la, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.txt_Trace_unit_serial_number_xy, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.txt_Trace_unit_serial_number_la, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.txt_Trace_fixture_id_xy, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.txt_Trace_fixture_id_la, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.txt_Trace_uut_start_zy, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.txt_Trace_uut_start_la, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.txt_Trace_assy_start_time_xy, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.txt_Trace_weld_start_time_la, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.txt_Trace_assy_stop_time_xy, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.txt_Trace_weld_stop_time_la, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.txt_Trace_uut_stop_xy, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.txt_Trace_uut_stop_la, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.txt_Trace_assy_ct_xy, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.txt_Trace_weld_wait_ct_la, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.txt_Trace_actual_weld_ct_ua, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.lb_Trace_XY_SendStatus, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.lb_Trace_LA_SendStatus, 2, 11);
            this.tableLayoutPanel1.Controls.Add(this.txt_Trace_band_xy, 1, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 12;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(492, 360);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(307, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(182, 29);
            this.label2.TabIndex = 156;
            this.label2.Text = "LA";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(108, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(193, 29);
            this.label1.TabIndex = 155;
            this.label1.Text = "XY Bracket";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.label3.Location = new System.Drawing.Point(3, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 29);
            this.label3.TabIndex = 157;
            this.label3.Text = "band:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.label4.Location = new System.Drawing.Point(3, 58);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 29);
            this.label4.TabIndex = 158;
            this.label4.Text = "test_result:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.label5.Location = new System.Drawing.Point(3, 87);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 29);
            this.label5.TabIndex = 159;
            this.label5.Text = "unit_serial_number:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.label6.Location = new System.Drawing.Point(3, 116);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 29);
            this.label6.TabIndex = 160;
            this.label6.Text = "fixture_id:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.label7.Location = new System.Drawing.Point(3, 145);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(99, 29);
            this.label7.TabIndex = 161;
            this.label7.Text = "uut_start:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.label8.Location = new System.Drawing.Point(3, 174);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(99, 29);
            this.label8.TabIndex = 162;
            this.label8.Text = "assy_start_time:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.label9.Location = new System.Drawing.Point(3, 203);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(99, 29);
            this.label9.TabIndex = 163;
            this.label9.Text = "assy_stop_time:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.label10.Location = new System.Drawing.Point(3, 232);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(99, 29);
            this.label10.TabIndex = 164;
            this.label10.Text = "uut_stop:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.label11.Location = new System.Drawing.Point(3, 261);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(99, 29);
            this.label11.TabIndex = 165;
            this.label11.Text = "assy_ct:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.label12.Location = new System.Drawing.Point(3, 290);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(99, 29);
            this.label12.TabIndex = 166;
            this.label12.Text = "actual_ct:";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label12.Visible = false;
            // 
            // txt_Trace_actual_weld_ct_la
            // 
            this.txt_Trace_actual_weld_ct_la.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_Trace_actual_weld_ct_la.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.txt_Trace_actual_weld_ct_la.Location = new System.Drawing.Point(307, 293);
            this.txt_Trace_actual_weld_ct_la.Name = "txt_Trace_actual_weld_ct_la";
            this.txt_Trace_actual_weld_ct_la.Size = new System.Drawing.Size(182, 25);
            this.txt_Trace_actual_weld_ct_la.TabIndex = 167;
            this.txt_Trace_actual_weld_ct_la.Visible = false;
            // 
            // txt_Trace_sp_la
            // 
            this.txt_Trace_sp_la.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_Trace_sp_la.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.txt_Trace_sp_la.Location = new System.Drawing.Point(307, 32);
            this.txt_Trace_sp_la.Name = "txt_Trace_sp_la";
            this.txt_Trace_sp_la.Size = new System.Drawing.Size(182, 25);
            this.txt_Trace_sp_la.TabIndex = 169;
            this.txt_Trace_sp_la.Visible = false;
            // 
            // txt_Trace_test_result_xy
            // 
            this.txt_Trace_test_result_xy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Trace_test_result_xy.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.txt_Trace_test_result_xy.Location = new System.Drawing.Point(108, 61);
            this.txt_Trace_test_result_xy.Name = "txt_Trace_test_result_xy";
            this.txt_Trace_test_result_xy.Size = new System.Drawing.Size(193, 25);
            this.txt_Trace_test_result_xy.TabIndex = 170;
            // 
            // txt_Trace_test_result_la
            // 
            this.txt_Trace_test_result_la.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_Trace_test_result_la.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.txt_Trace_test_result_la.Location = new System.Drawing.Point(307, 61);
            this.txt_Trace_test_result_la.Name = "txt_Trace_test_result_la";
            this.txt_Trace_test_result_la.Size = new System.Drawing.Size(182, 25);
            this.txt_Trace_test_result_la.TabIndex = 171;
            this.txt_Trace_test_result_la.Visible = false;
            // 
            // txt_Trace_unit_serial_number_xy
            // 
            this.txt_Trace_unit_serial_number_xy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Trace_unit_serial_number_xy.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.txt_Trace_unit_serial_number_xy.Location = new System.Drawing.Point(108, 90);
            this.txt_Trace_unit_serial_number_xy.Name = "txt_Trace_unit_serial_number_xy";
            this.txt_Trace_unit_serial_number_xy.Size = new System.Drawing.Size(193, 25);
            this.txt_Trace_unit_serial_number_xy.TabIndex = 172;
            // 
            // txt_Trace_unit_serial_number_la
            // 
            this.txt_Trace_unit_serial_number_la.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_Trace_unit_serial_number_la.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.txt_Trace_unit_serial_number_la.Location = new System.Drawing.Point(307, 90);
            this.txt_Trace_unit_serial_number_la.Name = "txt_Trace_unit_serial_number_la";
            this.txt_Trace_unit_serial_number_la.Size = new System.Drawing.Size(182, 25);
            this.txt_Trace_unit_serial_number_la.TabIndex = 173;
            this.txt_Trace_unit_serial_number_la.Visible = false;
            // 
            // txt_Trace_fixture_id_xy
            // 
            this.txt_Trace_fixture_id_xy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Trace_fixture_id_xy.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.txt_Trace_fixture_id_xy.Location = new System.Drawing.Point(108, 119);
            this.txt_Trace_fixture_id_xy.Name = "txt_Trace_fixture_id_xy";
            this.txt_Trace_fixture_id_xy.Size = new System.Drawing.Size(193, 25);
            this.txt_Trace_fixture_id_xy.TabIndex = 174;
            // 
            // txt_Trace_fixture_id_la
            // 
            this.txt_Trace_fixture_id_la.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_Trace_fixture_id_la.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.txt_Trace_fixture_id_la.Location = new System.Drawing.Point(307, 119);
            this.txt_Trace_fixture_id_la.Name = "txt_Trace_fixture_id_la";
            this.txt_Trace_fixture_id_la.Size = new System.Drawing.Size(182, 25);
            this.txt_Trace_fixture_id_la.TabIndex = 175;
            this.txt_Trace_fixture_id_la.Visible = false;
            // 
            // txt_Trace_uut_start_zy
            // 
            this.txt_Trace_uut_start_zy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Trace_uut_start_zy.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.txt_Trace_uut_start_zy.Location = new System.Drawing.Point(108, 148);
            this.txt_Trace_uut_start_zy.Name = "txt_Trace_uut_start_zy";
            this.txt_Trace_uut_start_zy.Size = new System.Drawing.Size(193, 25);
            this.txt_Trace_uut_start_zy.TabIndex = 176;
            // 
            // txt_Trace_uut_start_la
            // 
            this.txt_Trace_uut_start_la.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_Trace_uut_start_la.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.txt_Trace_uut_start_la.Location = new System.Drawing.Point(307, 148);
            this.txt_Trace_uut_start_la.Name = "txt_Trace_uut_start_la";
            this.txt_Trace_uut_start_la.Size = new System.Drawing.Size(182, 25);
            this.txt_Trace_uut_start_la.TabIndex = 177;
            this.txt_Trace_uut_start_la.Visible = false;
            // 
            // txt_Trace_assy_start_time_xy
            // 
            this.txt_Trace_assy_start_time_xy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Trace_assy_start_time_xy.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.txt_Trace_assy_start_time_xy.Location = new System.Drawing.Point(108, 177);
            this.txt_Trace_assy_start_time_xy.Name = "txt_Trace_assy_start_time_xy";
            this.txt_Trace_assy_start_time_xy.Size = new System.Drawing.Size(193, 25);
            this.txt_Trace_assy_start_time_xy.TabIndex = 178;
            this.txt_Trace_assy_start_time_xy.Text = "NA";
            // 
            // txt_Trace_weld_start_time_la
            // 
            this.txt_Trace_weld_start_time_la.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_Trace_weld_start_time_la.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.txt_Trace_weld_start_time_la.Location = new System.Drawing.Point(307, 177);
            this.txt_Trace_weld_start_time_la.Name = "txt_Trace_weld_start_time_la";
            this.txt_Trace_weld_start_time_la.Size = new System.Drawing.Size(182, 25);
            this.txt_Trace_weld_start_time_la.TabIndex = 179;
            this.txt_Trace_weld_start_time_la.Visible = false;
            // 
            // txt_Trace_assy_stop_time_xy
            // 
            this.txt_Trace_assy_stop_time_xy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Trace_assy_stop_time_xy.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.txt_Trace_assy_stop_time_xy.Location = new System.Drawing.Point(108, 206);
            this.txt_Trace_assy_stop_time_xy.Name = "txt_Trace_assy_stop_time_xy";
            this.txt_Trace_assy_stop_time_xy.Size = new System.Drawing.Size(193, 25);
            this.txt_Trace_assy_stop_time_xy.TabIndex = 180;
            this.txt_Trace_assy_stop_time_xy.Text = "NA";
            // 
            // txt_Trace_weld_stop_time_la
            // 
            this.txt_Trace_weld_stop_time_la.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_Trace_weld_stop_time_la.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.txt_Trace_weld_stop_time_la.Location = new System.Drawing.Point(307, 206);
            this.txt_Trace_weld_stop_time_la.Name = "txt_Trace_weld_stop_time_la";
            this.txt_Trace_weld_stop_time_la.Size = new System.Drawing.Size(182, 25);
            this.txt_Trace_weld_stop_time_la.TabIndex = 181;
            this.txt_Trace_weld_stop_time_la.Visible = false;
            // 
            // txt_Trace_uut_stop_xy
            // 
            this.txt_Trace_uut_stop_xy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Trace_uut_stop_xy.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.txt_Trace_uut_stop_xy.Location = new System.Drawing.Point(108, 235);
            this.txt_Trace_uut_stop_xy.Name = "txt_Trace_uut_stop_xy";
            this.txt_Trace_uut_stop_xy.Size = new System.Drawing.Size(193, 25);
            this.txt_Trace_uut_stop_xy.TabIndex = 182;
            // 
            // txt_Trace_uut_stop_la
            // 
            this.txt_Trace_uut_stop_la.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_Trace_uut_stop_la.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.txt_Trace_uut_stop_la.Location = new System.Drawing.Point(307, 235);
            this.txt_Trace_uut_stop_la.Name = "txt_Trace_uut_stop_la";
            this.txt_Trace_uut_stop_la.Size = new System.Drawing.Size(182, 25);
            this.txt_Trace_uut_stop_la.TabIndex = 183;
            this.txt_Trace_uut_stop_la.Visible = false;
            // 
            // txt_Trace_assy_ct_xy
            // 
            this.txt_Trace_assy_ct_xy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Trace_assy_ct_xy.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.txt_Trace_assy_ct_xy.Location = new System.Drawing.Point(108, 264);
            this.txt_Trace_assy_ct_xy.Name = "txt_Trace_assy_ct_xy";
            this.txt_Trace_assy_ct_xy.Size = new System.Drawing.Size(193, 25);
            this.txt_Trace_assy_ct_xy.TabIndex = 184;
            this.txt_Trace_assy_ct_xy.Text = "NA";
            // 
            // txt_Trace_weld_wait_ct_la
            // 
            this.txt_Trace_weld_wait_ct_la.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_Trace_weld_wait_ct_la.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.txt_Trace_weld_wait_ct_la.Location = new System.Drawing.Point(307, 264);
            this.txt_Trace_weld_wait_ct_la.Name = "txt_Trace_weld_wait_ct_la";
            this.txt_Trace_weld_wait_ct_la.Size = new System.Drawing.Size(182, 25);
            this.txt_Trace_weld_wait_ct_la.TabIndex = 185;
            this.txt_Trace_weld_wait_ct_la.Visible = false;
            // 
            // txt_Trace_actual_weld_ct_ua
            // 
            this.txt_Trace_actual_weld_ct_ua.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Trace_actual_weld_ct_ua.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.txt_Trace_actual_weld_ct_ua.Location = new System.Drawing.Point(108, 293);
            this.txt_Trace_actual_weld_ct_ua.Name = "txt_Trace_actual_weld_ct_ua";
            this.txt_Trace_actual_weld_ct_ua.Size = new System.Drawing.Size(193, 25);
            this.txt_Trace_actual_weld_ct_ua.TabIndex = 186;
            this.txt_Trace_actual_weld_ct_ua.Visible = false;
            // 
            // lb_Trace_XY_SendStatus
            // 
            this.lb_Trace_XY_SendStatus.AutoSize = true;
            this.lb_Trace_XY_SendStatus.BackColor = System.Drawing.Color.Transparent;
            this.lb_Trace_XY_SendStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Trace_XY_SendStatus.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.lb_Trace_XY_SendStatus.Location = new System.Drawing.Point(108, 319);
            this.lb_Trace_XY_SendStatus.Name = "lb_Trace_XY_SendStatus";
            this.lb_Trace_XY_SendStatus.Size = new System.Drawing.Size(193, 41);
            this.lb_Trace_XY_SendStatus.TabIndex = 187;
            this.lb_Trace_XY_SendStatus.Text = "等待中。。。";
            this.lb_Trace_XY_SendStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Trace_LA_SendStatus
            // 
            this.lb_Trace_LA_SendStatus.AutoSize = true;
            this.lb_Trace_LA_SendStatus.BackColor = System.Drawing.Color.Transparent;
            this.lb_Trace_LA_SendStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Trace_LA_SendStatus.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.lb_Trace_LA_SendStatus.Location = new System.Drawing.Point(307, 319);
            this.lb_Trace_LA_SendStatus.Name = "lb_Trace_LA_SendStatus";
            this.lb_Trace_LA_SendStatus.Size = new System.Drawing.Size(182, 41);
            this.lb_Trace_LA_SendStatus.TabIndex = 188;
            this.lb_Trace_LA_SendStatus.Text = "等待中。。。";
            this.lb_Trace_LA_SendStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lb_Trace_LA_SendStatus.Visible = false;
            // 
            // txt_Trace_band_xy
            // 
            this.txt_Trace_band_xy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Trace_band_xy.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.txt_Trace_band_xy.Location = new System.Drawing.Point(108, 32);
            this.txt_Trace_band_xy.Name = "txt_Trace_band_xy";
            this.txt_Trace_band_xy.Size = new System.Drawing.Size(193, 25);
            this.txt_Trace_band_xy.TabIndex = 168;
            // 
            // rtx_TraceMsg
            // 
            this.rtx_TraceMsg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtx_TraceMsg.Font = new System.Drawing.Font("Calibri", 10.5F);
            this.rtx_TraceMsg.Location = new System.Drawing.Point(0, 0);
            this.rtx_TraceMsg.Name = "rtx_TraceMsg";
            this.rtx_TraceMsg.Size = new System.Drawing.Size(325, 360);
            this.rtx_TraceMsg.TabIndex = 2;
            this.rtx_TraceMsg.Text = "";
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 10;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel8.Controls.Add(this.lb_TraceLANG, 7, 0);
            this.tableLayoutPanel8.Controls.Add(this.lb_TraceXYNG, 3, 0);
            this.tableLayoutPanel8.Controls.Add(this.label27, 2, 0);
            this.tableLayoutPanel8.Controls.Add(this.lb_TraceXYOK, 1, 0);
            this.tableLayoutPanel8.Controls.Add(this.lb_TraceSendNG, 9, 0);
            this.tableLayoutPanel8.Controls.Add(this.label42, 8, 0);
            this.tableLayoutPanel8.Controls.Add(this.label13, 4, 0);
            this.tableLayoutPanel8.Controls.Add(this.label14, 6, 0);
            this.tableLayoutPanel8.Controls.Add(this.lb_TraceLAOK, 5, 0);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(3, 51);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 1;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(827, 42);
            this.tableLayoutPanel8.TabIndex = 2;
            // 
            // lb_TraceLANG
            // 
            this.lb_TraceLANG.AutoSize = true;
            this.lb_TraceLANG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_TraceLANG.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lb_TraceLANG.ForeColor = System.Drawing.Color.Red;
            this.lb_TraceLANG.Location = new System.Drawing.Point(602, 0);
            this.lb_TraceLANG.Name = "lb_TraceLANG";
            this.lb_TraceLANG.Size = new System.Drawing.Size(51, 42);
            this.lb_TraceLANG.TabIndex = 23;
            this.lb_TraceLANG.Text = "0";
            this.lb_TraceLANG.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb_TraceLANG.Visible = false;
            // 
            // lb_TraceXYNG
            // 
            this.lb_TraceXYNG.AutoSize = true;
            this.lb_TraceXYNG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_TraceXYNG.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lb_TraceXYNG.ForeColor = System.Drawing.Color.Red;
            this.lb_TraceXYNG.Location = new System.Drawing.Point(274, 0);
            this.lb_TraceXYNG.Name = "lb_TraceXYNG";
            this.lb_TraceXYNG.Size = new System.Drawing.Size(51, 42);
            this.lb_TraceXYNG.TabIndex = 3;
            this.lb_TraceXYNG.Text = "0";
            this.lb_TraceXYNG.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb_TraceXYNG.Visible = false;
            this.lb_TraceXYNG.TextChanged += new System.EventHandler(this.lb_TraceUANG_TextChanged);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label27.Location = new System.Drawing.Point(167, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(101, 42);
            this.label27.TabIndex = 2;
            this.label27.Text = "Bracket组装NG:";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label27.Visible = false;
            // 
            // lb_TraceXYOK
            // 
            this.lb_TraceXYOK.AutoSize = true;
            this.lb_TraceXYOK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_TraceXYOK.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lb_TraceXYOK.ForeColor = System.Drawing.Color.Red;
            this.lb_TraceXYOK.Location = new System.Drawing.Point(110, 0);
            this.lb_TraceXYOK.Name = "lb_TraceXYOK";
            this.lb_TraceXYOK.Size = new System.Drawing.Size(51, 42);
            this.lb_TraceXYOK.TabIndex = 1;
            this.lb_TraceXYOK.Text = "0";
            this.lb_TraceXYOK.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb_TraceXYOK.Visible = false;
            this.lb_TraceXYOK.TextChanged += new System.EventHandler(this.lb_TraceUAOK_TextChanged);
            // 
            // lb_TraceSendNG
            // 
            this.lb_TraceSendNG.AutoSize = true;
            this.lb_TraceSendNG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_TraceSendNG.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lb_TraceSendNG.ForeColor = System.Drawing.Color.Red;
            this.lb_TraceSendNG.Location = new System.Drawing.Point(766, 0);
            this.lb_TraceSendNG.Name = "lb_TraceSendNG";
            this.lb_TraceSendNG.Size = new System.Drawing.Size(58, 42);
            this.lb_TraceSendNG.TabIndex = 19;
            this.lb_TraceSendNG.Text = "0";
            this.lb_TraceSendNG.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label42.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label42.Location = new System.Drawing.Point(659, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(101, 42);
            this.label42.TabIndex = 17;
            this.label42.Text = "缓存数:";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label13.Location = new System.Drawing.Point(331, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(101, 42);
            this.label13.TabIndex = 20;
            this.label13.Text = "LA焊接OK:";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label13.Visible = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label14.Location = new System.Drawing.Point(495, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(101, 42);
            this.label14.TabIndex = 21;
            this.label14.Text = "LA焊接NG:";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label14.Visible = false;
            // 
            // lb_TraceLAOK
            // 
            this.lb_TraceLAOK.AutoSize = true;
            this.lb_TraceLAOK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_TraceLAOK.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lb_TraceLAOK.ForeColor = System.Drawing.Color.Red;
            this.lb_TraceLAOK.Location = new System.Drawing.Point(438, 0);
            this.lb_TraceLAOK.Name = "lb_TraceLAOK";
            this.lb_TraceLAOK.Size = new System.Drawing.Size(51, 42);
            this.lb_TraceLAOK.TabIndex = 22;
            this.lb_TraceLAOK.Text = "0";
            this.lb_TraceLAOK.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb_TraceLAOK.Visible = false;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 12;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.Controls.Add(this.Paoliaolv, 11, 0);
            this.tableLayoutPanel2.Controls.Add(this.label26, 10, 0);
            this.tableLayoutPanel2.Controls.Add(this.Paoliaoshu, 9, 0);
            this.tableLayoutPanel2.Controls.Add(this.label23, 8, 0);
            this.tableLayoutPanel2.Controls.Add(this.Lianglv, 7, 0);
            this.tableLayoutPanel2.Controls.Add(this.label21, 6, 0);
            this.tableLayoutPanel2.Controls.Add(this.NGCount, 5, 0);
            this.tableLayoutPanel2.Controls.Add(this.label19, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.TotalCount, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.label17, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.CT, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label15, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(827, 42);
            this.tableLayoutPanel2.TabIndex = 6;
            // 
            // Paoliaolv
            // 
            this.Paoliaolv.AutoSize = true;
            this.Paoliaolv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Paoliaolv.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Paoliaolv.ForeColor = System.Drawing.Color.Red;
            this.Paoliaolv.Location = new System.Drawing.Point(751, 0);
            this.Paoliaolv.Name = "Paoliaolv";
            this.Paoliaolv.Size = new System.Drawing.Size(73, 42);
            this.Paoliaolv.TabIndex = 11;
            this.Paoliaolv.Text = "0";
            this.Paoliaolv.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label26.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label26.Location = new System.Drawing.Point(683, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(62, 42);
            this.label26.TabIndex = 10;
            this.label26.Text = "抛料率:";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Paoliaoshu
            // 
            this.Paoliaoshu.AutoSize = true;
            this.Paoliaoshu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Paoliaoshu.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Paoliaoshu.ForeColor = System.Drawing.Color.Red;
            this.Paoliaoshu.Location = new System.Drawing.Point(615, 0);
            this.Paoliaoshu.Name = "Paoliaoshu";
            this.Paoliaoshu.Size = new System.Drawing.Size(62, 42);
            this.Paoliaoshu.TabIndex = 9;
            this.Paoliaoshu.Text = "0";
            this.Paoliaoshu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label23.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label23.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label23.Location = new System.Drawing.Point(547, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(62, 42);
            this.label23.TabIndex = 8;
            this.label23.Text = "抛料数:";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Lianglv
            // 
            this.Lianglv.AutoSize = true;
            this.Lianglv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Lianglv.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Lianglv.ForeColor = System.Drawing.Color.Red;
            this.Lianglv.Location = new System.Drawing.Point(479, 0);
            this.Lianglv.Name = "Lianglv";
            this.Lianglv.Size = new System.Drawing.Size(62, 42);
            this.Lianglv.TabIndex = 7;
            this.Lianglv.Text = "0";
            this.Lianglv.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label21.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label21.Location = new System.Drawing.Point(411, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(62, 42);
            this.label21.TabIndex = 6;
            this.label21.Text = "良率:";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // NGCount
            // 
            this.NGCount.AutoSize = true;
            this.NGCount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NGCount.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.NGCount.ForeColor = System.Drawing.Color.Red;
            this.NGCount.Location = new System.Drawing.Point(343, 0);
            this.NGCount.Name = "NGCount";
            this.NGCount.Size = new System.Drawing.Size(62, 42);
            this.NGCount.TabIndex = 5;
            this.NGCount.Text = "0";
            this.NGCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label19.Location = new System.Drawing.Point(275, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(62, 42);
            this.label19.TabIndex = 4;
            this.label19.Text = "OK产量:";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TotalCount
            // 
            this.TotalCount.AutoSize = true;
            this.TotalCount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TotalCount.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TotalCount.ForeColor = System.Drawing.Color.Red;
            this.TotalCount.Location = new System.Drawing.Point(207, 0);
            this.TotalCount.Name = "TotalCount";
            this.TotalCount.Size = new System.Drawing.Size(62, 42);
            this.TotalCount.TabIndex = 3;
            this.TotalCount.Text = "0";
            this.TotalCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label17.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label17.Location = new System.Drawing.Point(139, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(62, 42);
            this.label17.TabIndex = 2;
            this.label17.Text = "总产量:";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CT
            // 
            this.CT.AutoSize = true;
            this.CT.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CT.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CT.ForeColor = System.Drawing.Color.Red;
            this.CT.Location = new System.Drawing.Point(71, 0);
            this.CT.Name = "CT";
            this.CT.Size = new System.Drawing.Size(62, 42);
            this.CT.TabIndex = 1;
            this.CT.Text = "0.0";
            this.CT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label15.Location = new System.Drawing.Point(3, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(62, 42);
            this.label15.TabIndex = 0;
            this.label15.Text = "CT(S):";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel1);
            this.tabPage2.Location = new System.Drawing.Point(124, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(841, 492);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "视觉";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(835, 486);
            this.panel1.TabIndex = 0;
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.tableLayoutPanel13);
            this.tabPage10.Location = new System.Drawing.Point(124, 4);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Size = new System.Drawing.Size(841, 492);
            this.tabPage10.TabIndex = 4;
            this.tabPage10.Text = "PDCA";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 1;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Controls.Add(this.groupBox7, 0, 1);
            this.tableLayoutPanel13.Controls.Add(this.tableLayoutPanel24, 0, 0);
            this.tableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 2;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 87F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(841, 492);
            this.tableLayoutPanel13.TabIndex = 7;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.splitContainer7);
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox7.Location = new System.Drawing.Point(3, 66);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(835, 423);
            this.groupBox7.TabIndex = 5;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "数据区";
            // 
            // splitContainer7
            // 
            this.splitContainer7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer7.IsSplitterFixed = true;
            this.splitContainer7.Location = new System.Drawing.Point(3, 19);
            this.splitContainer7.Name = "splitContainer7";
            // 
            // splitContainer7.Panel1
            // 
            this.splitContainer7.Panel1.Controls.Add(this.tableLayoutPanel23);
            // 
            // splitContainer7.Panel2
            // 
            this.splitContainer7.Panel2.Controls.Add(this.rtx_PDCAMsg);
            this.splitContainer7.Size = new System.Drawing.Size(829, 401);
            this.splitContainer7.SplitterDistance = 497;
            this.splitContainer7.TabIndex = 1;
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.ColumnCount = 3;
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.30282F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.49296F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38F));
            this.tableLayoutPanel23.Controls.Add(this.label97, 2, 0);
            this.tableLayoutPanel23.Controls.Add(this.label98, 1, 0);
            this.tableLayoutPanel23.Controls.Add(this.label99, 0, 1);
            this.tableLayoutPanel23.Controls.Add(this.label100, 0, 2);
            this.tableLayoutPanel23.Controls.Add(this.label101, 0, 3);
            this.tableLayoutPanel23.Controls.Add(this.label102, 0, 4);
            this.tableLayoutPanel23.Controls.Add(this.label103, 0, 5);
            this.tableLayoutPanel23.Controls.Add(this.label104, 0, 6);
            this.tableLayoutPanel23.Controls.Add(this.label105, 0, 7);
            this.tableLayoutPanel23.Controls.Add(this.label106, 0, 8);
            this.tableLayoutPanel23.Controls.Add(this.label107, 0, 9);
            this.tableLayoutPanel23.Controls.Add(this.label108, 0, 10);
            this.tableLayoutPanel23.Controls.Add(this.txt_PDCA_actual_weld_ct_la, 2, 10);
            this.tableLayoutPanel23.Controls.Add(this.txt_PDCA_sp_la, 2, 1);
            this.tableLayoutPanel23.Controls.Add(this.txt_PDCA_test_result_ua, 1, 2);
            this.tableLayoutPanel23.Controls.Add(this.txt_PDCA_test_result_la, 2, 2);
            this.tableLayoutPanel23.Controls.Add(this.txt_PDCA_unit_serial_number_ua, 1, 3);
            this.tableLayoutPanel23.Controls.Add(this.txt_PDCA_unit_serial_number_la, 2, 3);
            this.tableLayoutPanel23.Controls.Add(this.txt_PDCA_fixture_id_ua, 1, 4);
            this.tableLayoutPanel23.Controls.Add(this.txt_PDCA_fixture_id_la, 2, 4);
            this.tableLayoutPanel23.Controls.Add(this.txt_PDCA_uut_start_ua, 1, 5);
            this.tableLayoutPanel23.Controls.Add(this.txt_PDCA_uut_start_la, 2, 5);
            this.tableLayoutPanel23.Controls.Add(this.txt_PDCA_weld_start_time_ua, 1, 6);
            this.tableLayoutPanel23.Controls.Add(this.txt_PDCA_weld_start_time_la, 2, 6);
            this.tableLayoutPanel23.Controls.Add(this.txt_PDCA_weld_stop_time_ua, 1, 7);
            this.tableLayoutPanel23.Controls.Add(this.txt_PDCA_weld_stop_time_la, 2, 7);
            this.tableLayoutPanel23.Controls.Add(this.txt_PDCA_uut_stop_ua, 1, 8);
            this.tableLayoutPanel23.Controls.Add(this.txt_PDCA_uut_stop_la, 2, 8);
            this.tableLayoutPanel23.Controls.Add(this.txt_PDCA_weld_wait_ct_ua, 1, 9);
            this.tableLayoutPanel23.Controls.Add(this.txt_PDCA_weld_wait_ct_la, 2, 9);
            this.tableLayoutPanel23.Controls.Add(this.txt_PDCA_actual_weld_ct_ua, 1, 10);
            this.tableLayoutPanel23.Controls.Add(this.lb_PDCA_UA_SendStatus, 1, 11);
            this.tableLayoutPanel23.Controls.Add(this.lb_PDCA_LA_SendStatus, 2, 11);
            this.tableLayoutPanel23.Controls.Add(this.txt_PDCA_sp_ua, 1, 1);
            this.tableLayoutPanel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel23.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel23.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 12;
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(497, 401);
            this.tableLayoutPanel23.TabIndex = 1;
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label97.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label97.Location = new System.Drawing.Point(310, 0);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(184, 33);
            this.label97.TabIndex = 156;
            this.label97.Text = "LA";
            this.label97.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label97.Visible = false;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label98.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label98.Location = new System.Drawing.Point(109, 0);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(195, 33);
            this.label98.TabIndex = 155;
            this.label98.Text = "Bracket";
            this.label98.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label99.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label99.Location = new System.Drawing.Point(3, 33);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(100, 33);
            this.label99.TabIndex = 157;
            this.label99.Text = "band:";
            this.label99.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label100.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label100.Location = new System.Drawing.Point(3, 66);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(100, 33);
            this.label100.TabIndex = 158;
            this.label100.Text = "test_result:";
            this.label100.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label101.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label101.Location = new System.Drawing.Point(3, 99);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(100, 33);
            this.label101.TabIndex = 159;
            this.label101.Text = "unit_serial_number:";
            this.label101.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label102.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label102.Location = new System.Drawing.Point(3, 132);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(100, 33);
            this.label102.TabIndex = 160;
            this.label102.Text = "fixture_id:";
            this.label102.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label103.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label103.Location = new System.Drawing.Point(3, 165);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(100, 33);
            this.label103.TabIndex = 161;
            this.label103.Text = "uut_start:";
            this.label103.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label104.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label104.Location = new System.Drawing.Point(3, 198);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(100, 33);
            this.label104.TabIndex = 162;
            this.label104.Text = "weld_start_time:";
            this.label104.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label105.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label105.Location = new System.Drawing.Point(3, 231);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(100, 33);
            this.label105.TabIndex = 163;
            this.label105.Text = "weld_stop_time:";
            this.label105.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label106.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label106.Location = new System.Drawing.Point(3, 264);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(100, 33);
            this.label106.TabIndex = 164;
            this.label106.Text = "uut_stop:";
            this.label106.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label107.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label107.Location = new System.Drawing.Point(3, 297);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(100, 33);
            this.label107.TabIndex = 165;
            this.label107.Text = "weld_wait_ct:";
            this.label107.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label108.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label108.Location = new System.Drawing.Point(3, 330);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(100, 33);
            this.label108.TabIndex = 166;
            this.label108.Text = "actual_weld_ct:";
            this.label108.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_PDCA_actual_weld_ct_la
            // 
            this.txt_PDCA_actual_weld_ct_la.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_PDCA_actual_weld_ct_la.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDCA_actual_weld_ct_la.Location = new System.Drawing.Point(310, 333);
            this.txt_PDCA_actual_weld_ct_la.Name = "txt_PDCA_actual_weld_ct_la";
            this.txt_PDCA_actual_weld_ct_la.Size = new System.Drawing.Size(184, 25);
            this.txt_PDCA_actual_weld_ct_la.TabIndex = 167;
            this.txt_PDCA_actual_weld_ct_la.Visible = false;
            // 
            // txt_PDCA_sp_la
            // 
            this.txt_PDCA_sp_la.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_PDCA_sp_la.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDCA_sp_la.Location = new System.Drawing.Point(310, 36);
            this.txt_PDCA_sp_la.Name = "txt_PDCA_sp_la";
            this.txt_PDCA_sp_la.Size = new System.Drawing.Size(184, 25);
            this.txt_PDCA_sp_la.TabIndex = 169;
            this.txt_PDCA_sp_la.Visible = false;
            // 
            // txt_PDCA_test_result_ua
            // 
            this.txt_PDCA_test_result_ua.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_PDCA_test_result_ua.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDCA_test_result_ua.Location = new System.Drawing.Point(109, 70);
            this.txt_PDCA_test_result_ua.Name = "txt_PDCA_test_result_ua";
            this.txt_PDCA_test_result_ua.Size = new System.Drawing.Size(195, 25);
            this.txt_PDCA_test_result_ua.TabIndex = 170;
            // 
            // txt_PDCA_test_result_la
            // 
            this.txt_PDCA_test_result_la.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_PDCA_test_result_la.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDCA_test_result_la.Location = new System.Drawing.Point(310, 69);
            this.txt_PDCA_test_result_la.Name = "txt_PDCA_test_result_la";
            this.txt_PDCA_test_result_la.Size = new System.Drawing.Size(184, 25);
            this.txt_PDCA_test_result_la.TabIndex = 171;
            this.txt_PDCA_test_result_la.Visible = false;
            // 
            // txt_PDCA_unit_serial_number_ua
            // 
            this.txt_PDCA_unit_serial_number_ua.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_PDCA_unit_serial_number_ua.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDCA_unit_serial_number_ua.Location = new System.Drawing.Point(109, 103);
            this.txt_PDCA_unit_serial_number_ua.Name = "txt_PDCA_unit_serial_number_ua";
            this.txt_PDCA_unit_serial_number_ua.Size = new System.Drawing.Size(195, 25);
            this.txt_PDCA_unit_serial_number_ua.TabIndex = 172;
            // 
            // txt_PDCA_unit_serial_number_la
            // 
            this.txt_PDCA_unit_serial_number_la.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_PDCA_unit_serial_number_la.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDCA_unit_serial_number_la.Location = new System.Drawing.Point(310, 102);
            this.txt_PDCA_unit_serial_number_la.Name = "txt_PDCA_unit_serial_number_la";
            this.txt_PDCA_unit_serial_number_la.Size = new System.Drawing.Size(184, 25);
            this.txt_PDCA_unit_serial_number_la.TabIndex = 173;
            this.txt_PDCA_unit_serial_number_la.Visible = false;
            // 
            // txt_PDCA_fixture_id_ua
            // 
            this.txt_PDCA_fixture_id_ua.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_PDCA_fixture_id_ua.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDCA_fixture_id_ua.Location = new System.Drawing.Point(109, 136);
            this.txt_PDCA_fixture_id_ua.Name = "txt_PDCA_fixture_id_ua";
            this.txt_PDCA_fixture_id_ua.Size = new System.Drawing.Size(195, 25);
            this.txt_PDCA_fixture_id_ua.TabIndex = 174;
            // 
            // txt_PDCA_fixture_id_la
            // 
            this.txt_PDCA_fixture_id_la.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_PDCA_fixture_id_la.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDCA_fixture_id_la.Location = new System.Drawing.Point(310, 135);
            this.txt_PDCA_fixture_id_la.Name = "txt_PDCA_fixture_id_la";
            this.txt_PDCA_fixture_id_la.Size = new System.Drawing.Size(184, 25);
            this.txt_PDCA_fixture_id_la.TabIndex = 175;
            this.txt_PDCA_fixture_id_la.Visible = false;
            // 
            // txt_PDCA_uut_start_ua
            // 
            this.txt_PDCA_uut_start_ua.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_PDCA_uut_start_ua.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDCA_uut_start_ua.Location = new System.Drawing.Point(109, 169);
            this.txt_PDCA_uut_start_ua.Name = "txt_PDCA_uut_start_ua";
            this.txt_PDCA_uut_start_ua.Size = new System.Drawing.Size(195, 25);
            this.txt_PDCA_uut_start_ua.TabIndex = 176;
            // 
            // txt_PDCA_uut_start_la
            // 
            this.txt_PDCA_uut_start_la.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_PDCA_uut_start_la.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDCA_uut_start_la.Location = new System.Drawing.Point(310, 168);
            this.txt_PDCA_uut_start_la.Name = "txt_PDCA_uut_start_la";
            this.txt_PDCA_uut_start_la.Size = new System.Drawing.Size(184, 25);
            this.txt_PDCA_uut_start_la.TabIndex = 177;
            this.txt_PDCA_uut_start_la.Visible = false;
            // 
            // txt_PDCA_weld_start_time_ua
            // 
            this.txt_PDCA_weld_start_time_ua.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_PDCA_weld_start_time_ua.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDCA_weld_start_time_ua.Location = new System.Drawing.Point(109, 202);
            this.txt_PDCA_weld_start_time_ua.Name = "txt_PDCA_weld_start_time_ua";
            this.txt_PDCA_weld_start_time_ua.Size = new System.Drawing.Size(195, 25);
            this.txt_PDCA_weld_start_time_ua.TabIndex = 178;
            // 
            // txt_PDCA_weld_start_time_la
            // 
            this.txt_PDCA_weld_start_time_la.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_PDCA_weld_start_time_la.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDCA_weld_start_time_la.Location = new System.Drawing.Point(310, 201);
            this.txt_PDCA_weld_start_time_la.Name = "txt_PDCA_weld_start_time_la";
            this.txt_PDCA_weld_start_time_la.Size = new System.Drawing.Size(184, 25);
            this.txt_PDCA_weld_start_time_la.TabIndex = 179;
            this.txt_PDCA_weld_start_time_la.Visible = false;
            // 
            // txt_PDCA_weld_stop_time_ua
            // 
            this.txt_PDCA_weld_stop_time_ua.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_PDCA_weld_stop_time_ua.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDCA_weld_stop_time_ua.Location = new System.Drawing.Point(109, 235);
            this.txt_PDCA_weld_stop_time_ua.Name = "txt_PDCA_weld_stop_time_ua";
            this.txt_PDCA_weld_stop_time_ua.Size = new System.Drawing.Size(195, 25);
            this.txt_PDCA_weld_stop_time_ua.TabIndex = 180;
            // 
            // txt_PDCA_weld_stop_time_la
            // 
            this.txt_PDCA_weld_stop_time_la.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_PDCA_weld_stop_time_la.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDCA_weld_stop_time_la.Location = new System.Drawing.Point(310, 234);
            this.txt_PDCA_weld_stop_time_la.Name = "txt_PDCA_weld_stop_time_la";
            this.txt_PDCA_weld_stop_time_la.Size = new System.Drawing.Size(184, 25);
            this.txt_PDCA_weld_stop_time_la.TabIndex = 181;
            this.txt_PDCA_weld_stop_time_la.Visible = false;
            // 
            // txt_PDCA_uut_stop_ua
            // 
            this.txt_PDCA_uut_stop_ua.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_PDCA_uut_stop_ua.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDCA_uut_stop_ua.Location = new System.Drawing.Point(109, 268);
            this.txt_PDCA_uut_stop_ua.Name = "txt_PDCA_uut_stop_ua";
            this.txt_PDCA_uut_stop_ua.Size = new System.Drawing.Size(195, 25);
            this.txt_PDCA_uut_stop_ua.TabIndex = 182;
            // 
            // txt_PDCA_uut_stop_la
            // 
            this.txt_PDCA_uut_stop_la.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_PDCA_uut_stop_la.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDCA_uut_stop_la.Location = new System.Drawing.Point(310, 267);
            this.txt_PDCA_uut_stop_la.Name = "txt_PDCA_uut_stop_la";
            this.txt_PDCA_uut_stop_la.Size = new System.Drawing.Size(184, 25);
            this.txt_PDCA_uut_stop_la.TabIndex = 183;
            this.txt_PDCA_uut_stop_la.Visible = false;
            // 
            // txt_PDCA_weld_wait_ct_ua
            // 
            this.txt_PDCA_weld_wait_ct_ua.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_PDCA_weld_wait_ct_ua.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDCA_weld_wait_ct_ua.Location = new System.Drawing.Point(109, 301);
            this.txt_PDCA_weld_wait_ct_ua.Name = "txt_PDCA_weld_wait_ct_ua";
            this.txt_PDCA_weld_wait_ct_ua.Size = new System.Drawing.Size(195, 25);
            this.txt_PDCA_weld_wait_ct_ua.TabIndex = 184;
            // 
            // txt_PDCA_weld_wait_ct_la
            // 
            this.txt_PDCA_weld_wait_ct_la.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_PDCA_weld_wait_ct_la.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDCA_weld_wait_ct_la.Location = new System.Drawing.Point(310, 300);
            this.txt_PDCA_weld_wait_ct_la.Name = "txt_PDCA_weld_wait_ct_la";
            this.txt_PDCA_weld_wait_ct_la.Size = new System.Drawing.Size(184, 25);
            this.txt_PDCA_weld_wait_ct_la.TabIndex = 185;
            this.txt_PDCA_weld_wait_ct_la.Visible = false;
            // 
            // txt_PDCA_actual_weld_ct_ua
            // 
            this.txt_PDCA_actual_weld_ct_ua.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_PDCA_actual_weld_ct_ua.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDCA_actual_weld_ct_ua.Location = new System.Drawing.Point(109, 334);
            this.txt_PDCA_actual_weld_ct_ua.Name = "txt_PDCA_actual_weld_ct_ua";
            this.txt_PDCA_actual_weld_ct_ua.Size = new System.Drawing.Size(195, 25);
            this.txt_PDCA_actual_weld_ct_ua.TabIndex = 186;
            // 
            // lb_PDCA_UA_SendStatus
            // 
            this.lb_PDCA_UA_SendStatus.AutoSize = true;
            this.lb_PDCA_UA_SendStatus.BackColor = System.Drawing.Color.Transparent;
            this.lb_PDCA_UA_SendStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PDCA_UA_SendStatus.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_PDCA_UA_SendStatus.Location = new System.Drawing.Point(109, 363);
            this.lb_PDCA_UA_SendStatus.Name = "lb_PDCA_UA_SendStatus";
            this.lb_PDCA_UA_SendStatus.Size = new System.Drawing.Size(195, 38);
            this.lb_PDCA_UA_SendStatus.TabIndex = 187;
            this.lb_PDCA_UA_SendStatus.Text = "等待中。。。";
            this.lb_PDCA_UA_SendStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PDCA_LA_SendStatus
            // 
            this.lb_PDCA_LA_SendStatus.AutoSize = true;
            this.lb_PDCA_LA_SendStatus.BackColor = System.Drawing.Color.Transparent;
            this.lb_PDCA_LA_SendStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PDCA_LA_SendStatus.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_PDCA_LA_SendStatus.Location = new System.Drawing.Point(310, 363);
            this.lb_PDCA_LA_SendStatus.Name = "lb_PDCA_LA_SendStatus";
            this.lb_PDCA_LA_SendStatus.Size = new System.Drawing.Size(184, 38);
            this.lb_PDCA_LA_SendStatus.TabIndex = 188;
            this.lb_PDCA_LA_SendStatus.Text = "等待中。。。";
            this.lb_PDCA_LA_SendStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lb_PDCA_LA_SendStatus.Visible = false;
            // 
            // txt_PDCA_sp_ua
            // 
            this.txt_PDCA_sp_ua.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_PDCA_sp_ua.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDCA_sp_ua.Location = new System.Drawing.Point(109, 37);
            this.txt_PDCA_sp_ua.Name = "txt_PDCA_sp_ua";
            this.txt_PDCA_sp_ua.Size = new System.Drawing.Size(195, 25);
            this.txt_PDCA_sp_ua.TabIndex = 168;
            // 
            // rtx_PDCAMsg
            // 
            this.rtx_PDCAMsg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtx_PDCAMsg.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtx_PDCAMsg.Location = new System.Drawing.Point(0, 0);
            this.rtx_PDCAMsg.Name = "rtx_PDCAMsg";
            this.rtx_PDCAMsg.Size = new System.Drawing.Size(328, 401);
            this.rtx_PDCAMsg.TabIndex = 2;
            this.rtx_PDCAMsg.Text = "";
            // 
            // tableLayoutPanel24
            // 
            this.tableLayoutPanel24.ColumnCount = 10;
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel24.Controls.Add(this.lb_PDCALANG, 7, 0);
            this.tableLayoutPanel24.Controls.Add(this.lb_PDCALAOK, 5, 0);
            this.tableLayoutPanel24.Controls.Add(this.label57, 6, 0);
            this.tableLayoutPanel24.Controls.Add(this.lb_PDCAUANG, 3, 0);
            this.tableLayoutPanel24.Controls.Add(this.label28, 4, 0);
            this.tableLayoutPanel24.Controls.Add(this.label112, 2, 0);
            this.tableLayoutPanel24.Controls.Add(this.lb_PDCAUAOK, 1, 0);
            this.tableLayoutPanel24.Controls.Add(this.label114, 0, 0);
            this.tableLayoutPanel24.Controls.Add(this.lb_PDCASendNG, 9, 0);
            this.tableLayoutPanel24.Controls.Add(this.label115, 8, 0);
            this.tableLayoutPanel24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel24.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel24.Name = "tableLayoutPanel24";
            this.tableLayoutPanel24.RowCount = 1;
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel24.Size = new System.Drawing.Size(835, 57);
            this.tableLayoutPanel24.TabIndex = 2;
            // 
            // lb_PDCALANG
            // 
            this.lb_PDCALANG.AutoSize = true;
            this.lb_PDCALANG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PDCALANG.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lb_PDCALANG.ForeColor = System.Drawing.Color.Red;
            this.lb_PDCALANG.Location = new System.Drawing.Point(609, 0);
            this.lb_PDCALANG.Name = "lb_PDCALANG";
            this.lb_PDCALANG.Size = new System.Drawing.Size(52, 57);
            this.lb_PDCALANG.TabIndex = 5;
            this.lb_PDCALANG.Text = "0";
            this.lb_PDCALANG.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb_PDCALANG.Visible = false;
            // 
            // lb_PDCALAOK
            // 
            this.lb_PDCALAOK.AutoSize = true;
            this.lb_PDCALAOK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PDCALAOK.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lb_PDCALAOK.ForeColor = System.Drawing.Color.Red;
            this.lb_PDCALAOK.Location = new System.Drawing.Point(443, 0);
            this.lb_PDCALAOK.Name = "lb_PDCALAOK";
            this.lb_PDCALAOK.Size = new System.Drawing.Size(52, 57);
            this.lb_PDCALAOK.TabIndex = 5;
            this.lb_PDCALAOK.Text = "0";
            this.lb_PDCALAOK.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb_PDCALAOK.Visible = false;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label57.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label57.Location = new System.Drawing.Point(501, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(102, 57);
            this.label57.TabIndex = 4;
            this.label57.Text = "LA焊接NG:";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label57.Visible = false;
            // 
            // lb_PDCAUANG
            // 
            this.lb_PDCAUANG.AutoSize = true;
            this.lb_PDCAUANG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PDCAUANG.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lb_PDCAUANG.ForeColor = System.Drawing.Color.Red;
            this.lb_PDCAUANG.Location = new System.Drawing.Point(277, 0);
            this.lb_PDCAUANG.Name = "lb_PDCAUANG";
            this.lb_PDCAUANG.Size = new System.Drawing.Size(52, 57);
            this.lb_PDCAUANG.TabIndex = 3;
            this.lb_PDCAUANG.Text = "0";
            this.lb_PDCAUANG.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb_PDCAUANG.TextChanged += new System.EventHandler(this.lb_PDCAUANG_TextChanged);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label28.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label28.Location = new System.Drawing.Point(335, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(102, 57);
            this.label28.TabIndex = 4;
            this.label28.Text = "LA焊接OK:";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label28.Visible = false;
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label112.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label112.Location = new System.Drawing.Point(169, 0);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(102, 57);
            this.label112.TabIndex = 2;
            this.label112.Text = "Bracket焊接NG:";
            this.label112.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lb_PDCAUAOK
            // 
            this.lb_PDCAUAOK.AutoSize = true;
            this.lb_PDCAUAOK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PDCAUAOK.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lb_PDCAUAOK.ForeColor = System.Drawing.Color.Red;
            this.lb_PDCAUAOK.Location = new System.Drawing.Point(111, 0);
            this.lb_PDCAUAOK.Name = "lb_PDCAUAOK";
            this.lb_PDCAUAOK.Size = new System.Drawing.Size(52, 57);
            this.lb_PDCAUAOK.TabIndex = 1;
            this.lb_PDCAUAOK.Text = "0";
            this.lb_PDCAUAOK.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb_PDCAUAOK.TextChanged += new System.EventHandler(this.lb_PDCAUAOK_TextChanged);
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label114.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label114.Location = new System.Drawing.Point(3, 0);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(102, 57);
            this.label114.TabIndex = 0;
            this.label114.Text = "Bracket焊接OK:";
            this.label114.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lb_PDCASendNG
            // 
            this.lb_PDCASendNG.AutoSize = true;
            this.lb_PDCASendNG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_PDCASendNG.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lb_PDCASendNG.ForeColor = System.Drawing.Color.Red;
            this.lb_PDCASendNG.Location = new System.Drawing.Point(775, 0);
            this.lb_PDCASendNG.Name = "lb_PDCASendNG";
            this.lb_PDCASendNG.Size = new System.Drawing.Size(57, 57);
            this.lb_PDCASendNG.TabIndex = 19;
            this.lb_PDCASendNG.Text = "0";
            this.lb_PDCASendNG.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label115.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label115.Location = new System.Drawing.Point(667, 0);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(102, 57);
            this.label115.TabIndex = 17;
            this.label115.Text = "缓存数:";
            this.label115.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.tabControl3);
            this.tabPage7.Location = new System.Drawing.Point(124, 4);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(841, 492);
            this.tabPage7.TabIndex = 3;
            this.tabPage7.Text = "OEE";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage8);
            this.tabControl3.Controls.Add(this.tabPage9);
            this.tabControl3.Controls.Add(this.tabPage3);
            this.tabControl3.Controls.Add(this.tabPage4);
            this.tabControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl3.Location = new System.Drawing.Point(0, 0);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(841, 492);
            this.tabControl3.TabIndex = 1;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.tableLayoutPanel7);
            this.tabPage8.Font = new System.Drawing.Font("Calibri", 9F);
            this.tabPage8.Location = new System.Drawing.Point(4, 32);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(833, 456);
            this.tabPage8.TabIndex = 2;
            this.tabPage8.Text = "过站数据";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 1;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Controls.Add(this.groupBox1, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.tableLayoutPanel12, 0, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 2;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 87F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(833, 456);
            this.tableLayoutPanel7.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.splitContainer3);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.Location = new System.Drawing.Point(3, 62);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(827, 391);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "数据区";
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.IsSplitterFixed = true;
            this.splitContainer3.Location = new System.Drawing.Point(3, 19);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.tableLayoutPanel11);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.rtx_OEEDefaultMsg);
            this.splitContainer3.Size = new System.Drawing.Size(821, 369);
            this.splitContainer3.SplitterDistance = 492;
            this.splitContainer3.TabIndex = 1;
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 3;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.30282F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.49296F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38F));
            this.tableLayoutPanel11.Controls.Add(this.label45, 2, 0);
            this.tableLayoutPanel11.Controls.Add(this.label46, 1, 0);
            this.tableLayoutPanel11.Controls.Add(this.label47, 0, 1);
            this.tableLayoutPanel11.Controls.Add(this.label48, 0, 2);
            this.tableLayoutPanel11.Controls.Add(this.label49, 0, 3);
            this.tableLayoutPanel11.Controls.Add(this.label50, 0, 4);
            this.tableLayoutPanel11.Controls.Add(this.label51, 0, 5);
            this.tableLayoutPanel11.Controls.Add(this.label52, 0, 6);
            this.tableLayoutPanel11.Controls.Add(this.label53, 0, 7);
            this.tableLayoutPanel11.Controls.Add(this.label54, 0, 8);
            this.tableLayoutPanel11.Controls.Add(this.label55, 0, 9);
            this.tableLayoutPanel11.Controls.Add(this.label56, 0, 10);
            this.tableLayoutPanel11.Controls.Add(this.textBox21, 2, 10);
            this.tableLayoutPanel11.Controls.Add(this.txtOEE_SerialNumber, 1, 1);
            this.tableLayoutPanel11.Controls.Add(this.textBox23, 2, 1);
            this.tableLayoutPanel11.Controls.Add(this.txtOEE_Fixture, 1, 2);
            this.tableLayoutPanel11.Controls.Add(this.textBox25, 2, 2);
            this.tableLayoutPanel11.Controls.Add(this.txtOEE_StartTime, 1, 3);
            this.tableLayoutPanel11.Controls.Add(this.textBox27, 2, 3);
            this.tableLayoutPanel11.Controls.Add(this.txtOEE_EndTime, 1, 4);
            this.tableLayoutPanel11.Controls.Add(this.textBox29, 2, 4);
            this.tableLayoutPanel11.Controls.Add(this.txtOEE_Status, 1, 5);
            this.tableLayoutPanel11.Controls.Add(this.textBox31, 2, 5);
            this.tableLayoutPanel11.Controls.Add(this.txtOEE_ActualCT, 1, 6);
            this.tableLayoutPanel11.Controls.Add(this.textBox33, 2, 6);
            this.tableLayoutPanel11.Controls.Add(this.txtOEE_sw, 1, 7);
            this.tableLayoutPanel11.Controls.Add(this.textBox35, 2, 7);
            this.tableLayoutPanel11.Controls.Add(this.txtOEE_ScanCount, 1, 8);
            this.tableLayoutPanel11.Controls.Add(this.textBox37, 2, 8);
            this.tableLayoutPanel11.Controls.Add(this.textBox38, 1, 9);
            this.tableLayoutPanel11.Controls.Add(this.textBox39, 2, 9);
            this.tableLayoutPanel11.Controls.Add(this.textBox40, 1, 10);
            this.tableLayoutPanel11.Controls.Add(this.lb_OEE_UA_SendStatus, 1, 11);
            this.tableLayoutPanel11.Controls.Add(this.lb_OEE_LA_SendStatus, 2, 11);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel11.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 12;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(492, 369);
            this.tableLayoutPanel11.TabIndex = 1;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label45.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label45.Location = new System.Drawing.Point(307, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(182, 30);
            this.label45.TabIndex = 156;
            this.label45.Text = "LA";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label45.Visible = false;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label46.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label46.Location = new System.Drawing.Point(108, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(193, 30);
            this.label46.TabIndex = 155;
            this.label46.Text = "OEE";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label47.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(3, 30);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(99, 30);
            this.label47.TabIndex = 157;
            this.label47.Text = "SerialNumber:";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label48.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(3, 60);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(99, 30);
            this.label48.TabIndex = 158;
            this.label48.Text = "Fixture:";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label49.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(3, 90);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(99, 30);
            this.label49.TabIndex = 159;
            this.label49.Text = "StartTime:";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label50.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(3, 120);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(99, 30);
            this.label50.TabIndex = 160;
            this.label50.Text = "EndTime:";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label51.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(3, 150);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(99, 30);
            this.label51.TabIndex = 161;
            this.label51.Text = "Status:";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label52.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(3, 180);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(99, 30);
            this.label52.TabIndex = 162;
            this.label52.Text = "ActualCT:";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label53.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(3, 210);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(99, 30);
            this.label53.TabIndex = 163;
            this.label53.Text = "SwVersion:";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label54.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(3, 240);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(99, 30);
            this.label54.TabIndex = 164;
            this.label54.Text = "ScanCount:";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label55.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label55.Location = new System.Drawing.Point(3, 270);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(99, 30);
            this.label55.TabIndex = 165;
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label56.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label56.Location = new System.Drawing.Point(3, 300);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(99, 30);
            this.label56.TabIndex = 166;
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox21
            // 
            this.textBox21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox21.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox21.Location = new System.Drawing.Point(307, 303);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(182, 25);
            this.textBox21.TabIndex = 167;
            this.textBox21.Visible = false;
            // 
            // txtOEE_SerialNumber
            // 
            this.txtOEE_SerialNumber.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOEE_SerialNumber.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOEE_SerialNumber.Location = new System.Drawing.Point(108, 33);
            this.txtOEE_SerialNumber.Name = "txtOEE_SerialNumber";
            this.txtOEE_SerialNumber.Size = new System.Drawing.Size(193, 25);
            this.txtOEE_SerialNumber.TabIndex = 168;
            // 
            // textBox23
            // 
            this.textBox23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox23.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox23.Location = new System.Drawing.Point(307, 33);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(182, 25);
            this.textBox23.TabIndex = 169;
            this.textBox23.Visible = false;
            // 
            // txtOEE_Fixture
            // 
            this.txtOEE_Fixture.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOEE_Fixture.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOEE_Fixture.Location = new System.Drawing.Point(108, 63);
            this.txtOEE_Fixture.Name = "txtOEE_Fixture";
            this.txtOEE_Fixture.Size = new System.Drawing.Size(193, 25);
            this.txtOEE_Fixture.TabIndex = 170;
            // 
            // textBox25
            // 
            this.textBox25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox25.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox25.Location = new System.Drawing.Point(307, 63);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(182, 25);
            this.textBox25.TabIndex = 171;
            this.textBox25.Visible = false;
            // 
            // txtOEE_StartTime
            // 
            this.txtOEE_StartTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOEE_StartTime.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOEE_StartTime.Location = new System.Drawing.Point(108, 93);
            this.txtOEE_StartTime.Name = "txtOEE_StartTime";
            this.txtOEE_StartTime.Size = new System.Drawing.Size(193, 25);
            this.txtOEE_StartTime.TabIndex = 172;
            // 
            // textBox27
            // 
            this.textBox27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox27.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox27.Location = new System.Drawing.Point(307, 93);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(182, 25);
            this.textBox27.TabIndex = 173;
            this.textBox27.Visible = false;
            // 
            // txtOEE_EndTime
            // 
            this.txtOEE_EndTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOEE_EndTime.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOEE_EndTime.Location = new System.Drawing.Point(108, 123);
            this.txtOEE_EndTime.Name = "txtOEE_EndTime";
            this.txtOEE_EndTime.Size = new System.Drawing.Size(193, 25);
            this.txtOEE_EndTime.TabIndex = 174;
            // 
            // textBox29
            // 
            this.textBox29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox29.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox29.Location = new System.Drawing.Point(307, 123);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(182, 25);
            this.textBox29.TabIndex = 175;
            this.textBox29.Visible = false;
            // 
            // txtOEE_Status
            // 
            this.txtOEE_Status.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOEE_Status.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOEE_Status.Location = new System.Drawing.Point(108, 153);
            this.txtOEE_Status.Name = "txtOEE_Status";
            this.txtOEE_Status.Size = new System.Drawing.Size(193, 25);
            this.txtOEE_Status.TabIndex = 176;
            // 
            // textBox31
            // 
            this.textBox31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox31.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox31.Location = new System.Drawing.Point(307, 153);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(182, 25);
            this.textBox31.TabIndex = 177;
            this.textBox31.Visible = false;
            // 
            // txtOEE_ActualCT
            // 
            this.txtOEE_ActualCT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOEE_ActualCT.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOEE_ActualCT.Location = new System.Drawing.Point(108, 183);
            this.txtOEE_ActualCT.Name = "txtOEE_ActualCT";
            this.txtOEE_ActualCT.Size = new System.Drawing.Size(193, 25);
            this.txtOEE_ActualCT.TabIndex = 178;
            // 
            // textBox33
            // 
            this.textBox33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox33.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox33.Location = new System.Drawing.Point(307, 183);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(182, 25);
            this.textBox33.TabIndex = 179;
            this.textBox33.Visible = false;
            // 
            // txtOEE_sw
            // 
            this.txtOEE_sw.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOEE_sw.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOEE_sw.Location = new System.Drawing.Point(108, 213);
            this.txtOEE_sw.Name = "txtOEE_sw";
            this.txtOEE_sw.Size = new System.Drawing.Size(193, 25);
            this.txtOEE_sw.TabIndex = 180;
            // 
            // textBox35
            // 
            this.textBox35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox35.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox35.Location = new System.Drawing.Point(307, 213);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(182, 25);
            this.textBox35.TabIndex = 181;
            this.textBox35.Visible = false;
            // 
            // txtOEE_ScanCount
            // 
            this.txtOEE_ScanCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOEE_ScanCount.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOEE_ScanCount.Location = new System.Drawing.Point(108, 243);
            this.txtOEE_ScanCount.Name = "txtOEE_ScanCount";
            this.txtOEE_ScanCount.Size = new System.Drawing.Size(193, 25);
            this.txtOEE_ScanCount.TabIndex = 182;
            // 
            // textBox37
            // 
            this.textBox37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox37.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox37.Location = new System.Drawing.Point(307, 243);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(182, 25);
            this.textBox37.TabIndex = 183;
            this.textBox37.Visible = false;
            // 
            // textBox38
            // 
            this.textBox38.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox38.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox38.Location = new System.Drawing.Point(108, 273);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(193, 25);
            this.textBox38.TabIndex = 184;
            this.textBox38.Visible = false;
            // 
            // textBox39
            // 
            this.textBox39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox39.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox39.Location = new System.Drawing.Point(307, 273);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(182, 25);
            this.textBox39.TabIndex = 185;
            this.textBox39.Visible = false;
            // 
            // textBox40
            // 
            this.textBox40.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox40.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox40.Location = new System.Drawing.Point(108, 303);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(193, 25);
            this.textBox40.TabIndex = 186;
            this.textBox40.Visible = false;
            // 
            // lb_OEE_UA_SendStatus
            // 
            this.lb_OEE_UA_SendStatus.AutoSize = true;
            this.lb_OEE_UA_SendStatus.BackColor = System.Drawing.Color.Transparent;
            this.lb_OEE_UA_SendStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_OEE_UA_SendStatus.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_OEE_UA_SendStatus.Location = new System.Drawing.Point(108, 330);
            this.lb_OEE_UA_SendStatus.Name = "lb_OEE_UA_SendStatus";
            this.lb_OEE_UA_SendStatus.Size = new System.Drawing.Size(193, 39);
            this.lb_OEE_UA_SendStatus.TabIndex = 187;
            this.lb_OEE_UA_SendStatus.Text = "等待中。。。";
            this.lb_OEE_UA_SendStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_OEE_LA_SendStatus
            // 
            this.lb_OEE_LA_SendStatus.AutoSize = true;
            this.lb_OEE_LA_SendStatus.BackColor = System.Drawing.Color.Transparent;
            this.lb_OEE_LA_SendStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_OEE_LA_SendStatus.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_OEE_LA_SendStatus.Location = new System.Drawing.Point(307, 330);
            this.lb_OEE_LA_SendStatus.Name = "lb_OEE_LA_SendStatus";
            this.lb_OEE_LA_SendStatus.Size = new System.Drawing.Size(182, 39);
            this.lb_OEE_LA_SendStatus.TabIndex = 188;
            this.lb_OEE_LA_SendStatus.Text = "等待中。。。";
            this.lb_OEE_LA_SendStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lb_OEE_LA_SendStatus.Visible = false;
            // 
            // rtx_OEEDefaultMsg
            // 
            this.rtx_OEEDefaultMsg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtx_OEEDefaultMsg.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtx_OEEDefaultMsg.Location = new System.Drawing.Point(0, 0);
            this.rtx_OEEDefaultMsg.Name = "rtx_OEEDefaultMsg";
            this.rtx_OEEDefaultMsg.Size = new System.Drawing.Size(325, 369);
            this.rtx_OEEDefaultMsg.TabIndex = 2;
            this.rtx_OEEDefaultMsg.Text = "";
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.ColumnCount = 10;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel12.Controls.Add(this.lb_OEELANG, 7, 0);
            this.tableLayoutPanel12.Controls.Add(this.lb_OEELAOK, 5, 0);
            this.tableLayoutPanel12.Controls.Add(this.label63, 6, 0);
            this.tableLayoutPanel12.Controls.Add(this.lb_OEEOK, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.label44, 4, 0);
            this.tableLayoutPanel12.Controls.Add(this.label61, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.lb_OEENG, 3, 0);
            this.tableLayoutPanel12.Controls.Add(this.label62, 2, 0);
            this.tableLayoutPanel12.Controls.Add(this.lb_OEESendNG, 9, 0);
            this.tableLayoutPanel12.Controls.Add(this.label59, 8, 0);
            this.tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 1;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(827, 53);
            this.tableLayoutPanel12.TabIndex = 8;
            // 
            // lb_OEELANG
            // 
            this.lb_OEELANG.AutoSize = true;
            this.lb_OEELANG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_OEELANG.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lb_OEELANG.ForeColor = System.Drawing.Color.Red;
            this.lb_OEELANG.Location = new System.Drawing.Point(602, 0);
            this.lb_OEELANG.Name = "lb_OEELANG";
            this.lb_OEELANG.Size = new System.Drawing.Size(51, 53);
            this.lb_OEELANG.TabIndex = 13;
            this.lb_OEELANG.Text = "0";
            this.lb_OEELANG.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb_OEELANG.Visible = false;
            // 
            // lb_OEELAOK
            // 
            this.lb_OEELAOK.AutoSize = true;
            this.lb_OEELAOK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_OEELAOK.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lb_OEELAOK.ForeColor = System.Drawing.Color.Red;
            this.lb_OEELAOK.Location = new System.Drawing.Point(438, 0);
            this.lb_OEELAOK.Name = "lb_OEELAOK";
            this.lb_OEELAOK.Size = new System.Drawing.Size(51, 53);
            this.lb_OEELAOK.TabIndex = 13;
            this.lb_OEELAOK.Text = "0";
            this.lb_OEELAOK.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb_OEELAOK.Visible = false;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label63.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label63.Location = new System.Drawing.Point(495, 0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(101, 53);
            this.label63.TabIndex = 14;
            this.label63.Text = "LA焊接NG:";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label63.Visible = false;
            // 
            // lb_OEEOK
            // 
            this.lb_OEEOK.AutoSize = true;
            this.lb_OEEOK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_OEEOK.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lb_OEEOK.ForeColor = System.Drawing.Color.Red;
            this.lb_OEEOK.Location = new System.Drawing.Point(110, 0);
            this.lb_OEEOK.Name = "lb_OEEOK";
            this.lb_OEEOK.Size = new System.Drawing.Size(51, 53);
            this.lb_OEEOK.TabIndex = 13;
            this.lb_OEEOK.Text = "0";
            this.lb_OEEOK.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb_OEEOK.TextChanged += new System.EventHandler(this.lb_OEEOK_TextChanged);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label44.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label44.Location = new System.Drawing.Point(331, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(101, 53);
            this.label44.TabIndex = 14;
            this.label44.Text = "LA焊接OK:";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label44.Visible = false;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label61.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label61.Location = new System.Drawing.Point(3, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(101, 53);
            this.label61.TabIndex = 11;
            this.label61.Text = "OEE_焊接OK:";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lb_OEENG
            // 
            this.lb_OEENG.AutoSize = true;
            this.lb_OEENG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_OEENG.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lb_OEENG.ForeColor = System.Drawing.Color.Red;
            this.lb_OEENG.Location = new System.Drawing.Point(274, 0);
            this.lb_OEENG.Name = "lb_OEENG";
            this.lb_OEENG.Size = new System.Drawing.Size(51, 53);
            this.lb_OEENG.TabIndex = 10;
            this.lb_OEENG.Text = "0";
            this.lb_OEENG.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb_OEENG.TextChanged += new System.EventHandler(this.lb_OEENG_TextChanged);
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label62.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label62.Location = new System.Drawing.Point(167, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(101, 53);
            this.label62.TabIndex = 12;
            this.label62.Text = "OEE_焊接NG:";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lb_OEESendNG
            // 
            this.lb_OEESendNG.AutoSize = true;
            this.lb_OEESendNG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_OEESendNG.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lb_OEESendNG.ForeColor = System.Drawing.Color.Red;
            this.lb_OEESendNG.Location = new System.Drawing.Point(766, 0);
            this.lb_OEESendNG.Name = "lb_OEESendNG";
            this.lb_OEESendNG.Size = new System.Drawing.Size(58, 53);
            this.lb_OEESendNG.TabIndex = 14;
            this.lb_OEESendNG.Text = "0";
            this.lb_OEESendNG.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label59.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label59.Location = new System.Drawing.Point(659, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(101, 53);
            this.label59.TabIndex = 9;
            this.label59.Text = "缓存数:";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.tableLayoutPanel10);
            this.tabPage9.Font = new System.Drawing.Font("Calibri", 9F);
            this.tabPage9.Location = new System.Drawing.Point(4, 32);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(833, 456);
            this.tabPage9.TabIndex = 0;
            this.tabPage9.Text = "心跳&Machine&DownTime数据";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 1;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.Controls.Add(this.groupBox2, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.groupBox3, 0, 1);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 2;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(827, 450);
            this.tableLayoutPanel10.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rtx_HeartBeatMsg);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(3, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(821, 219);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "心跳/Machine数据";
            // 
            // rtx_HeartBeatMsg
            // 
            this.rtx_HeartBeatMsg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtx_HeartBeatMsg.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtx_HeartBeatMsg.Location = new System.Drawing.Point(3, 18);
            this.rtx_HeartBeatMsg.Name = "rtx_HeartBeatMsg";
            this.rtx_HeartBeatMsg.Size = new System.Drawing.Size(815, 198);
            this.rtx_HeartBeatMsg.TabIndex = 3;
            this.rtx_HeartBeatMsg.Text = "";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rtx_DownTimeMsg);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(3, 228);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(821, 219);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "DownTime数据";
            // 
            // rtx_DownTimeMsg
            // 
            this.rtx_DownTimeMsg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtx_DownTimeMsg.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtx_DownTimeMsg.Location = new System.Drawing.Point(3, 18);
            this.rtx_DownTimeMsg.Name = "rtx_DownTimeMsg";
            this.rtx_DownTimeMsg.Size = new System.Drawing.Size(815, 198);
            this.rtx_DownTimeMsg.TabIndex = 3;
            this.rtx_DownTimeMsg.Text = "";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.tableLayoutPanel4);
            this.tabPage3.Location = new System.Drawing.Point(4, 32);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(833, 456);
            this.tabPage3.TabIndex = 3;
            this.tabPage3.Text = "小料抛料";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Controls.Add(this.groupBox8, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel5, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 87F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(833, 456);
            this.tableLayoutPanel4.TabIndex = 4;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.rtx_OEEMateriel);
            this.groupBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox8.Location = new System.Drawing.Point(3, 62);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(827, 391);
            this.groupBox8.TabIndex = 9;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "数据区";
            // 
            // rtx_OEEMateriel
            // 
            this.rtx_OEEMateriel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtx_OEEMateriel.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtx_OEEMateriel.Location = new System.Drawing.Point(3, 19);
            this.rtx_OEEMateriel.Name = "rtx_OEEMateriel";
            this.rtx_OEEMateriel.Size = new System.Drawing.Size(821, 369);
            this.rtx_OEEMateriel.TabIndex = 3;
            this.rtx_OEEMateriel.Text = "";
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 10;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel5.Controls.Add(this.lb_Materiel_AllOK, 7, 0);
            this.tableLayoutPanel5.Controls.Add(this.lb_Materiel_Nut, 5, 0);
            this.tableLayoutPanel5.Controls.Add(this.label60, 6, 0);
            this.tableLayoutPanel5.Controls.Add(this.lb_Materiel_Total, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.label64, 4, 0);
            this.tableLayoutPanel5.Controls.Add(this.label91, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.lb_Materiel_AllNut, 3, 0);
            this.tableLayoutPanel5.Controls.Add(this.label109, 2, 0);
            this.tableLayoutPanel5.Controls.Add(this.lb_Materiel_OK, 9, 0);
            this.tableLayoutPanel5.Controls.Add(this.label111, 8, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(827, 53);
            this.tableLayoutPanel5.TabIndex = 8;
            // 
            // lb_Materiel_AllOK
            // 
            this.lb_Materiel_AllOK.AutoSize = true;
            this.lb_Materiel_AllOK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Materiel_AllOK.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lb_Materiel_AllOK.ForeColor = System.Drawing.Color.Red;
            this.lb_Materiel_AllOK.Location = new System.Drawing.Point(602, 0);
            this.lb_Materiel_AllOK.Name = "lb_Materiel_AllOK";
            this.lb_Materiel_AllOK.Size = new System.Drawing.Size(51, 53);
            this.lb_Materiel_AllOK.TabIndex = 13;
            this.lb_Materiel_AllOK.Text = "0";
            this.lb_Materiel_AllOK.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb_Materiel_AllOK.TextChanged += new System.EventHandler(this.lb_Materiel_AllOK_TextChanged);
            // 
            // lb_Materiel_Nut
            // 
            this.lb_Materiel_Nut.AutoSize = true;
            this.lb_Materiel_Nut.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Materiel_Nut.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lb_Materiel_Nut.ForeColor = System.Drawing.Color.Red;
            this.lb_Materiel_Nut.Location = new System.Drawing.Point(438, 0);
            this.lb_Materiel_Nut.Name = "lb_Materiel_Nut";
            this.lb_Materiel_Nut.Size = new System.Drawing.Size(51, 53);
            this.lb_Materiel_Nut.TabIndex = 13;
            this.lb_Materiel_Nut.Text = "0";
            this.lb_Materiel_Nut.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb_Materiel_Nut.TextChanged += new System.EventHandler(this.lb_Materiel_Nut_TextChanged);
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label60.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label60.Location = new System.Drawing.Point(495, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(101, 53);
            this.label60.TabIndex = 14;
            this.label60.Text = "合计成功数量:";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lb_Materiel_Total
            // 
            this.lb_Materiel_Total.AutoSize = true;
            this.lb_Materiel_Total.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Materiel_Total.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lb_Materiel_Total.ForeColor = System.Drawing.Color.Red;
            this.lb_Materiel_Total.Location = new System.Drawing.Point(110, 0);
            this.lb_Materiel_Total.Name = "lb_Materiel_Total";
            this.lb_Materiel_Total.Size = new System.Drawing.Size(51, 53);
            this.lb_Materiel_Total.TabIndex = 13;
            this.lb_Materiel_Total.Text = "0";
            this.lb_Materiel_Total.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb_Materiel_Total.TextChanged += new System.EventHandler(this.lb_Materiel_Total_TextChanged);
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label64.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label64.Location = new System.Drawing.Point(331, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(101, 53);
            this.label64.TabIndex = 14;
            this.label64.Text = "Nut抛料数量:";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label91.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label91.Location = new System.Drawing.Point(3, 0);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(101, 53);
            this.label91.TabIndex = 11;
            this.label91.Text = "总投入数量:";
            this.label91.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lb_Materiel_AllNut
            // 
            this.lb_Materiel_AllNut.AutoSize = true;
            this.lb_Materiel_AllNut.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Materiel_AllNut.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lb_Materiel_AllNut.ForeColor = System.Drawing.Color.Red;
            this.lb_Materiel_AllNut.Location = new System.Drawing.Point(274, 0);
            this.lb_Materiel_AllNut.Name = "lb_Materiel_AllNut";
            this.lb_Materiel_AllNut.Size = new System.Drawing.Size(51, 53);
            this.lb_Materiel_AllNut.TabIndex = 10;
            this.lb_Materiel_AllNut.Text = "0";
            this.lb_Materiel_AllNut.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb_Materiel_AllNut.TextChanged += new System.EventHandler(this.lb_Materiel_AllNut_TextChanged);
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label109.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label109.Location = new System.Drawing.Point(167, 0);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(101, 53);
            this.label109.TabIndex = 12;
            this.label109.Text = "合计抛料数量:";
            this.label109.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lb_Materiel_OK
            // 
            this.lb_Materiel_OK.AutoSize = true;
            this.lb_Materiel_OK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_Materiel_OK.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lb_Materiel_OK.ForeColor = System.Drawing.Color.Red;
            this.lb_Materiel_OK.Location = new System.Drawing.Point(766, 0);
            this.lb_Materiel_OK.Name = "lb_Materiel_OK";
            this.lb_Materiel_OK.Size = new System.Drawing.Size(58, 53);
            this.lb_Materiel_OK.TabIndex = 14;
            this.lb_Materiel_OK.Text = "0";
            this.lb_Materiel_OK.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb_Materiel_OK.TextChanged += new System.EventHandler(this.lb_Materiel_OK_TextChanged);
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label111.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label111.Location = new System.Drawing.Point(659, 0);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(101, 53);
            this.label111.TabIndex = 9;
            this.label111.Text = "Nut成功数量:";
            this.label111.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.tableLayoutPanel6);
            this.tabPage4.Location = new System.Drawing.Point(4, 32);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(833, 456);
            this.tabPage4.TabIndex = 4;
            this.tabPage4.Text = "手动测试上传OEE";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Controls.Add(this.tableLayoutPanel25, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.rtx_OEEMsg, 0, 1);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel6.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 85F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(833, 456);
            this.tableLayoutPanel6.TabIndex = 1;
            // 
            // tableLayoutPanel25
            // 
            this.tableLayoutPanel25.ColumnCount = 5;
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.07488F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.84711F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35.0234F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 327F));
            this.tableLayoutPanel25.Controls.Add(this.label16, 0, 0);
            this.tableLayoutPanel25.Controls.Add(this.OEE_index, 1, 0);
            this.tableLayoutPanel25.Controls.Add(this.OEE_labal, 2, 0);
            this.tableLayoutPanel25.Controls.Add(this.OEE_upload, 3, 0);
            this.tableLayoutPanel25.Controls.Add(this.OEE_uploadAll, 4, 0);
            this.tableLayoutPanel25.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel25.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel25.Name = "tableLayoutPanel25";
            this.tableLayoutPanel25.RowCount = 1;
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel25.Size = new System.Drawing.Size(829, 62);
            this.tableLayoutPanel25.TabIndex = 0;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(2, 0);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 62);
            this.label16.TabIndex = 0;
            this.label16.Text = "ErrorCode索引：";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // OEE_index
            // 
            this.OEE_index.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.OEE_index.Location = new System.Drawing.Point(77, 15);
            this.OEE_index.Margin = new System.Windows.Forms.Padding(2);
            this.OEE_index.Name = "OEE_index";
            this.OEE_index.Size = new System.Drawing.Size(106, 31);
            this.OEE_index.TabIndex = 1;
            // 
            // OEE_labal
            // 
            this.OEE_labal.AutoSize = true;
            this.OEE_labal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.OEE_labal.Font = new System.Drawing.Font("微软雅黑", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OEE_labal.ForeColor = System.Drawing.Color.Red;
            this.OEE_labal.Location = new System.Drawing.Point(187, 0);
            this.OEE_labal.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.OEE_labal.Name = "OEE_labal";
            this.OEE_labal.Size = new System.Drawing.Size(135, 62);
            this.OEE_labal.TabIndex = 3;
            this.OEE_labal.Text = "请输入整数";
            this.OEE_labal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // OEE_upload
            // 
            this.OEE_upload.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.OEE_upload.Location = new System.Drawing.Point(344, 11);
            this.OEE_upload.Margin = new System.Windows.Forms.Padding(2);
            this.OEE_upload.Name = "OEE_upload";
            this.OEE_upload.Size = new System.Drawing.Size(135, 40);
            this.OEE_upload.TabIndex = 2;
            this.OEE_upload.Text = "上传";
            this.OEE_upload.UseVisualStyleBackColor = true;
            this.OEE_upload.Click += new System.EventHandler(this.OEE_upload_Click);
            // 
            // OEE_uploadAll
            // 
            this.OEE_uploadAll.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.OEE_uploadAll.Location = new System.Drawing.Point(596, 11);
            this.OEE_uploadAll.Name = "OEE_uploadAll";
            this.OEE_uploadAll.Size = new System.Drawing.Size(135, 40);
            this.OEE_uploadAll.TabIndex = 4;
            this.OEE_uploadAll.Text = "一键上传";
            this.OEE_uploadAll.UseVisualStyleBackColor = true;
            this.OEE_uploadAll.Click += new System.EventHandler(this.OEE_uploadAll_Click);
            // 
            // rtx_OEEMsg
            // 
            this.rtx_OEEMsg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtx_OEEMsg.Location = new System.Drawing.Point(2, 70);
            this.rtx_OEEMsg.Margin = new System.Windows.Forms.Padding(2);
            this.rtx_OEEMsg.Name = "rtx_OEEMsg";
            this.rtx_OEEMsg.Size = new System.Drawing.Size(829, 384);
            this.rtx_OEEMsg.TabIndex = 1;
            this.rtx_OEEMsg.Text = "";
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.tableLayoutPanel16);
            this.tabPage11.Location = new System.Drawing.Point(124, 4);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Size = new System.Drawing.Size(841, 492);
            this.tabPage11.TabIndex = 5;
            this.tabPage11.Text = "前站校验";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.ColumnCount = 1;
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel16.Controls.Add(this.groupBox5, 0, 1);
            this.tableLayoutPanel16.Controls.Add(this.tableLayoutPanel18, 0, 0);
            this.tableLayoutPanel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel16.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 2;
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 87F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(841, 492);
            this.tableLayoutPanel16.TabIndex = 7;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.splitContainer5);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox5.Location = new System.Drawing.Point(3, 66);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(835, 423);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "数据区";
            // 
            // splitContainer5
            // 
            this.splitContainer5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer5.Location = new System.Drawing.Point(3, 19);
            this.splitContainer5.Name = "splitContainer5";
            // 
            // splitContainer5.Panel1
            // 
            this.splitContainer5.Panel1.Controls.Add(this.tableLayoutPanel17);
            // 
            // splitContainer5.Panel2
            // 
            this.splitContainer5.Panel2.Controls.Add(this.rtx_ProcessControl);
            this.splitContainer5.Panel2.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.splitContainer5.Size = new System.Drawing.Size(829, 401);
            this.splitContainer5.SplitterDistance = 457;
            this.splitContainer5.TabIndex = 1;
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.ColumnCount = 1;
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel17.Controls.Add(this.groupBox31, 0, 1);
            this.tableLayoutPanel17.Controls.Add(this.tableLayoutPanel19, 0, 0);
            this.tableLayoutPanel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel17.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 2;
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 26.06516F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 73.93484F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(457, 401);
            this.tableLayoutPanel17.TabIndex = 0;
            // 
            // groupBox31
            // 
            this.groupBox31.Controls.Add(this.rtx_ProcessControlErrorMsg);
            this.groupBox31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox31.Location = new System.Drawing.Point(3, 107);
            this.groupBox31.Name = "groupBox31";
            this.groupBox31.Size = new System.Drawing.Size(451, 291);
            this.groupBox31.TabIndex = 56;
            this.groupBox31.TabStop = false;
            this.groupBox31.Text = "返回结果";
            // 
            // rtx_ProcessControlErrorMsg
            // 
            this.rtx_ProcessControlErrorMsg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtx_ProcessControlErrorMsg.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtx_ProcessControlErrorMsg.Location = new System.Drawing.Point(3, 19);
            this.rtx_ProcessControlErrorMsg.Name = "rtx_ProcessControlErrorMsg";
            this.rtx_ProcessControlErrorMsg.Size = new System.Drawing.Size(445, 269);
            this.rtx_ProcessControlErrorMsg.TabIndex = 3;
            this.rtx_ProcessControlErrorMsg.Text = "";
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.ColumnCount = 2;
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18.77256F));
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 81.22744F));
            this.tableLayoutPanel19.Controls.Add(this.label123, 0, 0);
            this.tableLayoutPanel19.Controls.Add(this.txt_ProcessControl_SN, 1, 0);
            this.tableLayoutPanel19.Controls.Add(this.tableLayoutPanel3, 1, 1);
            this.tableLayoutPanel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel19.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.RowCount = 2;
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(451, 98);
            this.tableLayoutPanel19.TabIndex = 57;
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label123.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label123.Location = new System.Drawing.Point(3, 0);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(78, 49);
            this.label123.TabIndex = 45;
            this.label123.Text = "SN:";
            this.label123.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_ProcessControl_SN
            // 
            this.txt_ProcessControl_SN.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txt_ProcessControl_SN.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ProcessControl_SN.Location = new System.Drawing.Point(87, 12);
            this.txt_ProcessControl_SN.Name = "txt_ProcessControl_SN";
            this.txt_ProcessControl_SN.Size = new System.Drawing.Size(235, 25);
            this.txt_ProcessControl_SN.TabIndex = 46;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.txt_ProcessControl_Status, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(87, 52);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(361, 43);
            this.tableLayoutPanel3.TabIndex = 47;
            // 
            // txt_ProcessControl_Status
            // 
            this.txt_ProcessControl_Status.AutoSize = true;
            this.txt_ProcessControl_Status.BackColor = System.Drawing.Color.Transparent;
            this.txt_ProcessControl_Status.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_ProcessControl_Status.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ProcessControl_Status.Location = new System.Drawing.Point(3, 0);
            this.txt_ProcessControl_Status.Name = "txt_ProcessControl_Status";
            this.txt_ProcessControl_Status.Size = new System.Drawing.Size(174, 43);
            this.txt_ProcessControl_Status.TabIndex = 55;
            this.txt_ProcessControl_Status.Text = "等待中。。。";
            this.txt_ProcessControl_Status.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // rtx_ProcessControl
            // 
            this.rtx_ProcessControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtx_ProcessControl.Font = new System.Drawing.Font("Calibri", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtx_ProcessControl.Location = new System.Drawing.Point(0, 0);
            this.rtx_ProcessControl.Name = "rtx_ProcessControl";
            this.rtx_ProcessControl.Size = new System.Drawing.Size(368, 401);
            this.rtx_ProcessControl.TabIndex = 2;
            this.rtx_ProcessControl.Text = "";
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.ColumnCount = 10;
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel18.Controls.Add(this.lb_ProcessControlNG, 3, 0);
            this.tableLayoutPanel18.Controls.Add(this.label86, 2, 0);
            this.tableLayoutPanel18.Controls.Add(this.lb_ProcessControlOK, 1, 0);
            this.tableLayoutPanel18.Controls.Add(this.label88, 0, 0);
            this.tableLayoutPanel18.Controls.Add(this.label90, 9, 0);
            this.tableLayoutPanel18.Controls.Add(this.label89, 8, 0);
            this.tableLayoutPanel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel18.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 1;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(835, 57);
            this.tableLayoutPanel18.TabIndex = 2;
            // 
            // lb_ProcessControlNG
            // 
            this.lb_ProcessControlNG.AutoSize = true;
            this.lb_ProcessControlNG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ProcessControlNG.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lb_ProcessControlNG.ForeColor = System.Drawing.Color.Red;
            this.lb_ProcessControlNG.Location = new System.Drawing.Point(277, 0);
            this.lb_ProcessControlNG.Name = "lb_ProcessControlNG";
            this.lb_ProcessControlNG.Size = new System.Drawing.Size(52, 57);
            this.lb_ProcessControlNG.TabIndex = 3;
            this.lb_ProcessControlNG.Text = "0";
            this.lb_ProcessControlNG.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb_ProcessControlNG.TextChanged += new System.EventHandler(this.lb_ProcessControlNG_TextChanged);
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label86.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label86.Location = new System.Drawing.Point(169, 0);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(102, 57);
            this.label86.TabIndex = 2;
            this.label86.Text = "前站校验NG:";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lb_ProcessControlOK
            // 
            this.lb_ProcessControlOK.AutoSize = true;
            this.lb_ProcessControlOK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_ProcessControlOK.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.lb_ProcessControlOK.ForeColor = System.Drawing.Color.Red;
            this.lb_ProcessControlOK.Location = new System.Drawing.Point(111, 0);
            this.lb_ProcessControlOK.Name = "lb_ProcessControlOK";
            this.lb_ProcessControlOK.Size = new System.Drawing.Size(52, 57);
            this.lb_ProcessControlOK.TabIndex = 1;
            this.lb_ProcessControlOK.Text = "0";
            this.lb_ProcessControlOK.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb_ProcessControlOK.TextChanged += new System.EventHandler(this.lb_ProcessControlOK_TextChanged);
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label88.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label88.Location = new System.Drawing.Point(3, 0);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(102, 57);
            this.label88.TabIndex = 0;
            this.label88.Text = "前站校验OK:";
            this.label88.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label90.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label90.ForeColor = System.Drawing.Color.Red;
            this.label90.Location = new System.Drawing.Point(775, 0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(57, 57);
            this.label90.TabIndex = 19;
            this.label90.Text = "0";
            this.label90.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label89.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label89.Location = new System.Drawing.Point(667, 0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(102, 57);
            this.label89.TabIndex = 17;
            this.label89.Text = "缓存数:";
            this.label89.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.tabControl2);
            this.tabPage12.Location = new System.Drawing.Point(124, 4);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Size = new System.Drawing.Size(841, 492);
            this.tabPage12.TabIndex = 6;
            this.tabPage12.Text = "治具保养";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage13);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Location = new System.Drawing.Point(0, 0);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(841, 492);
            this.tabControl2.TabIndex = 1;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.tableLayoutPanel20);
            this.tabPage6.Location = new System.Drawing.Point(4, 23);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(833, 465);
            this.tabPage6.TabIndex = 0;
            this.tabPage6.Text = "治具IQC&PM";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.ColumnCount = 1;
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel20.Controls.Add(this.groupBox6, 0, 0);
            this.tableLayoutPanel20.Controls.Add(this.tableLayoutPanel22, 0, 1);
            this.tableLayoutPanel20.Controls.Add(this.tableLayoutPanel59, 0, 2);
            this.tableLayoutPanel20.Controls.Add(this.groupBox14, 0, 3);
            this.tableLayoutPanel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel20.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 4;
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 29F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 38F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(827, 459);
            this.tableLayoutPanel20.TabIndex = 2;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.tableLayoutPanel21);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox6.Location = new System.Drawing.Point(3, 3);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(821, 53);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "配置设定";
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.ColumnCount = 7;
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel21.Controls.Add(this.CB_Station, 3, 0);
            this.tableLayoutPanel21.Controls.Add(this.CB_project, 1, 0);
            this.tableLayoutPanel21.Controls.Add(this.label71, 0, 0);
            this.tableLayoutPanel21.Controls.Add(this.label72, 2, 0);
            this.tableLayoutPanel21.Controls.Add(this.label74, 4, 0);
            this.tableLayoutPanel21.Controls.Add(this.CB_Type, 5, 0);
            this.tableLayoutPanel21.Controls.Add(this.button19, 6, 0);
            this.tableLayoutPanel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel21.Location = new System.Drawing.Point(3, 18);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 1;
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(815, 32);
            this.tableLayoutPanel21.TabIndex = 1;
            // 
            // CB_Station
            // 
            this.CB_Station.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.CB_Station.FormattingEnabled = true;
            this.CB_Station.Items.AddRange(new object[] {
            "Spring_X_ST工站"});
            this.CB_Station.Location = new System.Drawing.Point(351, 5);
            this.CB_Station.Name = "CB_Station";
            this.CB_Station.Size = new System.Drawing.Size(110, 22);
            this.CB_Station.TabIndex = 5;
            this.CB_Station.Text = "Spring_X_ST工站";
            // 
            // CB_project
            // 
            this.CB_project.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.CB_project.FormattingEnabled = true;
            this.CB_project.Items.AddRange(new object[] {
            "Seattle-Housing"});
            this.CB_project.Location = new System.Drawing.Point(119, 5);
            this.CB_project.Name = "CB_project";
            this.CB_project.Size = new System.Drawing.Size(110, 22);
            this.CB_project.TabIndex = 4;
            this.CB_project.Text = "Seattle-Housing";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label71.Location = new System.Drawing.Point(3, 0);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(110, 32);
            this.label71.TabIndex = 0;
            this.label71.Text = "Project:";
            this.label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label72.Location = new System.Drawing.Point(235, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(110, 32);
            this.label72.TabIndex = 1;
            this.label72.Text = "Station:";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label74.Location = new System.Drawing.Point(467, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(110, 32);
            this.label74.TabIndex = 2;
            this.label74.Text = "Type:";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CB_Type
            // 
            this.CB_Type.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.CB_Type.FormattingEnabled = true;
            this.CB_Type.Items.AddRange(new object[] {
            "7D_ST"});
            this.CB_Type.Location = new System.Drawing.Point(583, 5);
            this.CB_Type.Name = "CB_Type";
            this.CB_Type.Size = new System.Drawing.Size(110, 22);
            this.CB_Type.TabIndex = 3;
            this.CB_Type.Text = "7D_ST";
            // 
            // button19
            // 
            this.button19.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button19.Location = new System.Drawing.Point(699, 3);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(113, 26);
            this.button19.TabIndex = 6;
            this.button19.Text = "设定";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.ColumnCount = 2;
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel22.Controls.Add(this.groupBox10, 1, 0);
            this.tableLayoutPanel22.Controls.Add(this.groupBox11, 0, 0);
            this.tableLayoutPanel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel22.Location = new System.Drawing.Point(3, 62);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 1;
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 127F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(821, 127);
            this.tableLayoutPanel22.TabIndex = 1;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.list_IQCFixture);
            this.groupBox10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox10.Location = new System.Drawing.Point(413, 3);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(405, 121);
            this.groupBox10.TabIndex = 1;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "治具IQC OK清单";
            // 
            // list_IQCFixture
            // 
            this.list_IQCFixture.Dock = System.Windows.Forms.DockStyle.Fill;
            this.list_IQCFixture.FormattingEnabled = true;
            this.list_IQCFixture.ItemHeight = 14;
            this.list_IQCFixture.Location = new System.Drawing.Point(3, 18);
            this.list_IQCFixture.Name = "list_IQCFixture";
            this.list_IQCFixture.ScrollAlwaysVisible = true;
            this.list_IQCFixture.Size = new System.Drawing.Size(399, 100);
            this.list_IQCFixture.TabIndex = 1;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.list_FixtureMsg);
            this.groupBox11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox11.Location = new System.Drawing.Point(3, 3);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(404, 121);
            this.groupBox11.TabIndex = 2;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "治具保养NG清单";
            // 
            // list_FixtureMsg
            // 
            this.list_FixtureMsg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.list_FixtureMsg.FormattingEnabled = true;
            this.list_FixtureMsg.ItemHeight = 14;
            this.list_FixtureMsg.Location = new System.Drawing.Point(3, 18);
            this.list_FixtureMsg.Name = "list_FixtureMsg";
            this.list_FixtureMsg.ScrollAlwaysVisible = true;
            this.list_FixtureMsg.Size = new System.Drawing.Size(398, 100);
            this.list_FixtureMsg.TabIndex = 0;
            // 
            // tableLayoutPanel59
            // 
            this.tableLayoutPanel59.ColumnCount = 2;
            this.tableLayoutPanel59.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel59.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel59.Controls.Add(this.groupBox12, 1, 0);
            this.tableLayoutPanel59.Controls.Add(this.groupBox13, 0, 0);
            this.tableLayoutPanel59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel59.Location = new System.Drawing.Point(3, 195);
            this.tableLayoutPanel59.Name = "tableLayoutPanel59";
            this.tableLayoutPanel59.RowCount = 1;
            this.tableLayoutPanel59.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel59.Size = new System.Drawing.Size(821, 85);
            this.tableLayoutPanel59.TabIndex = 2;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.list_IQCFixtureNG);
            this.groupBox12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox12.Location = new System.Drawing.Point(413, 3);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(405, 79);
            this.groupBox12.TabIndex = 3;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "治具IQC对比不到OK清单";
            // 
            // list_IQCFixtureNG
            // 
            this.list_IQCFixtureNG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.list_IQCFixtureNG.ForeColor = System.Drawing.Color.Red;
            this.list_IQCFixtureNG.FormattingEnabled = true;
            this.list_IQCFixtureNG.ItemHeight = 14;
            this.list_IQCFixtureNG.Location = new System.Drawing.Point(3, 18);
            this.list_IQCFixtureNG.Name = "list_IQCFixtureNG";
            this.list_IQCFixtureNG.ScrollAlwaysVisible = true;
            this.list_IQCFixtureNG.Size = new System.Drawing.Size(399, 58);
            this.list_IQCFixtureNG.TabIndex = 2;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.list_FixtureMsgNG);
            this.groupBox13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox13.Location = new System.Drawing.Point(3, 3);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(404, 79);
            this.groupBox13.TabIndex = 3;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "治具保养对比到NG清单";
            // 
            // list_FixtureMsgNG
            // 
            this.list_FixtureMsgNG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.list_FixtureMsgNG.ForeColor = System.Drawing.Color.Red;
            this.list_FixtureMsgNG.FormattingEnabled = true;
            this.list_FixtureMsgNG.ItemHeight = 14;
            this.list_FixtureMsgNG.Location = new System.Drawing.Point(3, 18);
            this.list_FixtureMsgNG.Name = "list_FixtureMsgNG";
            this.list_FixtureMsgNG.ScrollAlwaysVisible = true;
            this.list_FixtureMsgNG.Size = new System.Drawing.Size(398, 58);
            this.list_FixtureMsgNG.TabIndex = 1;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.tableLayoutPanel60);
            this.groupBox14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox14.Location = new System.Drawing.Point(3, 286);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(821, 170);
            this.groupBox14.TabIndex = 3;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "治具小保养功能";
            // 
            // tableLayoutPanel60
            // 
            this.tableLayoutPanel60.ColumnCount = 1;
            this.tableLayoutPanel60.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel60.Controls.Add(this.tableLayoutPanel61, 0, 0);
            this.tableLayoutPanel60.Controls.Add(this.grid_AllFixture, 0, 1);
            this.tableLayoutPanel60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel60.Location = new System.Drawing.Point(3, 18);
            this.tableLayoutPanel60.Name = "tableLayoutPanel60";
            this.tableLayoutPanel60.RowCount = 2;
            this.tableLayoutPanel60.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 27.11864F));
            this.tableLayoutPanel60.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 72.88136F));
            this.tableLayoutPanel60.Size = new System.Drawing.Size(815, 149);
            this.tableLayoutPanel60.TabIndex = 1;
            // 
            // tableLayoutPanel61
            // 
            this.tableLayoutPanel61.ColumnCount = 12;
            this.tableLayoutPanel61.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11062F));
            this.tableLayoutPanel61.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11062F));
            this.tableLayoutPanel61.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11062F));
            this.tableLayoutPanel61.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11062F));
            this.tableLayoutPanel61.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.999645F));
            this.tableLayoutPanel61.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.999733F));
            this.tableLayoutPanel61.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.999645F));
            this.tableLayoutPanel61.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.999733F));
            this.tableLayoutPanel61.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.999645F));
            this.tableLayoutPanel61.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.999733F));
            this.tableLayoutPanel61.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.999645F));
            this.tableLayoutPanel61.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.559753F));
            this.tableLayoutPanel61.Controls.Add(this.label92, 0, 0);
            this.tableLayoutPanel61.Controls.Add(this.txt_Fixture_Mantain_Count, 1, 0);
            this.tableLayoutPanel61.Controls.Add(this.label93, 2, 0);
            this.tableLayoutPanel61.Controls.Add(this.txt_Fixture_Mantain_Time, 3, 0);
            this.tableLayoutPanel61.Controls.Add(this.btn_Fixture_Clear, 4, 0);
            this.tableLayoutPanel61.Controls.Add(this.btn_Fixture_Add, 8, 0);
            this.tableLayoutPanel61.Controls.Add(this.btn_Fixture_Delete, 10, 0);
            this.tableLayoutPanel61.Controls.Add(this.btn_Fixture_Out, 6, 0);
            this.tableLayoutPanel61.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel61.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel61.Name = "tableLayoutPanel61";
            this.tableLayoutPanel61.RowCount = 1;
            this.tableLayoutPanel61.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel61.Size = new System.Drawing.Size(809, 34);
            this.tableLayoutPanel61.TabIndex = 0;
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label92.Location = new System.Drawing.Point(3, 0);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(83, 34);
            this.label92.TabIndex = 0;
            this.label92.Text = "保养次数设定:";
            this.label92.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txt_Fixture_Mantain_Count
            // 
            this.txt_Fixture_Mantain_Count.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txt_Fixture_Mantain_Count.Location = new System.Drawing.Point(92, 6);
            this.txt_Fixture_Mantain_Count.Name = "txt_Fixture_Mantain_Count";
            this.txt_Fixture_Mantain_Count.Size = new System.Drawing.Size(54, 22);
            this.txt_Fixture_Mantain_Count.TabIndex = 1;
            this.txt_Fixture_Mantain_Count.Text = "2550";
            this.txt_Fixture_Mantain_Count.TextChanged += new System.EventHandler(this.txt_Fixture_Mantain_Count_TextChanged);
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label93.Location = new System.Drawing.Point(181, 0);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(83, 34);
            this.label93.TabIndex = 2;
            this.label93.Text = "保养时间设置:";
            this.label93.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txt_Fixture_Mantain_Time
            // 
            this.txt_Fixture_Mantain_Time.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txt_Fixture_Mantain_Time.Location = new System.Drawing.Point(270, 6);
            this.txt_Fixture_Mantain_Time.Name = "txt_Fixture_Mantain_Time";
            this.txt_Fixture_Mantain_Time.Size = new System.Drawing.Size(50, 22);
            this.txt_Fixture_Mantain_Time.TabIndex = 3;
            this.txt_Fixture_Mantain_Time.Text = "0";
            this.txt_Fixture_Mantain_Time.TextChanged += new System.EventHandler(this.txt_Fixture_Mantain_Time_TextChanged);
            // 
            // btn_Fixture_Clear
            // 
            this.btn_Fixture_Clear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Fixture_Clear.Location = new System.Drawing.Point(359, 5);
            this.btn_Fixture_Clear.Name = "btn_Fixture_Clear";
            this.btn_Fixture_Clear.Size = new System.Drawing.Size(58, 23);
            this.btn_Fixture_Clear.TabIndex = 7;
            this.btn_Fixture_Clear.Text = "手动清除";
            this.btn_Fixture_Clear.UseVisualStyleBackColor = true;
            this.btn_Fixture_Clear.Click += new System.EventHandler(this.btn_Fixture_Clear_Click);
            // 
            // btn_Fixture_Add
            // 
            this.btn_Fixture_Add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Fixture_Add.Location = new System.Drawing.Point(583, 5);
            this.btn_Fixture_Add.Name = "btn_Fixture_Add";
            this.btn_Fixture_Add.Size = new System.Drawing.Size(58, 23);
            this.btn_Fixture_Add.TabIndex = 8;
            this.btn_Fixture_Add.Text = "添加治具";
            this.btn_Fixture_Add.UseVisualStyleBackColor = true;
            this.btn_Fixture_Add.Click += new System.EventHandler(this.btn_Fixture_Add_Click);
            // 
            // btn_Fixture_Delete
            // 
            this.btn_Fixture_Delete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Fixture_Delete.Location = new System.Drawing.Point(695, 5);
            this.btn_Fixture_Delete.Name = "btn_Fixture_Delete";
            this.btn_Fixture_Delete.Size = new System.Drawing.Size(58, 23);
            this.btn_Fixture_Delete.TabIndex = 9;
            this.btn_Fixture_Delete.Text = "移除治具";
            this.btn_Fixture_Delete.UseVisualStyleBackColor = true;
            this.btn_Fixture_Delete.Click += new System.EventHandler(this.btn_Fixture_Delete_Click);
            // 
            // btn_Fixture_Out
            // 
            this.btn_Fixture_Out.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Fixture_Out.Location = new System.Drawing.Point(471, 5);
            this.btn_Fixture_Out.Name = "btn_Fixture_Out";
            this.btn_Fixture_Out.Size = new System.Drawing.Size(58, 24);
            this.btn_Fixture_Out.TabIndex = 6;
            this.btn_Fixture_Out.Text = "手动排出";
            this.btn_Fixture_Out.UseVisualStyleBackColor = true;
            this.btn_Fixture_Out.Click += new System.EventHandler(this.btn_FixtureOut_Click);
            // 
            // grid_AllFixture
            // 
            this.grid_AllFixture.AllowUserToAddRows = false;
            this.grid_AllFixture.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.grid_AllFixture.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.grid_AllFixture.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid_AllFixture.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.grid_AllFixture.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grid_AllFixture.Location = new System.Drawing.Point(3, 43);
            this.grid_AllFixture.Name = "grid_AllFixture";
            this.grid_AllFixture.ReadOnly = true;
            this.grid_AllFixture.RowHeadersWidth = 51;
            this.grid_AllFixture.RowTemplate.Height = 23;
            this.grid_AllFixture.Size = new System.Drawing.Size(809, 103);
            this.grid_AllFixture.TabIndex = 1;
            this.grid_AllFixture.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grid_AllFixture_CellContentClick);
            this.grid_AllFixture.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.grid_AllFixture_RowPrePaint);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ID";
            this.dataGridViewTextBoxColumn1.HeaderText = "序号";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 124;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "FixtureID";
            this.dataGridViewTextBoxColumn2.HeaderText = "治具码";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 124;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Time";
            this.dataGridViewTextBoxColumn3.HeaderText = "保养时间";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 124;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "UsingTimes";
            this.dataGridViewTextBoxColumn4.HeaderText = "使用次数";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 124;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "CountDown";
            this.dataGridViewTextBoxColumn5.HeaderText = "使用时间";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 124;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Status";
            this.dataGridViewTextBoxColumn6.HeaderText = "状态";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 124;
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.tableLayoutPanel62);
            this.tabPage13.Location = new System.Drawing.Point(4, 23);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage13.Size = new System.Drawing.Size(833, 465);
            this.tabPage13.TabIndex = 1;
            this.tabPage13.Text = "治具抛料记录";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel62
            // 
            this.tableLayoutPanel62.ColumnCount = 1;
            this.tableLayoutPanel62.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel62.Controls.Add(this.tableLayoutPanel63, 0, 0);
            this.tableLayoutPanel62.Controls.Add(this.groupBox17, 0, 1);
            this.tableLayoutPanel62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel62.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel62.Name = "tableLayoutPanel62";
            this.tableLayoutPanel62.RowCount = 2;
            this.tableLayoutPanel62.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 59.25926F));
            this.tableLayoutPanel62.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.74074F));
            this.tableLayoutPanel62.Size = new System.Drawing.Size(827, 459);
            this.tableLayoutPanel62.TabIndex = 0;
            // 
            // tableLayoutPanel63
            // 
            this.tableLayoutPanel63.ColumnCount = 2;
            this.tableLayoutPanel63.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 82.61851F));
            this.tableLayoutPanel63.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.38149F));
            this.tableLayoutPanel63.Controls.Add(this.groupBox15, 0, 0);
            this.tableLayoutPanel63.Controls.Add(this.groupBox16, 1, 0);
            this.tableLayoutPanel63.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel63.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel63.Name = "tableLayoutPanel63";
            this.tableLayoutPanel63.RowCount = 1;
            this.tableLayoutPanel63.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel63.Size = new System.Drawing.Size(821, 265);
            this.tableLayoutPanel63.TabIndex = 0;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.tableLayoutPanel64);
            this.groupBox15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox15.Location = new System.Drawing.Point(3, 3);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(672, 259);
            this.groupBox15.TabIndex = 0;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "工站治具管控";
            // 
            // tableLayoutPanel64
            // 
            this.tableLayoutPanel64.ColumnCount = 1;
            this.tableLayoutPanel64.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel64.Controls.Add(this.grid_TossingFixture, 0, 1);
            this.tableLayoutPanel64.Controls.Add(this.tableLayoutPanel65, 0, 0);
            this.tableLayoutPanel64.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel64.Location = new System.Drawing.Point(3, 18);
            this.tableLayoutPanel64.Name = "tableLayoutPanel64";
            this.tableLayoutPanel64.RowCount = 2;
            this.tableLayoutPanel64.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.89796F));
            this.tableLayoutPanel64.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80.10204F));
            this.tableLayoutPanel64.Size = new System.Drawing.Size(666, 238);
            this.tableLayoutPanel64.TabIndex = 0;
            // 
            // grid_TossingFixture
            // 
            this.grid_TossingFixture.AllowUserToAddRows = false;
            this.grid_TossingFixture.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_TossingFixture.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.grid_TossingFixture.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid_TossingFixture.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grid_TossingFixture.DefaultCellStyle = dataGridViewCellStyle4;
            this.grid_TossingFixture.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grid_TossingFixture.Location = new System.Drawing.Point(3, 50);
            this.grid_TossingFixture.Name = "grid_TossingFixture";
            this.grid_TossingFixture.RowHeadersWidth = 51;
            this.grid_TossingFixture.RowTemplate.Height = 23;
            this.grid_TossingFixture.Size = new System.Drawing.Size(660, 185);
            this.grid_TossingFixture.TabIndex = 1;
            this.grid_TossingFixture.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grid_TossingFixture_CellContentClick);
            this.grid_TossingFixture.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.grid_TossingFixture_RowPrePaint);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "治具码";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "抛料时间";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "连续抛料次数(Max 3)";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "(抛料次数Max 5)";
            this.Column4.MinimumWidth = 6;
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "连续NG";
            this.Column5.MinimumWidth = 6;
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.HeaderText = "次数NG";
            this.Column6.MinimumWidth = 6;
            this.Column6.Name = "Column6";
            // 
            // tableLayoutPanel65
            // 
            this.tableLayoutPanel65.ColumnCount = 8;
            this.tableLayoutPanel65.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.13895F));
            this.tableLayoutPanel65.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.14009F));
            this.tableLayoutPanel65.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.08205F));
            this.tableLayoutPanel65.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18.92405F));
            this.tableLayoutPanel65.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.13829F));
            this.tableLayoutPanel65.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.14094F));
            this.tableLayoutPanel65.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.21922F));
            this.tableLayoutPanel65.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.2164F));
            this.tableLayoutPanel65.Controls.Add(this.txt_Fixture_CountNG, 4, 0);
            this.tableLayoutPanel65.Controls.Add(this.button24, 0, 0);
            this.tableLayoutPanel65.Controls.Add(this.label82, 1, 0);
            this.tableLayoutPanel65.Controls.Add(this.label83, 3, 0);
            this.tableLayoutPanel65.Controls.Add(this.btn_Setting_Limit, 5, 0);
            this.tableLayoutPanel65.Controls.Add(this.txt_Fixture_ContinuationNG, 2, 0);
            this.tableLayoutPanel65.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel65.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel65.Name = "tableLayoutPanel65";
            this.tableLayoutPanel65.RowCount = 1;
            this.tableLayoutPanel65.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel65.Size = new System.Drawing.Size(660, 41);
            this.tableLayoutPanel65.TabIndex = 2;
            // 
            // txt_Fixture_CountNG
            // 
            this.txt_Fixture_CountNG.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Fixture_CountNG.FormattingEnabled = true;
            this.txt_Fixture_CountNG.Items.AddRange(new object[] {
            "5",
            "10",
            "50",
            "100",
            "200"});
            this.txt_Fixture_CountNG.Location = new System.Drawing.Point(371, 9);
            this.txt_Fixture_CountNG.Name = "txt_Fixture_CountNG";
            this.txt_Fixture_CountNG.Size = new System.Drawing.Size(80, 22);
            this.txt_Fixture_CountNG.TabIndex = 5;
            this.txt_Fixture_CountNG.Text = "5";
            // 
            // button24
            // 
            this.button24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button24.Location = new System.Drawing.Point(3, 3);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(60, 35);
            this.button24.TabIndex = 0;
            this.button24.Text = "配置设定";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label82.Location = new System.Drawing.Point(69, 0);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(80, 41);
            this.label82.TabIndex = 1;
            this.label82.Text = "连续抛料上限";
            this.label82.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label83.Location = new System.Drawing.Point(247, 0);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(118, 41);
            this.label83.TabIndex = 2;
            this.label83.Text = "总抛料次数上限设定";
            this.label83.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_Setting_Limit
            // 
            this.btn_Setting_Limit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_Setting_Limit.Location = new System.Drawing.Point(457, 3);
            this.btn_Setting_Limit.Name = "btn_Setting_Limit";
            this.btn_Setting_Limit.Size = new System.Drawing.Size(60, 35);
            this.btn_Setting_Limit.TabIndex = 3;
            this.btn_Setting_Limit.Text = "设定";
            this.btn_Setting_Limit.UseVisualStyleBackColor = true;
            this.btn_Setting_Limit.Click += new System.EventHandler(this.btn_Setting_Limit_Click);
            // 
            // txt_Fixture_ContinuationNG
            // 
            this.txt_Fixture_ContinuationNG.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Fixture_ContinuationNG.FormattingEnabled = true;
            this.txt_Fixture_ContinuationNG.Items.AddRange(new object[] {
            "3",
            "5",
            "10"});
            this.txt_Fixture_ContinuationNG.Location = new System.Drawing.Point(155, 9);
            this.txt_Fixture_ContinuationNG.Name = "txt_Fixture_ContinuationNG";
            this.txt_Fixture_ContinuationNG.Size = new System.Drawing.Size(86, 22);
            this.txt_Fixture_ContinuationNG.TabIndex = 4;
            this.txt_Fixture_ContinuationNG.Text = "3";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.btn_Outputfixture);
            this.groupBox16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox16.Location = new System.Drawing.Point(681, 3);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(137, 259);
            this.groupBox16.TabIndex = 1;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "操作";
            // 
            // btn_Outputfixture
            // 
            this.btn_Outputfixture.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Outputfixture.Location = new System.Drawing.Point(6, 21);
            this.btn_Outputfixture.Name = "btn_Outputfixture";
            this.btn_Outputfixture.Size = new System.Drawing.Size(125, 34);
            this.btn_Outputfixture.TabIndex = 0;
            this.btn_Outputfixture.Text = "导出全部治具号";
            this.btn_Outputfixture.UseVisualStyleBackColor = true;
            this.btn_Outputfixture.Click += new System.EventHandler(this.btn_Outputfixture_Click);
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.tableLayoutPanel66);
            this.groupBox17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox17.Location = new System.Drawing.Point(3, 274);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(821, 182);
            this.groupBox17.TabIndex = 1;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "查询";
            // 
            // tableLayoutPanel66
            // 
            this.tableLayoutPanel66.ColumnCount = 1;
            this.tableLayoutPanel66.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel66.Controls.Add(this.tableLayoutPanel67, 0, 0);
            this.tableLayoutPanel66.Controls.Add(this.list_FixtureNG, 0, 1);
            this.tableLayoutPanel66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel66.Location = new System.Drawing.Point(3, 18);
            this.tableLayoutPanel66.Name = "tableLayoutPanel66";
            this.tableLayoutPanel66.RowCount = 2;
            this.tableLayoutPanel66.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.87578F));
            this.tableLayoutPanel66.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80.12422F));
            this.tableLayoutPanel66.Size = new System.Drawing.Size(815, 161);
            this.tableLayoutPanel66.TabIndex = 0;
            // 
            // tableLayoutPanel67
            // 
            this.tableLayoutPanel67.ColumnCount = 8;
            this.tableLayoutPanel67.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel67.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel67.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel67.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel67.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel67.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel67.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel67.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel67.Controls.Add(this.label96, 0, 0);
            this.tableLayoutPanel67.Controls.Add(this.label141, 2, 0);
            this.tableLayoutPanel67.Controls.Add(this.txt_SelectFixture, 1, 0);
            this.tableLayoutPanel67.Controls.Add(this.dtp_SelectFixture, 3, 0);
            this.tableLayoutPanel67.Controls.Add(this.btn_SelectFixture, 4, 0);
            this.tableLayoutPanel67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel67.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel67.Name = "tableLayoutPanel67";
            this.tableLayoutPanel67.RowCount = 1;
            this.tableLayoutPanel67.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel67.Size = new System.Drawing.Size(809, 26);
            this.tableLayoutPanel67.TabIndex = 0;
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label96.Location = new System.Drawing.Point(3, 0);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(74, 26);
            this.label96.TabIndex = 0;
            this.label96.Text = "治具SN:";
            this.label96.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label141.Location = new System.Drawing.Point(244, 0);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(74, 26);
            this.label141.TabIndex = 1;
            this.label141.Text = "时间：";
            this.label141.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txt_SelectFixture
            // 
            this.txt_SelectFixture.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_SelectFixture.Location = new System.Drawing.Point(83, 3);
            this.txt_SelectFixture.Name = "txt_SelectFixture";
            this.txt_SelectFixture.Size = new System.Drawing.Size(155, 22);
            this.txt_SelectFixture.TabIndex = 2;
            // 
            // dtp_SelectFixture
            // 
            this.dtp_SelectFixture.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dtp_SelectFixture.Location = new System.Drawing.Point(324, 3);
            this.dtp_SelectFixture.Name = "dtp_SelectFixture";
            this.dtp_SelectFixture.Size = new System.Drawing.Size(155, 22);
            this.dtp_SelectFixture.TabIndex = 3;
            // 
            // btn_SelectFixture
            // 
            this.btn_SelectFixture.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_SelectFixture.Location = new System.Drawing.Point(485, 3);
            this.btn_SelectFixture.Name = "btn_SelectFixture";
            this.btn_SelectFixture.Size = new System.Drawing.Size(74, 20);
            this.btn_SelectFixture.TabIndex = 4;
            this.btn_SelectFixture.Text = "治具查询";
            this.btn_SelectFixture.UseVisualStyleBackColor = true;
            this.btn_SelectFixture.Click += new System.EventHandler(this.btn_SelectFixture_Click);
            // 
            // list_FixtureNG
            // 
            this.list_FixtureNG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.list_FixtureNG.FormattingEnabled = true;
            this.list_FixtureNG.ItemHeight = 14;
            this.list_FixtureNG.Location = new System.Drawing.Point(3, 35);
            this.list_FixtureNG.Name = "list_FixtureNG";
            this.list_FixtureNG.Size = new System.Drawing.Size(809, 123);
            this.list_FixtureNG.TabIndex = 1;
            // 
            // tabPage14
            // 
            this.tabPage14.Controls.Add(this.tabControl4);
            this.tabPage14.Location = new System.Drawing.Point(124, 4);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage14.Size = new System.Drawing.Size(841, 492);
            this.tabPage14.TabIndex = 8;
            this.tabPage14.Text = "电批扭力";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // tabControl4
            // 
            this.tabControl4.Controls.Add(this.tabPage15);
            this.tabControl4.Controls.Add(this.tabPage16);
            this.tabControl4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl4.Location = new System.Drawing.Point(3, 3);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(835, 486);
            this.tabControl4.TabIndex = 332;
            // 
            // tabPage15
            // 
            this.tabPage15.Controls.Add(this.tableLayoutPanel68);
            this.tabPage15.Location = new System.Drawing.Point(4, 23);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage15.Size = new System.Drawing.Size(827, 459);
            this.tabPage15.TabIndex = 0;
            this.tabPage15.Text = "实时监控";
            this.tabPage15.UseVisualStyleBackColor = true;
            this.tabPage15.Click += new System.EventHandler(this.tabPage15_Click);
            // 
            // tableLayoutPanel68
            // 
            this.tableLayoutPanel68.ColumnCount = 2;
            this.tableLayoutPanel68.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel68.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel68.Controls.Add(this.tableLayoutPanel72, 0, 1);
            this.tableLayoutPanel68.Controls.Add(this.tableLayoutPanel69, 0, 0);
            this.tableLayoutPanel68.Controls.Add(this.label167, 1, 2);
            this.tableLayoutPanel68.Controls.Add(this.scottRealWaveL, 0, 3);
            this.tableLayoutPanel68.Controls.Add(this.scottRealWaveR, 0, 4);
            this.tableLayoutPanel68.Controls.Add(this.dplusRTB, 1, 3);
            this.tableLayoutPanel68.Controls.Add(this.label166, 0, 2);
            this.tableLayoutPanel68.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel68.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel68.Name = "tableLayoutPanel68";
            this.tableLayoutPanel68.RowCount = 1;
            this.tableLayoutPanel68.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.78947F));
            this.tableLayoutPanel68.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.78947F));
            this.tableLayoutPanel68.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.263158F));
            this.tableLayoutPanel68.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 31.57895F));
            this.tableLayoutPanel68.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 31.57895F));
            this.tableLayoutPanel68.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel68.Size = new System.Drawing.Size(821, 453);
            this.tableLayoutPanel68.TabIndex = 0;
            // 
            // tableLayoutPanel72
            // 
            this.tableLayoutPanel72.AutoSize = true;
            this.tableLayoutPanel72.ColumnCount = 7;
            this.tableLayoutPanel68.SetColumnSpan(this.tableLayoutPanel72, 2);
            this.tableLayoutPanel72.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 74.39446F));
            this.tableLayoutPanel72.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.60554F));
            this.tableLayoutPanel72.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel72.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 188F));
            this.tableLayoutPanel72.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 108F));
            this.tableLayoutPanel72.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 95F));
            this.tableLayoutPanel72.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel72.Controls.Add(this.label183, 3, 1);
            this.tableLayoutPanel72.Controls.Add(this.label185, 5, 2);
            this.tableLayoutPanel72.Controls.Add(this.label186, 5, 1);
            this.tableLayoutPanel72.Controls.Add(this.label187, 1, 2);
            this.tableLayoutPanel72.Controls.Add(this.label188, 3, 2);
            this.tableLayoutPanel72.Controls.Add(this.label190, 4, 2);
            this.tableLayoutPanel72.Controls.Add(this.label192, 4, 1);
            this.tableLayoutPanel72.Controls.Add(this.label193, 1, 1);
            this.tableLayoutPanel72.Controls.Add(this.label195, 5, 0);
            this.tableLayoutPanel72.Controls.Add(this.label196, 4, 0);
            this.tableLayoutPanel72.Controls.Add(this.label197, 3, 0);
            this.tableLayoutPanel72.Controls.Add(this.label198, 0, 2);
            this.tableLayoutPanel72.Controls.Add(this.label199, 0, 1);
            this.tableLayoutPanel72.Controls.Add(this.label202, 1, 0);
            this.tableLayoutPanel72.Controls.Add(this.label203, 0, 0);
            this.tableLayoutPanel72.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel72.Location = new System.Drawing.Point(3, 71);
            this.tableLayoutPanel72.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.tableLayoutPanel72.Name = "tableLayoutPanel72";
            this.tableLayoutPanel72.RowCount = 3;
            this.tableLayoutPanel72.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.tableLayoutPanel72.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32F));
            this.tableLayoutPanel72.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32F));
            this.tableLayoutPanel72.Size = new System.Drawing.Size(818, 71);
            this.tableLayoutPanel72.TabIndex = 105;
            // 
            // label183
            // 
            this.label183.BackColor = System.Drawing.Color.Gray;
            this.label183.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label183.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label183.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label183.ForeColor = System.Drawing.Color.LimeGreen;
            this.label183.Location = new System.Drawing.Point(336, 26);
            this.label183.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label183.Name = "label183";
            this.label183.Size = new System.Drawing.Size(187, 19);
            this.label183.TabIndex = 353;
            this.label183.Text = "0.00";
            this.label183.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label185
            // 
            this.label185.BackColor = System.Drawing.Color.Gray;
            this.label185.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tableLayoutPanel72.SetColumnSpan(this.label185, 2);
            this.label185.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label185.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label185.ForeColor = System.Drawing.Color.LimeGreen;
            this.label185.Location = new System.Drawing.Point(632, 48);
            this.label185.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label185.Name = "label185";
            this.label185.Size = new System.Drawing.Size(185, 21);
            this.label185.TabIndex = 352;
            this.label185.Text = "0.00";
            this.label185.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label186
            // 
            this.label186.BackColor = System.Drawing.Color.Gray;
            this.label186.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tableLayoutPanel72.SetColumnSpan(this.label186, 2);
            this.label186.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label186.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label186.ForeColor = System.Drawing.Color.LimeGreen;
            this.label186.Location = new System.Drawing.Point(632, 26);
            this.label186.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label186.Name = "label186";
            this.label186.Size = new System.Drawing.Size(185, 19);
            this.label186.TabIndex = 351;
            this.label186.Text = "0.00";
            this.label186.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label187
            // 
            this.label187.BackColor = System.Drawing.Color.Gray;
            this.label187.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tableLayoutPanel72.SetColumnSpan(this.label187, 2);
            this.label187.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label187.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label187.ForeColor = System.Drawing.Color.LimeGreen;
            this.label187.Location = new System.Drawing.Point(177, 48);
            this.label187.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label187.Name = "label187";
            this.label187.Size = new System.Drawing.Size(158, 21);
            this.label187.TabIndex = 350;
            this.label187.Text = "0.00";
            this.label187.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label188
            // 
            this.label188.BackColor = System.Drawing.Color.Gray;
            this.label188.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label188.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label188.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label188.ForeColor = System.Drawing.Color.LimeGreen;
            this.label188.Location = new System.Drawing.Point(336, 48);
            this.label188.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label188.Name = "label188";
            this.label188.Size = new System.Drawing.Size(187, 21);
            this.label188.TabIndex = 349;
            this.label188.Text = "0.00";
            this.label188.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label190
            // 
            this.label190.BackColor = System.Drawing.Color.Gray;
            this.label190.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label190.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label190.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label190.ForeColor = System.Drawing.Color.LimeGreen;
            this.label190.Location = new System.Drawing.Point(524, 48);
            this.label190.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label190.Name = "label190";
            this.label190.Size = new System.Drawing.Size(107, 21);
            this.label190.TabIndex = 346;
            this.label190.Text = "0";
            this.label190.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label192
            // 
            this.label192.BackColor = System.Drawing.Color.Gray;
            this.label192.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label192.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label192.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label192.ForeColor = System.Drawing.Color.LimeGreen;
            this.label192.Location = new System.Drawing.Point(524, 26);
            this.label192.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label192.Name = "label192";
            this.label192.Size = new System.Drawing.Size(107, 19);
            this.label192.TabIndex = 343;
            this.label192.Text = "0";
            this.label192.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label193
            // 
            this.label193.BackColor = System.Drawing.Color.Gray;
            this.label193.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tableLayoutPanel72.SetColumnSpan(this.label193, 2);
            this.label193.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label193.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label193.ForeColor = System.Drawing.Color.LimeGreen;
            this.label193.Location = new System.Drawing.Point(177, 26);
            this.label193.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label193.Name = "label193";
            this.label193.Size = new System.Drawing.Size(158, 19);
            this.label193.TabIndex = 339;
            this.label193.Text = "0.00";
            this.label193.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label195
            // 
            this.label195.BackColor = System.Drawing.Color.MistyRose;
            this.label195.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tableLayoutPanel72.SetColumnSpan(this.label195, 2);
            this.label195.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label195.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label195.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label195.Location = new System.Drawing.Point(632, 1);
            this.label195.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label195.Name = "label195";
            this.label195.Size = new System.Drawing.Size(185, 22);
            this.label195.TabIndex = 337;
            this.label195.Text = "扭力保持时间(ms)";
            this.label195.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label196
            // 
            this.label196.BackColor = System.Drawing.Color.MistyRose;
            this.label196.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label196.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label196.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label196.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label196.Location = new System.Drawing.Point(524, 1);
            this.label196.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label196.Name = "label196";
            this.label196.Size = new System.Drawing.Size(107, 22);
            this.label196.TabIndex = 336;
            this.label196.Text = "拧紧速度";
            this.label196.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label197
            // 
            this.label197.BackColor = System.Drawing.Color.MistyRose;
            this.label197.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label197.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label197.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label197.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label197.Location = new System.Drawing.Point(336, 1);
            this.label197.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label197.Name = "label197";
            this.label197.Size = new System.Drawing.Size(187, 22);
            this.label197.TabIndex = 335;
            this.label197.Text = "目标扭力(kgf.cm)";
            this.label197.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label198
            // 
            this.label198.BackColor = System.Drawing.Color.Gray;
            this.label198.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label198.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label198.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label198.ForeColor = System.Drawing.Color.LimeGreen;
            this.label198.Location = new System.Drawing.Point(0, 48);
            this.label198.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label198.Name = "label198";
            this.label198.Size = new System.Drawing.Size(176, 21);
            this.label198.TabIndex = 334;
            this.label198.Text = "2";
            this.label198.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label199
            // 
            this.label199.BackColor = System.Drawing.Color.Gray;
            this.label199.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label199.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label199.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label199.ForeColor = System.Drawing.Color.LimeGreen;
            this.label199.Location = new System.Drawing.Point(0, 26);
            this.label199.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label199.Name = "label199";
            this.label199.Size = new System.Drawing.Size(176, 19);
            this.label199.TabIndex = 329;
            this.label199.Text = "1";
            this.label199.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label202
            // 
            this.label202.BackColor = System.Drawing.Color.MistyRose;
            this.label202.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tableLayoutPanel72.SetColumnSpan(this.label202, 2);
            this.label202.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label202.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label202.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label202.Location = new System.Drawing.Point(177, 1);
            this.label202.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label202.Name = "label202";
            this.label202.Size = new System.Drawing.Size(158, 22);
            this.label202.TabIndex = 326;
            this.label202.Text = "拧紧圈数(r)";
            this.label202.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label203
            // 
            this.label203.BackColor = System.Drawing.Color.MistyRose;
            this.label203.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label203.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label203.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label203.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label203.Location = new System.Drawing.Point(0, 1);
            this.label203.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label203.Name = "label203";
            this.label203.Size = new System.Drawing.Size(176, 22);
            this.label203.TabIndex = 325;
            this.label203.Text = "编号";
            this.label203.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel69
            // 
            this.tableLayoutPanel69.AutoSize = true;
            this.tableLayoutPanel69.ColumnCount = 7;
            this.tableLayoutPanel68.SetColumnSpan(this.tableLayoutPanel69, 2);
            this.tableLayoutPanel69.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 74.39446F));
            this.tableLayoutPanel69.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.60554F));
            this.tableLayoutPanel69.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel69.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 188F));
            this.tableLayoutPanel69.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 108F));
            this.tableLayoutPanel69.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 95F));
            this.tableLayoutPanel69.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel69.Controls.Add(this.label155, 3, 1);
            this.tableLayoutPanel69.Controls.Add(this.label143, 5, 2);
            this.tableLayoutPanel69.Controls.Add(this.label153, 5, 1);
            this.tableLayoutPanel69.Controls.Add(this.label146, 2, 2);
            this.tableLayoutPanel69.Controls.Add(this.label145, 3, 2);
            this.tableLayoutPanel69.Controls.Add(this.label95, 6, 2);
            this.tableLayoutPanel69.Controls.Add(this.label144, 4, 2);
            this.tableLayoutPanel69.Controls.Add(this.label151, 6, 1);
            this.tableLayoutPanel69.Controls.Add(this.label154, 4, 1);
            this.tableLayoutPanel69.Controls.Add(this.label156, 2, 1);
            this.tableLayoutPanel69.Controls.Add(this.label159, 6, 0);
            this.tableLayoutPanel69.Controls.Add(this.label161, 5, 0);
            this.tableLayoutPanel69.Controls.Add(this.label162, 4, 0);
            this.tableLayoutPanel69.Controls.Add(this.label163, 3, 0);
            this.tableLayoutPanel69.Controls.Add(this.label25, 1, 2);
            this.tableLayoutPanel69.Controls.Add(this.label148, 1, 1);
            this.tableLayoutPanel69.Controls.Add(this.label147, 0, 2);
            this.tableLayoutPanel69.Controls.Add(this.label158, 0, 1);
            this.tableLayoutPanel69.Controls.Add(this.label164, 2, 0);
            this.tableLayoutPanel69.Controls.Add(this.label149, 1, 0);
            this.tableLayoutPanel69.Controls.Add(this.label165, 0, 0);
            this.tableLayoutPanel69.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel69.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel69.Name = "tableLayoutPanel69";
            this.tableLayoutPanel69.RowCount = 3;
            this.tableLayoutPanel69.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.tableLayoutPanel69.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32F));
            this.tableLayoutPanel69.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32F));
            this.tableLayoutPanel69.Size = new System.Drawing.Size(815, 65);
            this.tableLayoutPanel69.TabIndex = 104;
            // 
            // label155
            // 
            this.label155.BackColor = System.Drawing.Color.Gray;
            this.label155.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label155.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label155.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label155.ForeColor = System.Drawing.Color.LimeGreen;
            this.label155.Location = new System.Drawing.Point(333, 24);
            this.label155.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label155.Name = "label155";
            this.label155.Size = new System.Drawing.Size(187, 17);
            this.label155.TabIndex = 353;
            this.label155.Text = "0.00";
            this.label155.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label143
            // 
            this.label143.BackColor = System.Drawing.Color.Gray;
            this.label143.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label143.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label143.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label143.ForeColor = System.Drawing.Color.LimeGreen;
            this.label143.Location = new System.Drawing.Point(629, 44);
            this.label143.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(94, 19);
            this.label143.TabIndex = 352;
            this.label143.Text = "未知";
            this.label143.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label153
            // 
            this.label153.BackColor = System.Drawing.Color.Gray;
            this.label153.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label153.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label153.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label153.ForeColor = System.Drawing.Color.LimeGreen;
            this.label153.Location = new System.Drawing.Point(629, 24);
            this.label153.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label153.Name = "label153";
            this.label153.Size = new System.Drawing.Size(94, 17);
            this.label153.TabIndex = 351;
            this.label153.Text = "未知";
            this.label153.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label146
            // 
            this.label146.BackColor = System.Drawing.Color.Gray;
            this.label146.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label146.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label146.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label146.ForeColor = System.Drawing.Color.LimeGreen;
            this.label146.Location = new System.Drawing.Point(234, 44);
            this.label146.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(98, 19);
            this.label146.TabIndex = 350;
            this.label146.Text = "0.00";
            this.label146.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label145
            // 
            this.label145.BackColor = System.Drawing.Color.Gray;
            this.label145.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label145.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label145.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label145.ForeColor = System.Drawing.Color.LimeGreen;
            this.label145.Location = new System.Drawing.Point(333, 44);
            this.label145.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label145.Name = "label145";
            this.label145.Size = new System.Drawing.Size(187, 19);
            this.label145.TabIndex = 349;
            this.label145.Text = "0.00";
            this.label145.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label95
            // 
            this.label95.BackColor = System.Drawing.Color.Gray;
            this.label95.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label95.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label95.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label95.ForeColor = System.Drawing.Color.LimeGreen;
            this.label95.Location = new System.Drawing.Point(724, 44);
            this.label95.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(90, 19);
            this.label95.TabIndex = 348;
            this.label95.Text = "无";
            this.label95.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label144
            // 
            this.label144.BackColor = System.Drawing.Color.Gray;
            this.label144.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label144.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label144.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label144.ForeColor = System.Drawing.Color.LimeGreen;
            this.label144.Location = new System.Drawing.Point(521, 44);
            this.label144.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(107, 19);
            this.label144.TabIndex = 346;
            this.label144.Text = "0";
            this.label144.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label151
            // 
            this.label151.BackColor = System.Drawing.Color.Gray;
            this.label151.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label151.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label151.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label151.ForeColor = System.Drawing.Color.LimeGreen;
            this.label151.Location = new System.Drawing.Point(724, 24);
            this.label151.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label151.Name = "label151";
            this.label151.Size = new System.Drawing.Size(90, 17);
            this.label151.TabIndex = 345;
            this.label151.Text = "无";
            this.label151.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label154
            // 
            this.label154.BackColor = System.Drawing.Color.Gray;
            this.label154.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label154.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label154.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label154.ForeColor = System.Drawing.Color.LimeGreen;
            this.label154.Location = new System.Drawing.Point(521, 24);
            this.label154.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label154.Name = "label154";
            this.label154.Size = new System.Drawing.Size(107, 17);
            this.label154.TabIndex = 343;
            this.label154.Text = "0";
            this.label154.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label156
            // 
            this.label156.BackColor = System.Drawing.Color.Gray;
            this.label156.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label156.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label156.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label156.ForeColor = System.Drawing.Color.LimeGreen;
            this.label156.Location = new System.Drawing.Point(234, 24);
            this.label156.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label156.Name = "label156";
            this.label156.Size = new System.Drawing.Size(98, 17);
            this.label156.TabIndex = 339;
            this.label156.Text = "0.00";
            this.label156.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label159
            // 
            this.label159.BackColor = System.Drawing.Color.MistyRose;
            this.label159.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label159.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label159.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label159.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label159.Location = new System.Drawing.Point(724, 1);
            this.label159.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label159.Name = "label159";
            this.label159.Size = new System.Drawing.Size(90, 20);
            this.label159.TabIndex = 338;
            this.label159.Text = "警报";
            this.label159.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label161
            // 
            this.label161.BackColor = System.Drawing.Color.MistyRose;
            this.label161.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label161.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label161.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label161.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label161.Location = new System.Drawing.Point(629, 1);
            this.label161.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label161.Name = "label161";
            this.label161.Size = new System.Drawing.Size(94, 20);
            this.label161.TabIndex = 337;
            this.label161.Text = "拧紧结果";
            this.label161.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label162
            // 
            this.label162.BackColor = System.Drawing.Color.MistyRose;
            this.label162.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label162.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label162.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label162.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label162.Location = new System.Drawing.Point(521, 1);
            this.label162.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label162.Name = "label162";
            this.label162.Size = new System.Drawing.Size(107, 20);
            this.label162.TabIndex = 336;
            this.label162.Text = "耗时(ms)";
            this.label162.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label163
            // 
            this.label163.BackColor = System.Drawing.Color.MistyRose;
            this.label163.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label163.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label163.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label163.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label163.Location = new System.Drawing.Point(333, 1);
            this.label163.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label163.Name = "label163";
            this.label163.Size = new System.Drawing.Size(187, 20);
            this.label163.TabIndex = 335;
            this.label163.Text = "最大扭力(kgf.cm)";
            this.label163.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.Gray;
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label25.ForeColor = System.Drawing.Color.LimeGreen;
            this.label25.Location = new System.Drawing.Point(174, 44);
            this.label25.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(59, 19);
            this.label25.TabIndex = 334;
            this.label25.Text = "2";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label148
            // 
            this.label148.BackColor = System.Drawing.Color.Gray;
            this.label148.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label148.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label148.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label148.ForeColor = System.Drawing.Color.LimeGreen;
            this.label148.Location = new System.Drawing.Point(174, 24);
            this.label148.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label148.Name = "label148";
            this.label148.Size = new System.Drawing.Size(59, 17);
            this.label148.TabIndex = 329;
            this.label148.Text = "1";
            this.label148.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label147
            // 
            this.label147.BackColor = System.Drawing.Color.Gray;
            this.label147.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label147.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label147.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label147.ForeColor = System.Drawing.Color.LimeGreen;
            this.label147.Location = new System.Drawing.Point(0, 44);
            this.label147.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label147.Name = "label147";
            this.label147.Size = new System.Drawing.Size(173, 19);
            this.label147.TabIndex = 328;
            this.label147.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label158
            // 
            this.label158.BackColor = System.Drawing.Color.Gray;
            this.label158.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label158.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label158.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label158.ForeColor = System.Drawing.Color.LimeGreen;
            this.label158.Location = new System.Drawing.Point(0, 24);
            this.label158.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label158.Name = "label158";
            this.label158.Size = new System.Drawing.Size(173, 17);
            this.label158.TabIndex = 327;
            this.label158.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label164
            // 
            this.label164.BackColor = System.Drawing.Color.MistyRose;
            this.label164.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label164.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label164.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label164.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label164.Location = new System.Drawing.Point(234, 1);
            this.label164.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label164.Name = "label164";
            this.label164.Size = new System.Drawing.Size(98, 20);
            this.label164.TabIndex = 326;
            this.label164.Text = "圈数(r)";
            this.label164.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label149
            // 
            this.label149.BackColor = System.Drawing.Color.MistyRose;
            this.label149.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label149.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label149.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label149.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label149.Location = new System.Drawing.Point(174, 1);
            this.label149.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(59, 20);
            this.label149.TabIndex = 325;
            this.label149.Text = "编号";
            this.label149.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label165
            // 
            this.label165.BackColor = System.Drawing.Color.MistyRose;
            this.label165.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label165.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label165.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label165.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label165.Location = new System.Drawing.Point(0, 1);
            this.label165.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label165.Name = "label165";
            this.label165.Size = new System.Drawing.Size(173, 20);
            this.label165.TabIndex = 311;
            this.label165.Text = "产品码";
            this.label165.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label167
            // 
            this.label167.AutoSize = true;
            this.label167.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label167.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label167.Location = new System.Drawing.Point(574, 142);
            this.label167.Margin = new System.Windows.Forms.Padding(0);
            this.label167.Name = "label167";
            this.label167.Size = new System.Drawing.Size(247, 23);
            this.label167.TabIndex = 100;
            this.label167.Text = "电批记录";
            this.label167.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // scottRealWaveL
            // 
            this.scottRealWaveL.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.scottRealWaveL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scottRealWaveL.Location = new System.Drawing.Point(2, 167);
            this.scottRealWaveL.Margin = new System.Windows.Forms.Padding(2);
            this.scottRealWaveL.Name = "scottRealWaveL";
            this.scottRealWaveL.Size = new System.Drawing.Size(570, 139);
            this.scottRealWaveL.TabIndex = 98;
            // 
            // scottRealWaveR
            // 
            this.scottRealWaveR.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.scottRealWaveR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scottRealWaveR.Location = new System.Drawing.Point(2, 310);
            this.scottRealWaveR.Margin = new System.Windows.Forms.Padding(2);
            this.scottRealWaveR.Name = "scottRealWaveR";
            this.scottRealWaveR.Size = new System.Drawing.Size(570, 141);
            this.scottRealWaveR.TabIndex = 97;
            // 
            // dplusRTB
            // 
            this.dplusRTB.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dplusRTB.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dplusRTB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dplusRTB.ForeColor = System.Drawing.Color.White;
            this.dplusRTB.Location = new System.Drawing.Point(576, 167);
            this.dplusRTB.Margin = new System.Windows.Forms.Padding(2);
            this.dplusRTB.Name = "dplusRTB";
            this.tableLayoutPanel68.SetRowSpan(this.dplusRTB, 2);
            this.dplusRTB.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.dplusRTB.Size = new System.Drawing.Size(243, 284);
            this.dplusRTB.TabIndex = 96;
            this.dplusRTB.Text = "";
            // 
            // label166
            // 
            this.label166.AutoSize = true;
            this.label166.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label166.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label166.Location = new System.Drawing.Point(0, 142);
            this.label166.Margin = new System.Windows.Forms.Padding(0);
            this.label166.Name = "label166";
            this.label166.Size = new System.Drawing.Size(574, 23);
            this.label166.TabIndex = 99;
            this.label166.Text = "实时波形";
            this.label166.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tabPage16
            // 
            this.tabPage16.Controls.Add(this.tableLayoutPanel70);
            this.tabPage16.Location = new System.Drawing.Point(4, 23);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage16.Size = new System.Drawing.Size(827, 459);
            this.tabPage16.TabIndex = 1;
            this.tabPage16.Text = "历史记录";
            this.tabPage16.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel70
            // 
            this.tableLayoutPanel70.ColumnCount = 2;
            this.tableLayoutPanel70.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.52132F));
            this.tableLayoutPanel70.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 67.47868F));
            this.tableLayoutPanel70.Controls.Add(this.tableLayoutPanel71, 0, 1);
            this.tableLayoutPanel70.Controls.Add(this.formsPlot1, 0, 3);
            this.tableLayoutPanel70.Controls.Add(this.formsPlot2, 0, 4);
            this.tableLayoutPanel70.Controls.Add(this.label184, 0, 2);
            this.tableLayoutPanel70.Controls.Add(this.textBox1, 0, 0);
            this.tableLayoutPanel70.Controls.Add(this.button20, 1, 0);
            this.tableLayoutPanel70.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel70.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel70.Name = "tableLayoutPanel70";
            this.tableLayoutPanel70.RowCount = 5;
            this.tableLayoutPanel70.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel70.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24F));
            this.tableLayoutPanel70.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel70.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32F));
            this.tableLayoutPanel70.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32F));
            this.tableLayoutPanel70.Size = new System.Drawing.Size(821, 453);
            this.tableLayoutPanel70.TabIndex = 1;
            // 
            // tableLayoutPanel71
            // 
            this.tableLayoutPanel71.AutoSize = true;
            this.tableLayoutPanel71.ColumnCount = 7;
            this.tableLayoutPanel70.SetColumnSpan(this.tableLayoutPanel71, 2);
            this.tableLayoutPanel71.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 74.39446F));
            this.tableLayoutPanel71.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.60554F));
            this.tableLayoutPanel71.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel71.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 188F));
            this.tableLayoutPanel71.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 108F));
            this.tableLayoutPanel71.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 95F));
            this.tableLayoutPanel71.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel71.Controls.Add(this.label116, 3, 1);
            this.tableLayoutPanel71.Controls.Add(this.label142, 5, 2);
            this.tableLayoutPanel71.Controls.Add(this.label150, 5, 1);
            this.tableLayoutPanel71.Controls.Add(this.label152, 2, 2);
            this.tableLayoutPanel71.Controls.Add(this.label157, 3, 2);
            this.tableLayoutPanel71.Controls.Add(this.label160, 6, 2);
            this.tableLayoutPanel71.Controls.Add(this.label168, 4, 2);
            this.tableLayoutPanel71.Controls.Add(this.label169, 6, 1);
            this.tableLayoutPanel71.Controls.Add(this.label170, 4, 1);
            this.tableLayoutPanel71.Controls.Add(this.label171, 2, 1);
            this.tableLayoutPanel71.Controls.Add(this.label172, 6, 0);
            this.tableLayoutPanel71.Controls.Add(this.label173, 5, 0);
            this.tableLayoutPanel71.Controls.Add(this.label174, 4, 0);
            this.tableLayoutPanel71.Controls.Add(this.label175, 3, 0);
            this.tableLayoutPanel71.Controls.Add(this.label176, 1, 2);
            this.tableLayoutPanel71.Controls.Add(this.label177, 1, 1);
            this.tableLayoutPanel71.Controls.Add(this.label178, 0, 2);
            this.tableLayoutPanel71.Controls.Add(this.label179, 0, 1);
            this.tableLayoutPanel71.Controls.Add(this.label180, 2, 0);
            this.tableLayoutPanel71.Controls.Add(this.label181, 1, 0);
            this.tableLayoutPanel71.Controls.Add(this.label182, 0, 0);
            this.tableLayoutPanel71.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel71.Location = new System.Drawing.Point(3, 39);
            this.tableLayoutPanel71.Name = "tableLayoutPanel71";
            this.tableLayoutPanel71.RowCount = 3;
            this.tableLayoutPanel71.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.tableLayoutPanel71.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32F));
            this.tableLayoutPanel71.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32F));
            this.tableLayoutPanel71.Size = new System.Drawing.Size(815, 102);
            this.tableLayoutPanel71.TabIndex = 104;
            // 
            // label116
            // 
            this.label116.BackColor = System.Drawing.Color.Gray;
            this.label116.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label116.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label116.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label116.ForeColor = System.Drawing.Color.LimeGreen;
            this.label116.Location = new System.Drawing.Point(333, 37);
            this.label116.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(187, 29);
            this.label116.TabIndex = 353;
            this.label116.Text = "0.00";
            this.label116.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label142
            // 
            this.label142.BackColor = System.Drawing.Color.Gray;
            this.label142.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label142.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label142.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label142.ForeColor = System.Drawing.Color.LimeGreen;
            this.label142.Location = new System.Drawing.Point(629, 69);
            this.label142.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(94, 31);
            this.label142.TabIndex = 352;
            this.label142.Text = "未知";
            this.label142.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label150
            // 
            this.label150.BackColor = System.Drawing.Color.Gray;
            this.label150.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label150.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label150.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label150.ForeColor = System.Drawing.Color.LimeGreen;
            this.label150.Location = new System.Drawing.Point(629, 37);
            this.label150.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label150.Name = "label150";
            this.label150.Size = new System.Drawing.Size(94, 29);
            this.label150.TabIndex = 351;
            this.label150.Text = "未知";
            this.label150.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label152
            // 
            this.label152.BackColor = System.Drawing.Color.Gray;
            this.label152.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label152.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label152.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label152.ForeColor = System.Drawing.Color.LimeGreen;
            this.label152.Location = new System.Drawing.Point(234, 69);
            this.label152.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(98, 31);
            this.label152.TabIndex = 350;
            this.label152.Text = "0.00";
            this.label152.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label157
            // 
            this.label157.BackColor = System.Drawing.Color.Gray;
            this.label157.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label157.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label157.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label157.ForeColor = System.Drawing.Color.LimeGreen;
            this.label157.Location = new System.Drawing.Point(333, 69);
            this.label157.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label157.Name = "label157";
            this.label157.Size = new System.Drawing.Size(187, 31);
            this.label157.TabIndex = 349;
            this.label157.Text = "0.00";
            this.label157.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label160
            // 
            this.label160.BackColor = System.Drawing.Color.Gray;
            this.label160.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label160.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label160.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label160.ForeColor = System.Drawing.Color.LimeGreen;
            this.label160.Location = new System.Drawing.Point(724, 69);
            this.label160.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label160.Name = "label160";
            this.label160.Size = new System.Drawing.Size(90, 31);
            this.label160.TabIndex = 348;
            this.label160.Text = "无";
            this.label160.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label168
            // 
            this.label168.BackColor = System.Drawing.Color.Gray;
            this.label168.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label168.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label168.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label168.ForeColor = System.Drawing.Color.LimeGreen;
            this.label168.Location = new System.Drawing.Point(521, 69);
            this.label168.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label168.Name = "label168";
            this.label168.Size = new System.Drawing.Size(107, 31);
            this.label168.TabIndex = 346;
            this.label168.Text = "0";
            this.label168.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label169
            // 
            this.label169.BackColor = System.Drawing.Color.Gray;
            this.label169.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label169.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label169.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label169.ForeColor = System.Drawing.Color.LimeGreen;
            this.label169.Location = new System.Drawing.Point(724, 37);
            this.label169.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label169.Name = "label169";
            this.label169.Size = new System.Drawing.Size(90, 29);
            this.label169.TabIndex = 345;
            this.label169.Text = "无";
            this.label169.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label170
            // 
            this.label170.BackColor = System.Drawing.Color.Gray;
            this.label170.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label170.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label170.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label170.ForeColor = System.Drawing.Color.LimeGreen;
            this.label170.Location = new System.Drawing.Point(521, 37);
            this.label170.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label170.Name = "label170";
            this.label170.Size = new System.Drawing.Size(107, 29);
            this.label170.TabIndex = 343;
            this.label170.Text = "0";
            this.label170.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label171
            // 
            this.label171.BackColor = System.Drawing.Color.Gray;
            this.label171.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label171.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label171.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label171.ForeColor = System.Drawing.Color.LimeGreen;
            this.label171.Location = new System.Drawing.Point(234, 37);
            this.label171.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label171.Name = "label171";
            this.label171.Size = new System.Drawing.Size(98, 29);
            this.label171.TabIndex = 339;
            this.label171.Text = "0.00";
            this.label171.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label172
            // 
            this.label172.BackColor = System.Drawing.Color.MistyRose;
            this.label172.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label172.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label172.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label172.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label172.Location = new System.Drawing.Point(724, 1);
            this.label172.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label172.Name = "label172";
            this.label172.Size = new System.Drawing.Size(90, 33);
            this.label172.TabIndex = 338;
            this.label172.Text = "警报";
            this.label172.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label173
            // 
            this.label173.BackColor = System.Drawing.Color.MistyRose;
            this.label173.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label173.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label173.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label173.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label173.Location = new System.Drawing.Point(629, 1);
            this.label173.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label173.Name = "label173";
            this.label173.Size = new System.Drawing.Size(94, 33);
            this.label173.TabIndex = 337;
            this.label173.Text = "拧紧结果";
            this.label173.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label174
            // 
            this.label174.BackColor = System.Drawing.Color.MistyRose;
            this.label174.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label174.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label174.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label174.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label174.Location = new System.Drawing.Point(521, 1);
            this.label174.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label174.Name = "label174";
            this.label174.Size = new System.Drawing.Size(107, 33);
            this.label174.TabIndex = 336;
            this.label174.Text = "耗时(ms)";
            this.label174.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label175
            // 
            this.label175.BackColor = System.Drawing.Color.MistyRose;
            this.label175.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label175.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label175.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label175.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label175.Location = new System.Drawing.Point(333, 1);
            this.label175.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label175.Name = "label175";
            this.label175.Size = new System.Drawing.Size(187, 33);
            this.label175.TabIndex = 335;
            this.label175.Text = "最大扭力(kgf.cm)";
            this.label175.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label176
            // 
            this.label176.BackColor = System.Drawing.Color.Gray;
            this.label176.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label176.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label176.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label176.ForeColor = System.Drawing.Color.LimeGreen;
            this.label176.Location = new System.Drawing.Point(174, 69);
            this.label176.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label176.Name = "label176";
            this.label176.Size = new System.Drawing.Size(59, 31);
            this.label176.TabIndex = 334;
            this.label176.Text = "2";
            this.label176.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label177
            // 
            this.label177.BackColor = System.Drawing.Color.Gray;
            this.label177.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label177.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label177.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label177.ForeColor = System.Drawing.Color.LimeGreen;
            this.label177.Location = new System.Drawing.Point(174, 37);
            this.label177.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label177.Name = "label177";
            this.label177.Size = new System.Drawing.Size(59, 29);
            this.label177.TabIndex = 329;
            this.label177.Text = "1";
            this.label177.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label178
            // 
            this.label178.BackColor = System.Drawing.Color.Gray;
            this.label178.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label178.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label178.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label178.ForeColor = System.Drawing.Color.LimeGreen;
            this.label178.Location = new System.Drawing.Point(0, 69);
            this.label178.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label178.Name = "label178";
            this.label178.Size = new System.Drawing.Size(173, 31);
            this.label178.TabIndex = 328;
            this.label178.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label179
            // 
            this.label179.BackColor = System.Drawing.Color.Gray;
            this.label179.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label179.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label179.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label179.ForeColor = System.Drawing.Color.LimeGreen;
            this.label179.Location = new System.Drawing.Point(0, 37);
            this.label179.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label179.Name = "label179";
            this.label179.Size = new System.Drawing.Size(173, 29);
            this.label179.TabIndex = 327;
            this.label179.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label180
            // 
            this.label180.BackColor = System.Drawing.Color.MistyRose;
            this.label180.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label180.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label180.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label180.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label180.Location = new System.Drawing.Point(234, 1);
            this.label180.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label180.Name = "label180";
            this.label180.Size = new System.Drawing.Size(98, 33);
            this.label180.TabIndex = 326;
            this.label180.Text = "圈数(r)";
            this.label180.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label181
            // 
            this.label181.BackColor = System.Drawing.Color.MistyRose;
            this.label181.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label181.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label181.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label181.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label181.Location = new System.Drawing.Point(174, 1);
            this.label181.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label181.Name = "label181";
            this.label181.Size = new System.Drawing.Size(59, 33);
            this.label181.TabIndex = 325;
            this.label181.Text = "编号";
            this.label181.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label182
            // 
            this.label182.BackColor = System.Drawing.Color.MistyRose;
            this.label182.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label182.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label182.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.label182.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label182.Location = new System.Drawing.Point(0, 1);
            this.label182.Margin = new System.Windows.Forms.Padding(0, 1, 1, 2);
            this.label182.Name = "label182";
            this.label182.Size = new System.Drawing.Size(173, 33);
            this.label182.TabIndex = 311;
            this.label182.Text = "产品码";
            this.label182.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // formsPlot1
            // 
            this.formsPlot1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tableLayoutPanel70.SetColumnSpan(this.formsPlot1, 2);
            this.formsPlot1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.formsPlot1.Location = new System.Drawing.Point(2, 164);
            this.formsPlot1.Margin = new System.Windows.Forms.Padding(2);
            this.formsPlot1.Name = "formsPlot1";
            this.formsPlot1.Size = new System.Drawing.Size(817, 140);
            this.formsPlot1.TabIndex = 98;
            // 
            // formsPlot2
            // 
            this.formsPlot2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tableLayoutPanel70.SetColumnSpan(this.formsPlot2, 2);
            this.formsPlot2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.formsPlot2.Location = new System.Drawing.Point(2, 308);
            this.formsPlot2.Margin = new System.Windows.Forms.Padding(2);
            this.formsPlot2.Name = "formsPlot2";
            this.formsPlot2.Size = new System.Drawing.Size(817, 143);
            this.formsPlot2.TabIndex = 97;
            // 
            // label184
            // 
            this.label184.AutoSize = true;
            this.tableLayoutPanel70.SetColumnSpan(this.label184, 2);
            this.label184.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label184.Font = new System.Drawing.Font("宋体", 9F);
            this.label184.Location = new System.Drawing.Point(3, 144);
            this.label184.Name = "label184";
            this.label184.Size = new System.Drawing.Size(815, 18);
            this.label184.TabIndex = 99;
            this.label184.Text = "实时波形";
            this.label184.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox1.Location = new System.Drawing.Point(3, 7);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(261, 22);
            this.textBox1.TabIndex = 105;
            // 
            // button20
            // 
            this.button20.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button20.Font = new System.Drawing.Font("宋体", 9F);
            this.button20.Location = new System.Drawing.Point(270, 4);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(75, 28);
            this.button20.TabIndex = 106;
            this.button20.Text = "查询";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.ColumnCount = 8;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 1;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(937, 59);
            this.tableLayoutPanel15.TabIndex = 2;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label70.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label70.ForeColor = System.Drawing.Color.Red;
            this.label70.Location = new System.Drawing.Point(822, 0);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(112, 59);
            this.label70.TabIndex = 19;
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label69.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label69.Location = new System.Drawing.Point(705, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(111, 59);
            this.label69.TabIndex = 17;
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label68.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label68.Location = new System.Drawing.Point(3, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(111, 59);
            this.label68.TabIndex = 0;
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label67.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label67.ForeColor = System.Drawing.Color.Red;
            this.label67.Location = new System.Drawing.Point(120, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(111, 59);
            this.label67.TabIndex = 1;
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label66.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label66.Location = new System.Drawing.Point(237, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(111, 59);
            this.label66.TabIndex = 2;
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label65.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label65.ForeColor = System.Drawing.Color.Red;
            this.label65.Location = new System.Drawing.Point(354, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(111, 59);
            this.label65.TabIndex = 3;
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox4
            // 
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox4.Location = new System.Drawing.Point(3, 68);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(937, 421);
            this.groupBox4.TabIndex = 5;
            this.groupBox4.TabStop = false;
            // 
            // splitContainer4
            // 
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.IsSplitterFixed = true;
            this.splitContainer4.Location = new System.Drawing.Point(3, 19);
            this.splitContainer4.Name = "splitContainer4";
            this.splitContainer4.Size = new System.Drawing.Size(931, 399);
            this.splitContainer4.SplitterDistance = 560;
            this.splitContainer4.TabIndex = 1;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox1.Location = new System.Drawing.Point(0, 0);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(367, 399);
            this.richTextBox1.TabIndex = 2;
            this.richTextBox1.Text = "";
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 3;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.30282F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.49296F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38F));
            this.tableLayoutPanel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel14.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel14.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 12;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(560, 399);
            this.tableLayoutPanel14.TabIndex = 1;
            // 
            // textBox60
            // 
            this.textBox60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox60.Location = new System.Drawing.Point(122, 36);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(221, 21);
            this.textBox60.TabIndex = 168;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.Transparent;
            this.label43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label43.Location = new System.Drawing.Point(349, 363);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(208, 36);
            this.label43.TabIndex = 188;
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.Transparent;
            this.label41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label41.Location = new System.Drawing.Point(122, 363);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(221, 36);
            this.label41.TabIndex = 187;
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox59
            // 
            this.textBox59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox59.Location = new System.Drawing.Point(122, 333);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(221, 21);
            this.textBox59.TabIndex = 186;
            // 
            // textBox58
            // 
            this.textBox58.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox58.Location = new System.Drawing.Point(349, 300);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(208, 21);
            this.textBox58.TabIndex = 185;
            // 
            // textBox57
            // 
            this.textBox57.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox57.Location = new System.Drawing.Point(122, 300);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(221, 21);
            this.textBox57.TabIndex = 184;
            // 
            // textBox56
            // 
            this.textBox56.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox56.Location = new System.Drawing.Point(349, 267);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(208, 21);
            this.textBox56.TabIndex = 183;
            // 
            // textBox55
            // 
            this.textBox55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox55.Location = new System.Drawing.Point(122, 267);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(221, 21);
            this.textBox55.TabIndex = 182;
            // 
            // textBox54
            // 
            this.textBox54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox54.Location = new System.Drawing.Point(349, 234);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(208, 21);
            this.textBox54.TabIndex = 181;
            // 
            // textBox53
            // 
            this.textBox53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox53.Location = new System.Drawing.Point(122, 234);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(221, 21);
            this.textBox53.TabIndex = 180;
            // 
            // textBox52
            // 
            this.textBox52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox52.Location = new System.Drawing.Point(349, 201);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(208, 21);
            this.textBox52.TabIndex = 179;
            // 
            // textBox51
            // 
            this.textBox51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox51.Location = new System.Drawing.Point(122, 201);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(221, 21);
            this.textBox51.TabIndex = 178;
            // 
            // textBox50
            // 
            this.textBox50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox50.Location = new System.Drawing.Point(349, 168);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(208, 21);
            this.textBox50.TabIndex = 177;
            // 
            // textBox49
            // 
            this.textBox49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox49.Location = new System.Drawing.Point(122, 168);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(221, 21);
            this.textBox49.TabIndex = 176;
            // 
            // textBox48
            // 
            this.textBox48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox48.Location = new System.Drawing.Point(349, 135);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(208, 21);
            this.textBox48.TabIndex = 175;
            // 
            // textBox47
            // 
            this.textBox47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox47.Location = new System.Drawing.Point(122, 135);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(221, 21);
            this.textBox47.TabIndex = 174;
            // 
            // textBox46
            // 
            this.textBox46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox46.Location = new System.Drawing.Point(349, 102);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(208, 21);
            this.textBox46.TabIndex = 173;
            // 
            // textBox45
            // 
            this.textBox45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox45.Location = new System.Drawing.Point(122, 102);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(221, 21);
            this.textBox45.TabIndex = 172;
            // 
            // textBox44
            // 
            this.textBox44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox44.Location = new System.Drawing.Point(349, 69);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(208, 21);
            this.textBox44.TabIndex = 171;
            // 
            // textBox43
            // 
            this.textBox43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox43.Location = new System.Drawing.Point(122, 69);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(221, 21);
            this.textBox43.TabIndex = 170;
            // 
            // textBox42
            // 
            this.textBox42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox42.Location = new System.Drawing.Point(349, 36);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(208, 21);
            this.textBox42.TabIndex = 169;
            // 
            // textBox41
            // 
            this.textBox41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox41.Location = new System.Drawing.Point(349, 333);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(208, 21);
            this.textBox41.TabIndex = 167;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label40.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label40.Location = new System.Drawing.Point(3, 330);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(113, 33);
            this.label40.TabIndex = 166;
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label39.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label39.Location = new System.Drawing.Point(3, 297);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(113, 33);
            this.label39.TabIndex = 165;
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label38.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label38.Location = new System.Drawing.Point(3, 264);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(113, 33);
            this.label38.TabIndex = 164;
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label37.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label37.Location = new System.Drawing.Point(3, 231);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(113, 33);
            this.label37.TabIndex = 163;
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label36.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label36.Location = new System.Drawing.Point(3, 198);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(113, 33);
            this.label36.TabIndex = 162;
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label35.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label35.Location = new System.Drawing.Point(3, 165);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(113, 33);
            this.label35.TabIndex = 161;
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label34.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label34.Location = new System.Drawing.Point(3, 132);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(113, 33);
            this.label34.TabIndex = 160;
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label33.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label33.Location = new System.Drawing.Point(3, 99);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(113, 33);
            this.label33.TabIndex = 159;
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label32.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label32.Location = new System.Drawing.Point(3, 66);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(113, 33);
            this.label32.TabIndex = 158;
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label31.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label31.Location = new System.Drawing.Point(3, 33);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(113, 33);
            this.label31.TabIndex = 157;
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label30.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label30.Location = new System.Drawing.Point(122, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(221, 33);
            this.label30.TabIndex = 155;
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label29.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label29.Location = new System.Drawing.Point(349, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(208, 33);
            this.label29.TabIndex = 156;
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // HomeFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(969, 500);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "HomeFrm";
            this.Text = "HomeFrm";
            this.Load += new System.EventHandler(this.HomeFrm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tableLayoutPanel26.ResumeLayout(false);
            this.tableLayoutPanel27.ResumeLayout(false);
            this.tableLayoutPanel28.ResumeLayout(false);
            this.tableLayoutPanel29.ResumeLayout(false);
            this.tableLayoutPanel29.PerformLayout();
            this.tableLayoutPanel30.ResumeLayout(false);
            this.tableLayoutPanel31.ResumeLayout(false);
            this.tableLayoutPanel31.PerformLayout();
            this.tableLayoutPanel32.ResumeLayout(false);
            this.tableLayoutPanel32.PerformLayout();
            this.tableLayoutPanel33.ResumeLayout(false);
            this.tableLayoutPanel33.PerformLayout();
            this.tableLayoutPanel34.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.tableLayoutPanel49.ResumeLayout(false);
            this.tableLayoutPanel49.PerformLayout();
            this.tableLayoutPanel50.ResumeLayout(false);
            this.tableLayoutPanel50.PerformLayout();
            this.tableLayoutPanel51.ResumeLayout(false);
            this.tableLayoutPanel51.PerformLayout();
            this.tableLayoutPanel52.ResumeLayout(false);
            this.tableLayoutPanel52.PerformLayout();
            this.tableLayoutPanel53.ResumeLayout(false);
            this.tableLayoutPanel53.PerformLayout();
            this.tableLayoutPanel54.ResumeLayout(false);
            this.tableLayoutPanel54.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.tableLayoutPanel43.ResumeLayout(false);
            this.tableLayoutPanel43.PerformLayout();
            this.tableLayoutPanel44.ResumeLayout(false);
            this.tableLayoutPanel44.PerformLayout();
            this.tableLayoutPanel45.ResumeLayout(false);
            this.tableLayoutPanel45.PerformLayout();
            this.tableLayoutPanel46.ResumeLayout(false);
            this.tableLayoutPanel46.PerformLayout();
            this.tableLayoutPanel47.ResumeLayout(false);
            this.tableLayoutPanel47.PerformLayout();
            this.tableLayoutPanel48.ResumeLayout(false);
            this.tableLayoutPanel48.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.tableLayoutPanel37.ResumeLayout(false);
            this.tableLayoutPanel37.PerformLayout();
            this.tableLayoutPanel38.ResumeLayout(false);
            this.tableLayoutPanel38.PerformLayout();
            this.tableLayoutPanel39.ResumeLayout(false);
            this.tableLayoutPanel39.PerformLayout();
            this.tableLayoutPanel40.ResumeLayout(false);
            this.tableLayoutPanel40.PerformLayout();
            this.tableLayoutPanel41.ResumeLayout(false);
            this.tableLayoutPanel41.PerformLayout();
            this.tableLayoutPanel42.ResumeLayout(false);
            this.tableLayoutPanel42.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel35.ResumeLayout(false);
            this.tableLayoutPanel35.PerformLayout();
            this.tableLayoutPanel36.ResumeLayout(false);
            this.tableLayoutPanel36.PerformLayout();
            this.tableLayoutPanel55.ResumeLayout(false);
            this.tableLayoutPanel55.PerformLayout();
            this.tableLayoutPanel56.ResumeLayout(false);
            this.tableLayoutPanel56.PerformLayout();
            this.tableLayoutPanel57.ResumeLayout(false);
            this.tableLayoutPanel57.PerformLayout();
            this.tableLayoutPanel58.ResumeLayout(false);
            this.tableLayoutPanel58.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage10.ResumeLayout(false);
            this.tableLayoutPanel13.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.splitContainer7.Panel1.ResumeLayout(false);
            this.splitContainer7.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).EndInit();
            this.splitContainer7.ResumeLayout(false);
            this.tableLayoutPanel23.ResumeLayout(false);
            this.tableLayoutPanel23.PerformLayout();
            this.tableLayoutPanel24.ResumeLayout(false);
            this.tableLayoutPanel24.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage8.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel11.PerformLayout();
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel12.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel25.ResumeLayout(false);
            this.tableLayoutPanel25.PerformLayout();
            this.tabPage11.ResumeLayout(false);
            this.tableLayoutPanel16.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.splitContainer5.Panel1.ResumeLayout(false);
            this.splitContainer5.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).EndInit();
            this.splitContainer5.ResumeLayout(false);
            this.tableLayoutPanel17.ResumeLayout(false);
            this.groupBox31.ResumeLayout(false);
            this.tableLayoutPanel19.ResumeLayout(false);
            this.tableLayoutPanel19.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel18.ResumeLayout(false);
            this.tableLayoutPanel18.PerformLayout();
            this.tabPage12.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tableLayoutPanel20.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.tableLayoutPanel21.ResumeLayout(false);
            this.tableLayoutPanel21.PerformLayout();
            this.tableLayoutPanel22.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.tableLayoutPanel59.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.tableLayoutPanel60.ResumeLayout(false);
            this.tableLayoutPanel61.ResumeLayout(false);
            this.tableLayoutPanel61.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid_AllFixture)).EndInit();
            this.tabPage13.ResumeLayout(false);
            this.tableLayoutPanel62.ResumeLayout(false);
            this.tableLayoutPanel63.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            this.tableLayoutPanel64.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grid_TossingFixture)).EndInit();
            this.tableLayoutPanel65.ResumeLayout(false);
            this.tableLayoutPanel65.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox17.ResumeLayout(false);
            this.tableLayoutPanel66.ResumeLayout(false);
            this.tableLayoutPanel67.ResumeLayout(false);
            this.tableLayoutPanel67.PerformLayout();
            this.tabPage14.ResumeLayout(false);
            this.tabControl4.ResumeLayout(false);
            this.tabPage15.ResumeLayout(false);
            this.tableLayoutPanel68.ResumeLayout(false);
            this.tableLayoutPanel68.PerformLayout();
            this.tableLayoutPanel72.ResumeLayout(false);
            this.tableLayoutPanel69.ResumeLayout(false);
            this.tabPage16.ResumeLayout(false);
            this.tableLayoutPanel70.ResumeLayout(false);
            this.tableLayoutPanel70.PerformLayout();
            this.tableLayoutPanel71.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Label lb_TraceXYNG;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label lb_TraceXYOK;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label lb_TraceSendNG;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RichTextBox rtx_HeartBeatMsg;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RichTextBox rtx_DownTimeMsg;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.RichTextBox rtx_OEEDefaultMsg;
        private System.Windows.Forms.Label lb_OEE_LA_SendStatus;
        private System.Windows.Forms.Label lb_OEE_UA_SendStatus;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox txtOEE_ScanCount;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox txtOEE_sw;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox txtOEE_ActualCT;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox txtOEE_Status;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox txtOEE_EndTime;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox txtOEE_StartTime;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox txtOEE_Fixture;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox txtOEE_SerialNumber;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label lb_OEEOK;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label lb_OEENG;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label lb_OEESendNG;
        private System.Windows.Forms.RichTextBox rtx_TraceMsg;
        private System.Windows.Forms.TextBox txt_Trace_band_xy;
        private System.Windows.Forms.Label lb_Trace_LA_SendStatus;
        private System.Windows.Forms.Label lb_Trace_XY_SendStatus;
        private System.Windows.Forms.TextBox txt_Trace_actual_weld_ct_ua;
        private System.Windows.Forms.TextBox txt_Trace_weld_wait_ct_la;
        private System.Windows.Forms.TextBox txt_Trace_assy_ct_xy;
        private System.Windows.Forms.TextBox txt_Trace_uut_stop_la;
        private System.Windows.Forms.TextBox txt_Trace_uut_stop_xy;
        private System.Windows.Forms.TextBox txt_Trace_weld_stop_time_la;
        private System.Windows.Forms.TextBox txt_Trace_assy_stop_time_xy;
        private System.Windows.Forms.TextBox txt_Trace_weld_start_time_la;
        private System.Windows.Forms.TextBox txt_Trace_assy_start_time_xy;
        private System.Windows.Forms.TextBox txt_Trace_uut_start_la;
        private System.Windows.Forms.TextBox txt_Trace_uut_start_zy;
        private System.Windows.Forms.TextBox txt_Trace_fixture_id_la;
        private System.Windows.Forms.TextBox txt_Trace_fixture_id_xy;
        private System.Windows.Forms.TextBox txt_Trace_unit_serial_number_la;
        private System.Windows.Forms.TextBox txt_Trace_unit_serial_number_xy;
        private System.Windows.Forms.TextBox txt_Trace_test_result_la;
        private System.Windows.Forms.TextBox txt_Trace_test_result_xy;
        private System.Windows.Forms.TextBox txt_Trace_sp_la;
        private System.Windows.Forms.TextBox txt_Trace_actual_weld_ct_la;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel16;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.SplitContainer splitContainer5;
        private System.Windows.Forms.RichTextBox rtx_ProcessControl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private System.Windows.Forms.Label lb_ProcessControlNG;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label lb_ProcessControlOK;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.GroupBox groupBox31;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel19;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.TextBox txt_ProcessControl_SN;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel17;
        private System.Windows.Forms.RichTextBox rtx_ProcessControlErrorMsg;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.SplitContainer splitContainer7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel23;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.TextBox txt_PDCA_actual_weld_ct_la;
        private System.Windows.Forms.TextBox txt_PDCA_sp_la;
        private System.Windows.Forms.TextBox txt_PDCA_test_result_ua;
        private System.Windows.Forms.TextBox txt_PDCA_test_result_la;
        private System.Windows.Forms.TextBox txt_PDCA_unit_serial_number_ua;
        private System.Windows.Forms.TextBox txt_PDCA_unit_serial_number_la;
        private System.Windows.Forms.TextBox txt_PDCA_fixture_id_ua;
        private System.Windows.Forms.TextBox txt_PDCA_fixture_id_la;
        private System.Windows.Forms.TextBox txt_PDCA_uut_start_ua;
        private System.Windows.Forms.TextBox txt_PDCA_uut_start_la;
        private System.Windows.Forms.TextBox txt_PDCA_weld_start_time_ua;
        private System.Windows.Forms.TextBox txt_PDCA_weld_start_time_la;
        private System.Windows.Forms.TextBox txt_PDCA_weld_stop_time_ua;
        private System.Windows.Forms.TextBox txt_PDCA_weld_stop_time_la;
        private System.Windows.Forms.TextBox txt_PDCA_uut_stop_ua;
        private System.Windows.Forms.TextBox txt_PDCA_uut_stop_la;
        private System.Windows.Forms.TextBox txt_PDCA_weld_wait_ct_ua;
        private System.Windows.Forms.TextBox txt_PDCA_weld_wait_ct_la;
        private System.Windows.Forms.TextBox txt_PDCA_actual_weld_ct_ua;
        private System.Windows.Forms.Label lb_PDCA_UA_SendStatus;
        private System.Windows.Forms.Label lb_PDCA_LA_SendStatus;
        private System.Windows.Forms.TextBox txt_PDCA_sp_ua;
        private System.Windows.Forms.RichTextBox rtx_PDCAMsg;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel24;
        private System.Windows.Forms.Label lb_PDCAUANG;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label lb_PDCAUAOK;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label lb_PDCASendNG;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.Label lb_TraceLANG;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lb_TraceLAOK;
        private System.Windows.Forms.Label lb_PDCALANG;
        private System.Windows.Forms.Label lb_PDCALAOK;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label lb_OEELANG;
        private System.Windows.Forms.Label lb_OEELAOK;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label Paoliaolv;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label Paoliaoshu;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label Lianglv;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label NGCount;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label TotalCount;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label CT;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label txt_ProcessControl_Status;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.RichTextBox rtx_OEEMateriel;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label lb_Materiel_AllOK;
        private System.Windows.Forms.Label lb_Materiel_Nut;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label lb_Materiel_Total;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label lb_Materiel_AllNut;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label lb_Materiel_OK;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel25;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox OEE_index;
        private System.Windows.Forms.Label OEE_labal;
        private System.Windows.Forms.Button OEE_upload;
        private System.Windows.Forms.RichTextBox rtx_OEEMsg;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel26;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel27;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel28;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel29;
        private System.Windows.Forms.TextBox txt_Count;
        private System.Windows.Forms.TextBox txt_NGcount;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txt_lianglv;
        private System.Windows.Forms.TextBox txt_paoliao;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.TextBox txt_CT;
        private System.Windows.Forms.TextBox txt_paoliaolv;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel30;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel31;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel32;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel33;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel34;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel49;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel50;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel51;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel52;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel53;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel54;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel43;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel44;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel45;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel46;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel47;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel48;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel37;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel38;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel39;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel40;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel41;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel42;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel35;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel36;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel55;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel56;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel57;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel58;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel20;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel21;
        private System.Windows.Forms.ComboBox CB_Station;
        private System.Windows.Forms.ComboBox CB_project;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.ComboBox CB_Type;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel22;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.ListBox list_IQCFixture;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel59;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.ListBox list_IQCFixtureNG;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.ListBox list_FixtureMsgNG;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel62;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel63;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel64;
        private System.Windows.Forms.DataGridView grid_TossingFixture;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel65;
        private System.Windows.Forms.ComboBox txt_Fixture_CountNG;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Button btn_Setting_Limit;
        private System.Windows.Forms.ComboBox txt_Fixture_ContinuationNG;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Button btn_Outputfixture;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel66;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel67;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.TextBox txt_SelectFixture;
        private System.Windows.Forms.DateTimePicker dtp_SelectFixture;
        private System.Windows.Forms.Button btn_SelectFixture;
        private System.Windows.Forms.ListBox list_FixtureNG;
        private System.Windows.Forms.Button OEE_uploadAll;
        private System.Windows.Forms.ListBox list_FixtureMsg;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel60;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel61;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.TextBox txt_Fixture_Mantain_Count;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.TextBox txt_Fixture_Mantain_Time;
        private System.Windows.Forms.Button btn_Fixture_Clear;
        private System.Windows.Forms.Button btn_Fixture_Add;
        private System.Windows.Forms.Button btn_Fixture_Delete;
        private System.Windows.Forms.Button btn_Fixture_Out;
        private System.Windows.Forms.DataGridView grid_AllFixture;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.TabPage tabPage16;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel68;
        private System.Windows.Forms.RichTextBox dplusRTB;
        public ScottPlot.FormsPlot scottRealWaveR;
        public ScottPlot.FormsPlot scottRealWaveL;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel69;
        private System.Windows.Forms.Label label165;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.Label label164;
        private System.Windows.Forms.Label label158;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.Label label148;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label161;
        private System.Windows.Forms.Label label162;
        private System.Windows.Forms.Label label163;
        private System.Windows.Forms.Label label159;
        public System.Windows.Forms.Label label156;
        private System.Windows.Forms.Label label95;
        public System.Windows.Forms.Label label144;
        private System.Windows.Forms.Label label151;
        public System.Windows.Forms.Label label154;
        public System.Windows.Forms.Label label145;
        public System.Windows.Forms.Label label146;
        public System.Windows.Forms.Label label153;
        public System.Windows.Forms.Label label143;
        public System.Windows.Forms.Label label155;
        private System.Windows.Forms.Label label167;
        private System.Windows.Forms.Label label166;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel70;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel71;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.Label label150;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.Label label157;
        private System.Windows.Forms.Label label160;
        private System.Windows.Forms.Label label168;
        private System.Windows.Forms.Label label169;
        private System.Windows.Forms.Label label170;
        private System.Windows.Forms.Label label171;
        private System.Windows.Forms.Label label172;
        private System.Windows.Forms.Label label173;
        private System.Windows.Forms.Label label174;
        private System.Windows.Forms.Label label175;
        private System.Windows.Forms.Label label176;
        private System.Windows.Forms.Label label177;
        private System.Windows.Forms.Label label178;
        private System.Windows.Forms.Label label179;
        private System.Windows.Forms.Label label180;
        private System.Windows.Forms.Label label181;
        private System.Windows.Forms.Label label182;
        public ScottPlot.FormsPlot formsPlot1;
        public ScottPlot.FormsPlot formsPlot2;
        private System.Windows.Forms.Label label184;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel72;
        private System.Windows.Forms.Label label183;
        private System.Windows.Forms.Label label185;
        private System.Windows.Forms.Label label186;
        public System.Windows.Forms.Label label187;
        private System.Windows.Forms.Label label188;
        private System.Windows.Forms.Label label190;
        private System.Windows.Forms.Label label192;
        public System.Windows.Forms.Label label193;
        private System.Windows.Forms.Label label195;
        private System.Windows.Forms.Label label196;
        private System.Windows.Forms.Label label197;
        private System.Windows.Forms.Label label198;
        private System.Windows.Forms.Label label199;
        private System.Windows.Forms.Label label202;
        private System.Windows.Forms.Label label203;
    }
}