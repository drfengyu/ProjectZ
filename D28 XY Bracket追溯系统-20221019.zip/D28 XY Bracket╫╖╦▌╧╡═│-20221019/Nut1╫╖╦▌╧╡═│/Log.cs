﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;

namespace 卓汇数据追溯系统
{
    public class Log
    {
        private static string logPath = string.Empty;
        private static string logPath2 = @"D:\\ZHH\\操作记录\\";
        private static object _lock = new object();

        public static string LogPath
        {
            get
            {
                if (logPath == string.Empty)
                {
                    logPath = @"D:\\ZHH\\日志文件\\";
                }
                return logPath;
            }
            set { Log.logPath = value; }
        }

        public static void WriteLog(string text, string fileName)
        {
            System.IO.StreamWriter sw = null;
            if (!Directory.Exists(LogPath))
            {
                Directory.CreateDirectory(LogPath);
            }
            if (!Directory.Exists(logPath2 + fileName + "\\"))
            {
                Directory.CreateDirectory(logPath2 + fileName + "\\");
            }
            string fileFullFileName = LogPath + DateTime.Now.ToString("yyyyMMdd") + ".Log";
            string fileFullFileName2 = logPath2 + fileName + "\\" + DateTime.Now.ToString("yyyyMMdd") + ".csv";
            if (!File.Exists(fileFullFileName2))
            {
                using (sw = new StreamWriter(fileFullFileName2, true, Encoding.Default))
                {
                    string str = "Time,Data";
                    sw.WriteLine(str);
                }
            }
            lock (_lock)
            {
                try
                {
                    using (sw = new StreamWriter(fileFullFileName, true, Encoding.Default))
                    {
                        sw.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ": " + text);
                    }
                    using (sw = new StreamWriter(fileFullFileName2, true, Encoding.Default))
                    {
                        sw.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") +","+ text.Replace(",","|").Replace("\r\n", "").Replace("\n", "").Replace("\r", ""));
                    }
                    sw.Close();
                    sw.Dispose();
                }
                catch
                {}
            }
        }

        public static void WriteOEELog(string text)
        {
            System.IO.StreamWriter sw = null;
            if (!Directory.Exists(LogPath))
            {
                Directory.CreateDirectory(LogPath);
            }
            if (!Directory.Exists(LogPath + "\\OEE - Demo" + "\\"))
            {
                Directory.CreateDirectory(LogPath + "\\OEE - Demo" + "\\");
            }
            string fileFullFileName = LogPath + "\\OEE - Demo" + "\\" + DateTime.Now.ToString("yyyyMMdd") + ".Log";
            //string fileFullFileName = LogPath + "OEE-Demo" + ".Log";
            lock (_lock)
            {
                try
                {
                    using (sw = new StreamWriter(fileFullFileName, true, Encoding.Default))
                    {
                        sw.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss: ") + text);
                    }

                    sw.Close();
                    sw.Dispose();
                }
                catch
                {

                }
            }
        }

        public static void WriteCSV(string text, string LogPath1)
        {
            System.IO.StreamWriter sw = null;
            if (!Directory.Exists(LogPath1))
            {
                Directory.CreateDirectory(LogPath1);
            }
            string fileFullFileName = LogPath1 + DateTime.Now.ToString("yyyyMMdd") + ".csv";
            if (!File.Exists(fileFullFileName))
            {
                using (sw = new StreamWriter(fileFullFileName, true, Encoding.Default))
                {
                    string str = "Time,Procuct,full_sn,Fixture_id,Start_Time,Weld_start_time,Weld_stop_time,Stop_time,Weld_wait_ct,Actual_weld_ct, power_ll, power_ul, pattern_type, frequency, linear_speed, spot_size, pulse_energy,power, filling_pattern, hatch,status,Result";
                    if (LogPath1.Contains("System_ini"))
                    {
                        str = "记录时间,异常代码,触发时间,模组代码,上传状态,运行状态,故障描述,时长";
                    }
                    if (LogPath1.Contains("OEE_抛料日志数据"))
                    {
                        str = "记录时间,SN,SystemType,uptime,JSONBody,Error,Frenquency,上传状态";
                    }
                      if (LogPath1.Contains("OEE_小料抛料计数数据"))
                    {
                        str = "时间,合计抛料数量,总共抛料数量,UA抛料数量,LA抛料数量,上传状态";
                    }
                    if (LogPath1.Contains("UpLoad_HeartBeat"))
                    {
                        str = "记录时间,故障状态,故障代码,故障信息,上传状态";
                    }
                    if (LogPath1.Contains("OEE_Default"))
                    {
                        str = "Time,Procuct,full_sn,Fixture_id,Start_Time,EndTime,Status,ActualCT,SwVersion,DefectCode,SendStatus";
                    }
                    if (LogPath1.Contains("日志文件"))
                    {
                        str = "Time,SystemInfo";
                    }
                    if (LogPath1.Contains("备件更换记录"))
                    {
                        str = "类别,品名,规格,标准寿命,实际使用次数,上次更换时间,当前时间,更换原因,处理生技";
                    }
                    if (LogPath1.Contains("OEE_demo"))
                    {
                        str = "记录时间,URL路径,Data";
                    }
                    if (LogPath1.Contains("产品出流道记录"))
                    {
                        str = "记录时间,产品SP码,流道,治具码";
                    }
                    if (LogPath1.Contains("产品各工站CT记录"))
                    {
                        str = "记录时间,CT,名称";
                    }
                    if (LogPath1.Contains("IFactory前站校验"))
                    {
                        str = "记录时间,SN,返回结果,异常信息";
                    }
                    if (LogPath1.Contains("JGP上传次数校验"))
                    {
                        str = "记录时间,SN,返回结果,异常信息";
                    }
                    if (LogPath1.Contains("参数修改记录"))
                    {
                        str = "用户名称,权限等级,修改时间,参数名称,原参数,现参数";
                    }
                    if (LogPath1.Contains("探高记录"))
                    {
                        str = "探测时间,治具号,治具ID,焊机ID,焊位ID,探高检测值1,探高1结果,探高检测值2,探高2结果,判定结果";
                    }
                    if (LogPath1.Contains("焊接记录"))
                    {
                        str = "时间,治具号,治具ID,焊机ID,焊位ID,治具状态字,开始时间,结束时间,探高公差,探测标准值1,探测实际值1,探高1结果,探测标准值2,探测实际值2,探高2结果,探高总结果,焊点1结果,焊点2结果,焊点3结果,焊点4结果,焊点5结果,焊点6结果,焊点7结果,焊点8结果,焊点9结果,焊点10结果,焊接总结果";
                    }
                    if (LogPath1.Contains("PLC上传记录"))
                    {
                        str = "时间,产品码,进站时间,出站时间,组装开始时间,组装结束时间,预检结果,1#电批锁螺丝结果,2#电批锁螺丝结果,复检结果,运送位,CT";
                    }
                    if (LogPath1.Contains("电批数据记录"))
                    {
                        str = "时间,产品码,1#电批圈数,目标扭力,最大扭力值,拧紧时间,拧紧速度,1#电批锁螺丝结果,2#电批圈数,目标扭力,最大扭力值,拧紧时间,拧紧速度,2#电批锁螺丝结果";
                    }
                    if (LogPath1.Contains("抛料导出记录")) {
                        str = "时间,运送,电批,连续抛料次数,累计NG次数";
                    }
                    sw.WriteLine(str);
                }
            }
            lock (_lock)
            {
                try
                {
                    using (sw = new StreamWriter(fileFullFileName, true, Encoding.Default))
                    {
                        sw.WriteLine(text);
                    }
                    sw.Close();
                    sw.Dispose();
                }
                catch
                {
                    //foreach (Process process in System.Diagnostics.Process.GetProcesses())
                    //{
                    //    if (process.ProcessName.ToUpper().Equals("wps"))
                    //        process.Kill();    //杀进程
                    //}
                    //GC.Collect();
                    //Thread.Sleep(200);
                    //using (sw = System.IO.File.AppendText(fileFullFileName))
                    //{

                    //    sw.WriteLine(DateTime.Now.ToString("yyyy-MM-dd,HH:mm:ss:,") + text);

                    //}
                }
            }
        }

        public static void WriteCSV_NG(string text, string LogPath1)
        {
            System.IO.StreamWriter sw = null;
            if (!Directory.Exists(LogPath1))
            {
                Directory.CreateDirectory(LogPath1);
            }
            string fileFullFileName = LogPath1 + "sendNG.csv";
            if (!File.Exists(fileFullFileName))
            {
                using (sw = new StreamWriter(fileFullFileName, true, Encoding.Default))
                {
                    string str = "Time,Procuct,full_sn,Fixture_id,Start_Time,Weld_start_time,Weld_stop_time,Stop_Time,Weld_wait_ct,Actual_weld_ct,Status";
                    sw.WriteLine(str);
                }
            }
            lock (_lock)
            {
                try
                {
                    using (sw = new StreamWriter(fileFullFileName, true, Encoding.Default))
                    {
                        sw.WriteLine(text);
                    }
                    sw.Close();
                    sw.Dispose();
                }
                catch
                {
                }
            }
        }

        public static void WriteCSV_NUM(string text)
        {
            System.IO.StreamWriter sw = null;
            if (!Directory.Exists(System.AppDomain.CurrentDomain.BaseDirectory + "\\月产量数据统计\\"))
            {
                Directory.CreateDirectory(System.AppDomain.CurrentDomain.BaseDirectory + "\\月产量数据统计\\");
            }
            string filePath = System.AppDomain.CurrentDomain.BaseDirectory + "\\月产量数据统计\\" + DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString() + ".csv";
            if (!File.Exists(filePath))
            {
                using (sw = new StreamWriter(filePath, true, Encoding.Default))
                {
                    //string str = "Time,OK产品数量,NG产品数量,良率,稼动率";
                    string str = "Time,OK产品数量,NG产品数量";
                    sw.WriteLine(str);
                }
            }
            lock (_lock)
            {
                try
                {
                    using (sw = new StreamWriter(filePath, true, Encoding.Default))
                    {
                        sw.WriteLine(text);
                    }
                    sw.Close();
                    sw.Dispose();
                }
                catch
                {
                }
            }
        }
        public static void WriteCSV_PDCA(string text)
        {
            System.IO.StreamWriter sw = null;
            if (!Directory.Exists(System.AppDomain.CurrentDomain.BaseDirectory + "\\PDCA上传成功数据统计\\"))
            {
                Directory.CreateDirectory(System.AppDomain.CurrentDomain.BaseDirectory + "\\PDCA上传成功数据统计\\");
            }
            string filePath = System.AppDomain.CurrentDomain.BaseDirectory + "\\PDCA上传成功数据统计\\" + DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString() + ".csv";
            if (!File.Exists(filePath))
            {
                using (sw = new StreamWriter(filePath, true, Encoding.Default))
                {
                    //string str = "Time,OK数量,NG数量,良率,稼动率";
                    string str = "Time,UA数量,LA数量";
                    sw.WriteLine(str);
                }
            }
            lock (_lock)
            {
                try
                {
                    using (sw = new StreamWriter(filePath, true, Encoding.Default))
                    {
                        sw.WriteLine(text);
                    }
                    sw.Close();
                    sw.Dispose();
                }
                catch
                {
                }
            }
        }

        public static void WriteCSV_DiscardLog(string text)
        {
            System.IO.StreamWriter sw = null;
            if (!Directory.Exists(@"D:\装机软件\系统配置\OEE_抛料日志数据\" + DateTime.Now.ToString("yyyyMM")))
            {
                Directory.CreateDirectory(@"D:\装机软件\系统配置\OEE_抛料日志数据\" + DateTime.Now.ToString("yyyyMM"));
            }
            string filePath = @"D:\装机软件\系统配置\OEE_抛料日志数据\" + DateTime.Now.ToString("yyyyMM") + "\\" + DateTime.Now.ToString("yyyyMMdd") + ".csv";
            if (!File.Exists(filePath))
            {
                using (sw = new StreamWriter(filePath, true, Encoding.Default))
                {
                    //string str = "Time,OK数量,NG数量,良率,稼动率";
                    string str = "系统类型,上传时间,工站,机台号,SN,上传数据,报错信息,上传次数";
                    sw.WriteLine(str);
                }
            }
            lock (_lock)
            {
                try
                {
                    using (sw = new StreamWriter(filePath, true, Encoding.Default))
                    {
                        sw.WriteLine(text);
                    }
                    sw.Close();
                    sw.Dispose();
                }
                catch
                {
                }
            }
        }
    }
}
