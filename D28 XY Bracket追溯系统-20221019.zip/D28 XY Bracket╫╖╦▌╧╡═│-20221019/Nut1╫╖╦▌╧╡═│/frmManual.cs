﻿using EMD.Model;
using EMD.Trace.Common;
using EMD.Trace.Model;
using EMD.Trace.StaticModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using EMD.Oee.Models;
using EMD.Oee;
using EMD.DPlus.Models;
using EMD.ModbusTcp.Models;
using ScottPlot;
using ExcelUtility;

namespace EMD.Trace.NodeFrm
{
    public partial class frmManual : Form
    {


        private OeeMqttClient _oeeMqttClient = null;
        public string status = "2";
        private Plot _pltReal_L;
        private Plot _pltReal_R;
        private Plot _pltReal_1;
        private Plot _pltReal_2;
        private Plot _pltReal_3;
        EMD.Model.log logs = null;
        EMD.BLL.log gblog = new EMD.BLL.log();
        public frmManual()
        {
            InitializeComponent();
            _oeeMqttClient = OeeMqttClient.GetSingleton();
            Control.CheckForIllegalCrossThreadCalls = false;
            start_time_select.Value = DateTime.Now.Date.AddHours(6);
            end_time_select.Value = DateTime.Now.Date.AddHours(30);
            dataGridView1.AutoGenerateColumns = false;
            InitScottPlot();
        }

        private ShowRichTextBox _showRichTextBox;
        //public Index frm_index;
        public ShowRichTextBox showRtb
        {
            get => _showRichTextBox;
            set
            {
                _showRichTextBox = value;
                showRtb.dplusRTB = this.dplusRTB;
                showRtb.TraceSupRTB = this.richTextBox1;
            }
        }
        /// <summary>
        /// 显示电批数据
        /// </summary>
        /// <param name="dPlus"></param>
        public delegate void ShowRealDplusCallback(DPlusModel dPlus, ScrewModel screw);
        public void ShowRealDplus(DPlusModel dPlus, ScrewModel screw)
        {
            if (this.InvokeRequired)
            {
                ShowRealDplusCallback showRealDplusCallback = new ShowRealDplusCallback(ShowRealDplus);
                this.Invoke(showRealDplusCallback, dPlus, screw);
            }
            else
            {
                try
                {
                    if (dPlus != null)
                    {
                        if (screw.StationCode == StationCodeEnum.Left)
                        {
                            //警报
                            this.label36.Text = dPlus.AlarmCode.GetEnumDescription<DescriptionAttribute>().Description;
                            if (dPlus.AlarmCode != AlarmCodeEnum.None)
                                this.label36.ForeColor = Color.Red;
                            else
                                this.label36.ForeColor = Color.LimeGreen;
                            //编号
                            this.label59.Text = screw.No.ToString();
                            //产品码
                            this.label42.Text = screw.SerialNumber.ToString();
                            //圈数
                            this.label41.Text = (dPlus.RealCycles * 0.01).ToString();
                            //最大扭力
                            this.label40.Text = (dPlus.MaxTorque * 0.01).ToString();
                            //耗时
                            this.label39.Text = dPlus.TotalMSecTime.ToString();
                            //拧紧结果
                            this.label38.Text = dPlus.TightenStatus.GetEnumDescription<DescriptionAttribute>().Description;
                            if (dPlus.TightenStatus != TightenStatusEnum.OK)
                                this.label38.ForeColor = Color.Red;
                            else
                                this.label38.ForeColor = Color.LimeGreen;

                            string msg = $"{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")} 工位:{this.label37.Text.Trim()} 穴位:{screw.Acupoint} 螺丝编号:{this.label59.Text.Trim()} 产品码:{this.label42.Text.Trim()} 圈数(r):{this.label41.Text.Trim()} 最大扭力(kgf.cm):{this.label40.Text.Trim()} 耗时(ms):{this.label39.Text.Trim()} 拧紧结果:{this.label38.Text.Trim()} 警报:{this.label36.Text.Trim()}";
                            if (dPlus.AlarmCode != AlarmCodeEnum.None || dPlus.TightenStatus != TightenStatusEnum.OK)
                            {
                                showRtb.AppendTextBox4("Err:" + msg);
                            }
                            else
                            {
                                showRtb.AppendTextBox4("Suc:" + msg);
                            }

                            _pltReal_L.Clear();
                            _pltReal_L = new Plot();

                            var datas = dPlus.WaveDatas.ToArray();
                            if (datas != null && datas.Length > 0)
                            {
                                _pltReal_L = scottRealWaveL.Plot;
                                var title = $"左工位 螺丝-{screw.No}";
                                _pltReal_L.Title($"{title}", size: 12);
                                var vals = Array.ConvertAll(datas, x => Math.Round((double)x / 1000 * 10, 3));
                                var rate = 1 / ((double)dPlus.TotalMSecTime / (vals.Length - 1));
                                var signalPlot = _pltReal_L.AddSignal(vals, rate, color: Color.DodgerBlue, label: title);
                                signalPlot.LineWidth = 2;
                                var spaceX = Math.Ceiling(((double)dPlus.TotalMSecTime / 10));
                                _pltReal_L.XAxis.ManualTickSpacing(spaceX);
                                _pltReal_L.YAxis.ManualTickSpacing(0.2);
                                _pltReal_L.Margins(x: 0, y: 0);
                                _pltReal_L.SetAxisLimitsX(0, spaceX * 10);
                                _pltReal_L.SetAxisLimitsY(0, dPlus.MaxTorque * 0.01);
                            }


                            scottRealWaveL.Refresh();
                        }
                        else if (screw.StationCode == StationCodeEnum.Right)
                        {
                            //警报
                            this.label52.Text = dPlus.AlarmCode.GetEnumDescription<DescriptionAttribute>().Description;
                            if (dPlus.AlarmCode != AlarmCodeEnum.None)
                                this.label52.ForeColor = Color.Red;
                            else
                                this.label52.ForeColor = Color.LimeGreen;
                            //编号
                            this.label47.Text = screw.No.ToString();
                            //产品码
                            this.label60.Text = screw.SerialNumber.ToString();
                            //圈数
                            this.label57.Text = (dPlus.RealCycles * 0.01).ToString();
                            //最大扭力
                            this.label56.Text = (dPlus.MaxTorque * 0.01).ToString();
                            //耗时
                            this.label55.Text = dPlus.TotalMSecTime.ToString();
                            //拧紧结果
                            this.label54.Text = dPlus.TightenStatus.GetEnumDescription<DescriptionAttribute>().Description;
                            if (dPlus.TightenStatus != TightenStatusEnum.OK)
                                this.label54.ForeColor = Color.Red;
                            else
                                this.label54.ForeColor = Color.LimeGreen;
                            string msg = $"{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")} 工位:{this.label53.Text.Trim()} 穴位:{screw.Acupoint} 螺丝编号:{this.label47.Text.Trim()} 产品码 {this.label60.Text.Trim()} 圈数(r):{this.label57.Text.Trim()} 最大扭力(kgf.cm):{this.label56.Text.Trim()} 耗时(ms):{this.label55.Text.Trim()} 拧紧结果:{this.label54.Text.Trim()} 警报:{this.label52.Text.Trim()}";
                            if (dPlus.AlarmCode != AlarmCodeEnum.None || dPlus.TightenStatus != TightenStatusEnum.OK)
                            {
                                showRtb.AppendTextBox4("Err:" + msg);
                            }
                            else
                            {
                                showRtb.AppendTextBox4("Suc:" + msg);
                            }

                            _pltReal_R.Clear();
                            _pltReal_R = new Plot();
                            var datas = dPlus.WaveDatas.ToArray();
                            if (datas != null && datas.Length > 0)
                            {
                                _pltReal_R = scottRealWaveR.Plot;

                                var title = $"右工位 螺丝-{screw.No}";
                                _pltReal_R.Title($"{title}", size: 12);
                                var vals = Array.ConvertAll(datas, x => Math.Round((double)x / 1000 * 10, 3));
                                var rate = 1 / ((double)dPlus.TotalMSecTime / (vals.Length - 1));
                                var signalPlot = _pltReal_R.AddSignal(vals, rate, color: Color.DodgerBlue, label: title);
                                signalPlot.LineWidth = 2;
                                var spaceX = Math.Ceiling(((double)dPlus.TotalMSecTime / 10));
                                _pltReal_R.XAxis.ManualTickSpacing(spaceX);
                                _pltReal_R.YAxis.ManualTickSpacing(0.2);
                                _pltReal_R.Margins(x: 0, y: 0);
                                _pltReal_R.SetAxisLimitsX(0, spaceX * 10);
                                _pltReal_R.SetAxisLimitsY(0, dPlus.MaxTorque * 0.01);
                            }


                            scottRealWaveR.Refresh();
                        }
                    }
                    else
                    {
                        showRtb.AppendTextBox4($"Err:工位:{screw.StationCode.GetEnumDescription<DescriptionAttribute>().Description} 电批数据异常");
                    }
                }
                catch (Exception)
                {

                }
            }
        }

        private void ManualLeftMenu_Click(object sender, EventArgs e)
        {
            Button btnLeftMenu = (Button)sender;
            switch (btnLeftMenu.Name.Trim())
            {
                case "btnInManual":
                    stcManual.SelectedTab = stiInManual;
                    break;
                case "btnOutManual":
                    stcManual.SelectedTab = stiOutManual;
                    break;
                case "btnMoveManual":
                    stcManual.SelectedTab = stiMoveManual;
                    break;
                case "btnTraceManual":
                    stcManual.SelectedTab = stiTraceManual;
                    break;
                case "btnPDCManual":
                    stcManual.SelectedTab = stiPDCManual;
                    break;
                case "btnOEEManual":
                    {
                        stcManual.SelectedTab = stiOEEManual;
                        setCombox1Data();
                        if (StaticSettingsCommunication.MachineNo != "2")
                        {
                            button1.Enabled = false;
                            button2.Enabled = false;
                            button3.Enabled = false;
                            button4.Enabled = false;
                            button5.Enabled = false;
                        }
                        if (StaticAlarmCode.Status != (int)OeeDownTimeStatusEnum.FAI)
                        {
                            button4.Enabled = true;
                        }
                        if (StaticAlarmCode.Status != (int)OeeDownTimeStatusEnum.Break)
                        {
                            button2.Enabled = true;
                        }
                    }
                    break;
                case "btnCCDManual":
                    stcManual.SelectedTab = stiCCDManual;
                    break;
                case "btnDPlusManual":
                    stcManual.SelectedTab = stiDPlusManual;
                    break;
                default:
                    stcManual.SelectedTab = stiTraceManual;
                    break;
            }
            UpdateLeftMenuBgColor(btnLeftMenu);
        }

        private void UpdateLeftMenuBgColor(Button btn)
        {
            Panel pan = (Panel)btn.Parent;
            foreach (var item in pan.Controls)
            {
                if (item.GetType().ToString().Contains("Button") && ((Button)item).Name.Trim() != btn.Name.Trim())
                {
                    ((Button)item).BackColor = Color.Silver;
                }
            }
            btn.BackColor = Color.FromArgb(173, 218, 151);
        }
        FileInfo[] arrFI = null;
        private void frmManual_Load(object sender, EventArgs e)
        {
            ManualLeftMenu_Click(btnTraceManual, null);
            GetNotPostDate();
        }

        private void InitScottPlot()
        {

            scottRealWaveL.Configuration.LockHorizontalAxis = true;
            scottRealWaveL.Configuration.LockVerticalAxis = true;

            scottRealWaveR.Configuration.LockHorizontalAxis = true;
            scottRealWaveR.Configuration.LockVerticalAxis = true;

            scottRealWave1.Configuration.LockHorizontalAxis = true;
            scottRealWave1.Configuration.LockVerticalAxis = true;

            scottRealWave2.Configuration.LockHorizontalAxis = true;
            scottRealWave2.Configuration.LockVerticalAxis = true;

            scottRealWave3.Configuration.LockHorizontalAxis = true;
            scottRealWave3.Configuration.LockVerticalAxis = true;

            _pltReal_L = scottRealWaveL.Plot;
            _pltReal_L.Style(Style.Gray2);
            _pltReal_L.Style(figureBackground: System.Drawing.SystemColors.ControlDarkDark);
            _pltReal_L.XAxis.Label("Time:ms", Color.LimeGreen, size: 12);
            _pltReal_L.YAxis.Label("扭力:kgf.cm", Color.LimeGreen, size: 12);
            _pltReal_L.XAxis.Color(Color.LimeGreen);
            _pltReal_L.YAxis.Color(Color.LimeGreen);
            _pltReal_L.XAxis.MajorGrid(lineStyle: LineStyle.Solid, lineWidth: 1, color: Color.FromArgb(100, Color.LimeGreen));
            _pltReal_L.XAxis.MinorGrid(lineStyle: LineStyle.Solid, lineWidth: 1, enable: true, color: Color.FromArgb(20, Color.LimeGreen));
            _pltReal_L.YAxis.MajorGrid(lineStyle: LineStyle.Solid, lineWidth: 1, color: Color.FromArgb(100, Color.LimeGreen));
            _pltReal_L.YAxis.MinorGrid(lineStyle: LineStyle.Solid, lineWidth: 1, enable: true, color: Color.FromArgb(20, Color.LimeGreen));

            _pltReal_R = scottRealWaveR.Plot;
            _pltReal_R.Style(Style.Gray2);
            _pltReal_R.Style(figureBackground: System.Drawing.SystemColors.ControlDarkDark);
            _pltReal_R.XAxis.Label("Time:ms", Color.LimeGreen, size: 12);
            _pltReal_R.YAxis.Label("扭力:kgf.cm", Color.LimeGreen, size: 12);
            _pltReal_R.XAxis.Color(Color.LimeGreen);
            _pltReal_R.YAxis.Color(Color.LimeGreen);
            _pltReal_R.XAxis.MajorGrid(lineStyle: LineStyle.Solid, lineWidth: 1, color: Color.FromArgb(100, Color.LimeGreen));
            _pltReal_R.XAxis.MinorGrid(lineStyle: LineStyle.Solid, lineWidth: 1, enable: true, color: Color.FromArgb(20, Color.LimeGreen));
            _pltReal_R.YAxis.MajorGrid(lineStyle: LineStyle.Solid, lineWidth: 1, color: Color.FromArgb(100, Color.LimeGreen));
            _pltReal_R.YAxis.MinorGrid(lineStyle: LineStyle.Solid, lineWidth: 1, enable: true, color: Color.FromArgb(20, Color.LimeGreen));

            _pltReal_1 = scottRealWave1.Plot;
            _pltReal_1.Style(Style.Gray2);
            _pltReal_1.Style(figureBackground: System.Drawing.SystemColors.ControlDarkDark);
            _pltReal_1.XAxis.Label("Time:ms", Color.LimeGreen, size: 12);
            _pltReal_1.YAxis.Label("扭力:kgf.cm", Color.LimeGreen, size: 12);
            _pltReal_1.XAxis.Color(Color.LimeGreen);
            _pltReal_1.YAxis.Color(Color.LimeGreen);
            _pltReal_1.XAxis.MajorGrid(lineStyle: LineStyle.Solid, lineWidth: 1, color: Color.FromArgb(100, Color.LimeGreen));
            _pltReal_1.XAxis.MinorGrid(lineStyle: LineStyle.Solid, lineWidth: 1, enable: true, color: Color.FromArgb(20, Color.LimeGreen));
            _pltReal_1.YAxis.MajorGrid(lineStyle: LineStyle.Solid, lineWidth: 1, color: Color.FromArgb(100, Color.LimeGreen));
            _pltReal_1.YAxis.MinorGrid(lineStyle: LineStyle.Solid, lineWidth: 1, enable: true, color: Color.FromArgb(20, Color.LimeGreen));

            _pltReal_2 = scottRealWave2.Plot;
            _pltReal_2.Style(Style.Gray2);
            _pltReal_2.Style(figureBackground: System.Drawing.SystemColors.ControlDarkDark);
            _pltReal_2.XAxis.Label("Time:ms", Color.LimeGreen, size: 12);
            _pltReal_2.YAxis.Label("扭力:kgf.cm", Color.LimeGreen, size: 12);
            _pltReal_2.XAxis.Color(Color.LimeGreen);
            _pltReal_2.YAxis.Color(Color.LimeGreen);
            _pltReal_2.XAxis.MajorGrid(lineStyle: LineStyle.Solid, lineWidth: 1, color: Color.FromArgb(100, Color.LimeGreen));
            _pltReal_2.XAxis.MinorGrid(lineStyle: LineStyle.Solid, lineWidth: 1, enable: true, color: Color.FromArgb(20, Color.LimeGreen));
            _pltReal_2.YAxis.MajorGrid(lineStyle: LineStyle.Solid, lineWidth: 1, color: Color.FromArgb(100, Color.LimeGreen));
            _pltReal_2.YAxis.MinorGrid(lineStyle: LineStyle.Solid, lineWidth: 1, enable: true, color: Color.FromArgb(20, Color.LimeGreen));

            _pltReal_3 = scottRealWave3.Plot;
            _pltReal_3.Style(Style.Gray2);
            _pltReal_3.Style(figureBackground: System.Drawing.SystemColors.ControlDarkDark);
            _pltReal_3.XAxis.Label("Time:ms", Color.LimeGreen, size: 12);
            _pltReal_3.YAxis.Label("扭力:kgf.cm", Color.LimeGreen, size: 12);
            _pltReal_3.XAxis.Color(Color.LimeGreen);
            _pltReal_3.YAxis.Color(Color.LimeGreen);
            _pltReal_3.XAxis.MajorGrid(lineStyle: LineStyle.Solid, lineWidth: 1, color: Color.FromArgb(100, Color.LimeGreen));
            _pltReal_3.XAxis.MinorGrid(lineStyle: LineStyle.Solid, lineWidth: 1, enable: true, color: Color.FromArgb(20, Color.LimeGreen));
            _pltReal_3.YAxis.MajorGrid(lineStyle: LineStyle.Solid, lineWidth: 1, color: Color.FromArgb(100, Color.LimeGreen));
            _pltReal_3.YAxis.MinorGrid(lineStyle: LineStyle.Solid, lineWidth: 1, enable: true, color: Color.FromArgb(20, Color.LimeGreen));
        }

        private void LoadWaveData(string bandSn)
        {
            EMD.BLL.screw_wave bllWave = new BLL.screw_wave();
            var lst = bllWave.GetModelList(bandSn, Convert.ToInt32(StaticSettingsCommunication.MachineNo));
            _pltReal_1.Clear();
            _pltReal_2.Clear();
            _pltReal_3.Clear();


            _pltReal_1 = new Plot();
            _pltReal_2 = new Plot();
            _pltReal_3 = new Plot();

            //警报
            this.lbAlarm1.Text = "无";
            this.lbAlarm1.ForeColor = Color.LimeGreen;
            //编号
            this.lbScrewNo1.Text = "0";
            //圈数
            this.lbCycles1.Text = "0.00";
            //最大扭力
            this.lbMaxTorque1.Text = "0.00";
            //耗时
            this.lbTotalMsecTime1.Text = "0";
            //拧紧结果
            this.lbTightenStatus1.Text = "未知";

            this.lbTightenStatus1.ForeColor = Color.Red;

            //警报
            this.lbAlarm2.Text = "无";
            this.lbAlarm2.ForeColor = Color.LimeGreen;
            //编号
            this.lbScrewNo2.Text = "0";
            //圈数
            this.lbCycles2.Text = "0.00";
            //最大扭力
            this.lbMaxTorque2.Text = "0.00";
            //耗时
            this.lbTotalMsecTime2.Text = "0";
            //拧紧结果
            this.lbTightenStatus2.Text = "未知";
            this.lbTightenStatus2.ForeColor = Color.Red;


            //警报
            this.lbAlarm3.Text = "无";

            this.lbAlarm3.ForeColor = Color.LimeGreen;
            //编号
            this.lbScrewNo3.Text = "0";
            //圈数
            this.lbCycles3.Text = "0.00";
            //最大扭力
            this.lbMaxTorque3.Text = "0.00";
            //耗时
            this.lbTotalMsecTime3.Text = "0";
            //拧紧结果
            this.lbTightenStatus3.Text = "未知";

            this.lbTightenStatus3.ForeColor = Color.Red;

            foreach (var item in lst)
            {
                if (item.Screw_no == 1)
                {
                    _pltReal_1 = scottRealWave1.Plot;
                    //var no = (item.Machine_no % 3) * 3 + item.Screw_no;
                    var title = $"螺丝-{item.Screw_no}";
                    _pltReal_1.Title($"{title}", size: 12);
                    var datas = item.Data.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
                    if (datas != null && datas.Length > 0)
                    {
                        var vals = Array.ConvertAll(datas, x => Math.Round((double)Convert.ToInt32(x) / 1000 * 10, 3));
                        var rate = 1 / ((double)item.Total_msec_time / (vals.Length - 1));
                        var signalPlot = _pltReal_1.AddSignal(vals, rate, color: Color.DodgerBlue, label: title);
                        signalPlot.LineWidth = 2;
                        var spaceX = Math.Ceiling(((double)item.Total_msec_time / 10));
                        _pltReal_1.XAxis.ManualTickSpacing(spaceX);
                        _pltReal_1.YAxis.ManualTickSpacing(0.2);
                        _pltReal_1.Margins(x: 0, y: 0);
                        _pltReal_1.SetAxisLimitsX(0, spaceX * 10);
                        _pltReal_1.SetAxisLimitsY(0, item.Max_torque);
                    }

                    //警报
                    this.lbAlarm1.Text = item.Alarm;
                    if (item.Alarm != "无")
                        this.lbAlarm1.ForeColor = Color.Red;
                    else
                        this.lbAlarm1.ForeColor = Color.LimeGreen;
                    //编号
                    this.lbScrewNo1.Text = item.Screw_no.ToString();
                    //圈数
                    this.lbCycles1.Text = item.Real_cycles.ToString();
                    //最大扭力
                    this.lbMaxTorque1.Text = item.Max_torque.ToString();
                    //耗时
                    this.lbTotalMsecTime1.Text = item.Total_msec_time.ToString();
                    //拧紧结果
                    this.lbTightenStatus1.Text = item.Tighten_status;
                    if (item.Tighten_status != "OK")
                        this.lbTightenStatus1.ForeColor = Color.Red;
                    else
                        this.lbTightenStatus1.ForeColor = Color.LimeGreen;

                }
                else if (item.Screw_no == 2)
                {
                    _pltReal_2 = scottRealWave2.Plot;
                    //var no = (item.Machine_no % 3) * 3 + item.Screw_no;
                    var title = $"螺丝-{item.Screw_no}";
                    _pltReal_2.Title($"{title}", size: 12);
                    var datas = item.Data.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
                    if (datas != null && datas.Length > 0)
                    {
                        var vals = Array.ConvertAll(datas, x => Math.Round((double)Convert.ToInt32(x) / 1000 * 10, 3));
                        var rate = 1 / ((double)item.Total_msec_time / (vals.Length - 1));
                        var signalPlot = _pltReal_2.AddSignal(vals, rate, color: Color.DodgerBlue, label: title);
                        signalPlot.LineWidth = 2;
                        var spaceX = Math.Ceiling(((double)item.Total_msec_time / 10));
                        _pltReal_2.XAxis.ManualTickSpacing(spaceX);
                        _pltReal_2.YAxis.ManualTickSpacing(0.2);
                        _pltReal_2.Margins(x: 0, y: 0);
                        _pltReal_2.SetAxisLimitsX(0, spaceX * 10);
                        _pltReal_2.SetAxisLimitsY(0, item.Max_torque);
                    }
                    //警报
                    this.lbAlarm2.Text = item.Alarm;
                    if (item.Alarm != "无")
                        this.lbAlarm2.ForeColor = Color.Red;
                    else
                        this.lbAlarm2.ForeColor = Color.LimeGreen;
                    //编号
                    this.lbScrewNo2.Text = item.Screw_no.ToString();
                    //圈数
                    this.lbCycles2.Text = item.Real_cycles.ToString();
                    //最大扭力
                    this.lbMaxTorque2.Text = item.Max_torque.ToString();
                    //耗时
                    this.lbTotalMsecTime2.Text = item.Total_msec_time.ToString();
                    //拧紧结果
                    this.lbTightenStatus2.Text = item.Tighten_status;
                    if (item.Tighten_status != "OK")
                        this.lbTightenStatus2.ForeColor = Color.Red;
                    else
                        this.lbTightenStatus2.ForeColor = Color.LimeGreen;
                }
                else if (item.Screw_no == 3)
                {
                    _pltReal_3 = scottRealWave3.Plot;
                    //var no = (item.Machine_no % 3) * 3 + item.Screw_no;
                    var title = $"螺丝-{item.Screw_no}";
                    _pltReal_3.Title($"{title}", size: 12);
                    var datas = item.Data.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
                    if (datas != null && datas.Length > 0)
                    {
                        var vals = Array.ConvertAll(datas, x => Math.Round((double)Convert.ToInt32(x) / 1000 * 10, 3));
                        var rate = 1 / ((double)item.Total_msec_time / (vals.Length - 1));
                        var signalPlot = _pltReal_3.AddSignal(vals, rate, color: Color.DodgerBlue, label: title);
                        signalPlot.LineWidth = 2;
                        var spaceX = Math.Ceiling(((double)item.Total_msec_time / 10));
                        _pltReal_3.XAxis.ManualTickSpacing(spaceX);
                        _pltReal_3.YAxis.ManualTickSpacing(0.2);
                        _pltReal_3.Margins(x: 0, y: 0);
                        _pltReal_3.SetAxisLimitsX(0, spaceX * 10);
                        _pltReal_3.SetAxisLimitsY(0, item.Max_torque);
                    }
                    //警报
                    this.lbAlarm3.Text = item.Alarm;
                    if (item.Alarm != "无")
                        this.lbAlarm3.ForeColor = Color.Red;
                    else
                        this.lbAlarm3.ForeColor = Color.LimeGreen;
                    //编号
                    this.lbScrewNo3.Text = item.Screw_no.ToString();
                    //圈数
                    this.lbCycles3.Text = item.Real_cycles.ToString();
                    //最大扭力
                    this.lbMaxTorque3.Text = item.Max_torque.ToString();
                    //耗时
                    this.lbTotalMsecTime3.Text = item.Total_msec_time.ToString();
                    //拧紧结果
                    this.lbTightenStatus3.Text = item.Tighten_status;
                    if (item.Tighten_status != "OK")
                        this.lbTightenStatus3.ForeColor = Color.Red;
                    else
                        this.lbTightenStatus3.ForeColor = Color.LimeGreen;
                }
            }

            scottRealWave1.Refresh();
            scottRealWave2.Refresh();
            scottRealWave3.Refresh();

        }

        private void btnQueryWave_Click(object sender, EventArgs e)
        {
            if (txbBandSnWave.Text.Trim().Length != StaticSettings.iBandSnLength)
            {
                fm = new frmMsg();
                fm.strMsg = "Fail";
                fm.strRem = string.Format("Band码不足{0}位", StaticSettings.iBandSnLength);
                fm.MyForeColor = Color.Red;
                fm.ShowDialog();
                return;
            }

            LoadWaveData(txbBandSnWave.Text.Trim());
        }
        /// <summary>
        /// 设置电批功能是否可用
        /// </summary>
        public void SetDplusEnabled()
        {
            if (int.TryParse(StaticSettingsCommunication.MachineNo, out int machineNo))
            {
                if (machineNo >= 3 && machineNo <= 5)
                {
                    this.btnDPlusManual.Enabled = true;
                }
                else
                {
                    this.btnDPlusManual.Enabled = false;
                }
            }
        }


        private void GetNotPostDate()
        {
            FileComparer fc = new FileComparer();
            arrFI = fc.GetFilesAllDir(StaticSettings.AppDomain + @"\Log\NotPost");
            if (arrFI.Length > 0)
            {
                for (int i = arrFI.Length - 1; i >= 0; i--)
                {
                    richTextBox2.AppendText(arrFI[i].Name);
                    richTextBox2.AppendText("\r\n");
                }
            }
        }

        private void GetDplusData()
        {
            FileComparer fc = new FileComparer();
            arrFI = fc.GetFilesAllDir(StaticSettings.AppDomain + @"\Log\DPlus");
            if (arrFI.Length > 0)
            {
                for (int i = arrFI.Length - 1; i >= 0; i--)
                {
                    dplusRTB.AppendText(arrFI[i].Name);
                    dplusRTB.AppendText("\r\n");
                }
            }
        }


        frmMsg fm = null;
        private void btnUpload_Click(object sender, EventArgs e)
        {
            if (txtBandSN.Text.Trim().Length != StaticSettings.iBandSnLength)
            {
                fm = new frmMsg();
                fm.strMsg = "Fail";
                fm.strRem = string.Format("Band码不足{0}位", StaticSettings.iBandSnLength);
                fm.MyForeColor = Color.Red;
                fm.ShowDialog();
                //MessageBox.Show("　　     Band码，请检查后上传！", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                string strReqJson = string.Empty;
                string strResJson = string.Empty;
                for (int i = arrFI.Length - 1; i >= 0; i--)
                {
                    if (arrFI[i].Name.StartsWith(txtBandSN.Text.Trim()))
                    {
                        strReqJson = File.ReadAllText(arrFI[i].FullName, Encoding.Default);
                        showRtb.AppendTextBox(DateTime.Now.ToString("yyyy-MM-dd_HH:mm:ss.fff") + ",手动上传[" + txtBandSN.Text.Trim() + "]缓存数据。");
                        showRtb.AppendTextBox2("Req:" + strReqJson);
                        strResJson = DaqTraceData.PostData(strReqJson);
                        showRtb.AppendTextBox2("Res:" + strResJson);

                        Post_Trace_Res ptr = new Post_Trace_Res();
                        try
                        {
                            ptr = JsonHelper.StringToJson<Post_Trace_Res>(strResJson);
                            //frm_index.UpdateStatus("Trace", 1);
                            arrFI[i].Delete();
                            showRtb.AppendTextBox(DateTime.Now.ToString("yyyy-MM-dd_HH:mm:ss.fff") + ",手动上传[" + txtBandSN.Text.Trim() + "]缓存数据：PASS。");
                            richTextBox1.AppendText(DateTime.Now.ToString("yyyy-MM-dd_HH:mm:ss.fff") + ",Trace手动上传[" + txtBandSN.Text.Trim() + "]缓存数据：PASS。");
                            //fm=new frmMsg("Pass", "上传成功。" , Color.Lime).ShowDialog();
                            fm.strMsg = "Pass";
                            fm.MyForeColor = Color.LimeGreen;
                            fm.ShowDialog();
                        }
                        catch (Exception ex)
                        {
                            //frm_index.UpdateStatus("Trace", 2);
                            //ModbusApiH5U.H5U_Write(10, 103);
                            showRtb.AppendTextBox(DateTime.Now.ToString("yyyy-MM-dd_HH:mm:ss.fff") + ",手动上传[" + txtBandSN.Text.Trim() + "]缓存数据：Fail。" + ex.Message);
                            arrFI[i].Delete();
                            richTextBox1.AppendText(DateTime.Now.ToString("yyyy-MM-dd_HH:mm:ss.fff") + ",Trace手动上传[" + txtBandSN.Text.Trim() + "]缓存数据：Fail。" + ex.Message);
                            //new frmMsg("Fail", "上传失败！", Color.Red).ShowDialog();
                            fm.strMsg = "Fail";
                            fm.strRem = ex.Message;
                            fm.MyForeColor = Color.Red;
                            fm.ShowDialog();
                        }
                        break;
                    }
                }
                richTextBox2.Clear();
                GetNotPostDate();
            }
        }

        private void label21_Click(object sender, EventArgs e)
        {

        }
        private void setCombox1Data()
        {
            //EMD.BLL.errorcodes berr = new EMD.BLL.errorcodes();
            //List<third_level_output> comboBoxData = berr.GetThirdLevelList();
            var comboBoxData = StaticAlarmCode.AlarmCodes.Where(x => x.IsManual).ToList();
            comboBox1.DataSource = comboBoxData;
            comboBox1.ValueMember = "ErrorCode";
            comboBox1.DisplayMember = "Alarm";
            comboBox1.SelectedItem = null;
            label20.Text = "无，0";
        }

        private decimal CalculationTimeDisparity(DateTime dateStart, DateTime dateEnd)
        {
            TimeSpan timeStart = new TimeSpan(dateStart.Ticks);
            TimeSpan timeEnd = new TimeSpan(dateEnd.Ticks);
            TimeSpan ts = timeStart.Subtract(timeEnd).Duration();
            double totalMinutes = ts.TotalMinutes;
            return Convert.ToDecimal(totalMinutes);
        }

        private void refresh_Click(object sender, EventArgs e)
        {
            DateTime start_time = start_time_select.Value;
            DateTime end_time = end_time_select.Value;
            //System.Data.DataSet dataSet = null;
            EMD.BLL.alarm bal = new EMD.BLL.alarm();
            string str = $"(start>='{start_time}' and start<='{end_time}' ) or (end >= '{start_time}' and end <='{end_time}') or(start<'{start_time}' and end>'{end_time}')or(end IS NULL) order by start Desc";
            //string str = "start>='" + start_time + "' and start<='" + end_time + "' order by start Desc";
            var dataSet = bal.GetAlarmList(str);
            if (dataSet != null && dataSet.Count > 0)
            {
                if (dataSet[0].start >= end_time && dataSet[0].end == null)
                    dataSet.RemoveAt(0);
                foreach (var item in dataSet)
                {
                    if (item.end == null && (item.start <= end_time && DateTime.Now >= start_time))
                        item.end = DateTime.Now;
                    if (item.start < start_time)
                        item.start = start_time;
                    if (item.end > end_time && item.end != null)
                        item.end = end_time;
                    if (item.end != null)
                        item.atimes = ((DateTime)item.end - item.start).TotalMinutes;
                }
                //int i = 1;
                //foreach (var model in dataSet)
                //{
                //    double dMin = 0.0;
                //    if (i == 1)
                //    {
                //        DateTime dts = DateTime.Now;
                //        if (dts < end_time)
                //        {
                //            dMin = Math.Round((dts - model.start).TotalSeconds / 60, 3);
                //            model.end = dts;
                //        }
                //        else
                //        {
                //            dMin = Math.Round((end_time - model.start).TotalSeconds / 60, 3);
                //            model.end = end_time;
                //        }
                //    }
                //    if (i == dataSet.Count)
                //    {
                //        if (start_time > model.start)
                //            model.start = start_time;
                //        dMin = Math.Round(((DateTime)model.end - model.start).TotalMinutes, 3);
                //    }
                //    else
                //    {
                //        if (model.atimes == 0)
                //        {
                //            dMin = Math.Round((DateTime.Now - model.start).TotalSeconds / 60, 3);
                //        }
                //        else
                //        {
                //            dMin = Math.Round(1.0 * model.atimes / 60, 3);
                //        }
                //    }
                //    i++;
                //    model.atimes = dMin;
                //}
                dataGridView1.DataSource = dataSet;
            }

            //EMD.BLL.alarm bal = new EMD.BLL.alarm();
            //List<getTableDataOutput> output = bal.GetOEETableData(start_time, end_time);
            //Label lblTemp = null;
            //int count = 1;
            //for (int i = 1; i <= 9; i++)
            //{
            //    foreach (var ctrl in panel9.Controls)
            //    {
            //        lblTemp = (Label)ctrl;
            //        if (lblTemp.Name == "start_time_" + i)
            //        {
            //            lblTemp.Text = "";
            //            lblTemp.Visible = false;
            //        }
            //        else if (lblTemp.Name == "minute_" + i)
            //        {
            //            lblTemp.Text = "";
            //            lblTemp.Visible = false;
            //        }
            //        else if (lblTemp.Name == "error_code_" + i)
            //        {
            //            lblTemp.Text = "";
            //            lblTemp.Visible = false;
            //        }
            //        else if (lblTemp.Name == "error_name_" + i)
            //        {
            //            lblTemp.Text = "";
            //            lblTemp.Visible = false;
            //        }
            //    }
            //}
            //foreach (var item in output)
            //{
            //    if (item.end.Year == 1)
            //    {
            //        item.end = DateTime.Now;
            //    }
            //    item.minutes = CalculationTimeDisparity(item.start, item.end);
            //    foreach (var ctrl in panel9.Controls)
            //    {
            //        lblTemp = (Label)ctrl;
            //        if (lblTemp.Name == "start_time_" + count)
            //        {
            //            lblTemp.Text = " " + item.start.ToString("yyyy-MM-dd HH:mm:ss");
            //            lblTemp.Visible = true;
            //        }
            //        else if (lblTemp.Name == "minute_" + count)
            //        {
            //            lblTemp.Text = " " + item.minutes.ToString("0.00");
            //            lblTemp.Visible = true;
            //        }
            //        else if (lblTemp.Name == "error_code_" + count)
            //        {
            //            lblTemp.Text = " " + item.acode.ToString();
            //            lblTemp.Visible = true;
            //        }
            //        else if (lblTemp.Name == "error_name_" + count)
            //        {
            //            lblTemp.Text = " " + item.aname;
            //            lblTemp.Visible = true;
            //        }
            //    }
            //    count++;
            //}
            CreateChart(dataSet, start_time, end_time);

        }
        private void CreateChart(List<alarmData> input, DateTime start, DateTime end)
        {
            double[] yValues = new double[9];
            string[] xValues = { "待料", "关机", "生产", "吃饭休息", "宕机", "维护保养", "调试", "更换耗材", "首件" };
            decimal total_time = CalculationTimeDisparity(start, end);
            foreach (var item in input)
            {
                if (item.end == null)
                {
                    item.end = DateTime.Now;
                }
                if (item.start < start)
                {
                    item.start = start;
                }
                if (item.end > end)
                {
                    item.end = end;
                }
                if (item.end > item.start)
                {
                    item.atimes = ((DateTime)item.end - item.start).TotalMinutes;
                }
                else
                {
                    item.atimes = (DateTime.Now - item.start).TotalMinutes;
                }
                if (item.status != 0)
                {
                    switch (item.status)
                    {
                        case 0:
                            break;
                        case 1:
                            yValues[0] += Math.Round(item.atimes, 2);
                            break;
                        case 2:
                            yValues[2] += Math.Round(item.atimes, 2);
                            break;
                        case 3:
                            yValues[4] += Math.Round(item.atimes, 2);
                            break;
                        case 4:
                            yValues[5] += Math.Round(item.atimes, 2);
                            break;
                        case 5:
                            yValues[6] += Math.Round(item.atimes, 2);
                            break;
                        case 6:
                            yValues[1] += Math.Round(item.atimes, 2);
                            break;
                        case 7:
                            yValues[3] += Math.Round(item.atimes, 2);
                            break;
                        case 8:
                            yValues[7] += Math.Round(item.atimes, 2);
                            break;
                        case 9:
                            yValues[8] += Math.Round(item.atimes, 2);
                            break;
                    }
                }
                else
                {
                    yValues[2] += Math.Round(item.atimes, 2);
                }
                //total_time = total_time - item.minutes;
            }
            //yValues[2] = Math.Round(total_time, 2);
            chart1.Series[0].XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.String;
            chart1.Series["Series1"].Points.DataBindXY(xValues, yValues);
            chart1.Series["Series1"].LegendText = "#VALX - #PERCENT{P2},#VALY(m)";
            chart1.Series["Series1"]["PieLineColor"] = "Black";
            chart1.Series["Series1"]["PieLabelStyle"] = "Outside";
            for (int i = 0; i < yValues.Length; i++)
            {
                if (yValues[i] == 0)
                {
                    chart1.Series["Series1"].Points[i].Label = "#VALX, #VALY";
                }
                else
                {
                    chart1.Series["Series1"].Points[i].Label = "#VALX, #VALY";
                }
            }
            //chart1.Series["Series1"].Label = "#VALX, #VALY";
            chart1.Update();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //EMD.BLL.errorcodes berr = new EMD.BLL.errorcodes();
            //List<third_level_output> comboBoxData = berr.GetThirdLevelList();
            if (null != comboBox1.SelectedItem)
            {
                var alarmCodeModel = comboBox1.SelectedItem as AlarmCodeModel;
                label20.Text = alarmCodeModel.Alarm + "," + alarmCodeModel.ErrorCode;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (null != comboBox1.SelectedItem)
            {
                var selectAlarmCodeModel = comboBox1.SelectedItem as AlarmCodeModel;
                selectAlarmCodeModel.Trigger = (suc) =>
                {
                    if (suc)
                    {
                        //todo触发刷新Oee
                        DateTime start_time = DateTime.Now.AddDays(-1);
                        DateTime end_time = DateTime.Now;
                        EMD.BLL.alarm bal = new EMD.BLL.alarm();
                        List<getTableDataOutput> output = bal.GetOEETableData(start_time, end_time);
                        Label lblTemp = null;
                        int count = 1;
                        //for (int i = 1; i <= 9; i++)
                        //{
                        //    foreach (var ctrl in panel9.Controls)
                        //    {
                        //        lblTemp = (Label)ctrl;
                        //        if (lblTemp.Name == "start_time_" + i)
                        //        {
                        //            lblTemp.Text = "";
                        //            lblTemp.Visible = false;
                        //        }
                        //        else if (lblTemp.Name == "minute_" + i)
                        //        {
                        //            lblTemp.Text = "";
                        //            lblTemp.Visible = false;
                        //        }
                        //        else if (lblTemp.Name == "error_code_" + i)
                        //        {
                        //            lblTemp.Text = "";
                        //            lblTemp.Visible = false;
                        //        }
                        //        else if (lblTemp.Name == "error_name_" + i)
                        //        {
                        //            lblTemp.Text = "";
                        //            lblTemp.Visible = false;
                        //        }
                        //    }
                        //}
                        //foreach (var item in output)
                        //{
                        //    foreach (var ctrl in panel9.Controls)
                        //    {
                        //        lblTemp = (Label)ctrl;
                        //        if (lblTemp.Name == "start_time_" + count)
                        //        {
                        //            lblTemp.Text = " " + item.start.ToString("yyyy-MM-dd HH:mm:ss");
                        //            lblTemp.Visible = true;
                        //        }
                        //        else if (lblTemp.Name == "minute_" + count)
                        //        {
                        //            lblTemp.Text = " " + item.minutes.ToString("0.00");
                        //            lblTemp.Visible = true;
                        //        }
                        //        else if (lblTemp.Name == "error_code_" + count)
                        //        {
                        //            lblTemp.Text = " " + item.acode.ToString();
                        //            lblTemp.Visible = true;
                        //        }
                        //        else if (lblTemp.Name == "error_name_" + count)
                        //        {
                        //            lblTemp.Text = " " + item.aname;
                        //            lblTemp.Visible = true;
                        //        }
                        //    }
                        //    count++;
                        //}
                        //CreateChart(output, start_time, end_time);
                    }
                };
                OeeConfirm?.Invoke(this, new OeeEventArgs<AlarmCodeModel>(selectAlarmCodeModel));

            }
            /*
            if (comboBox1.SelectedIndex >= 0)
            {
                EMD.BLL.errorcodes berr = new EMD.BLL.errorcodes();
                alarm alarm = new alarm();
                alarm.start = DateTime.Now;
                List<third_level_output> comboBoxData = berr.GetThirdLevelList();
                if (comboBox1.SelectedIndex >= 0)
                {
                    alarm.acode = int.Parse(comboBoxData[comboBox1.SelectedIndex].error_code);
                    alarm.aname = comboBoxData[comboBox1.SelectedIndex].third_level_name_cn;
                    alarm.remark = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " " + comboBoxData[comboBox1.SelectedIndex].third_level_name_cn;
                }
                alarm.status = 1;
                alarm.atimes = 0;
                EMD.BLL.alarm aa = new EMD.BLL.alarm();
                bool result = aa.Add(alarm);

                DateTime start_time = DateTime.Now.AddDays(-1);
                DateTime end_time = DateTime.Now;
                EMD.BLL.alarm bal = new EMD.BLL.alarm();
                List<getTableDataOutput> output = bal.GetOEETableData(start_time, end_time);
                Label lblTemp = null;
                int count = 1;
                for (int i = 1; i <= 9; i++)
                {
                    foreach (var ctrl in panel9.Controls)
                    {
                        lblTemp = (Label)ctrl;
                        if (lblTemp.Name == "start_time_" + i)
                        {
                            lblTemp.Text = "";
                            lblTemp.Visible = false;
                        }
                        else if (lblTemp.Name == "minute_" + i)
                        {
                            lblTemp.Text = "";
                            lblTemp.Visible = false;
                        }
                        else if (lblTemp.Name == "error_code_" + i)
                        {
                            lblTemp.Text = "";
                            lblTemp.Visible = false;
                        }
                        else if (lblTemp.Name == "error_name_" + i)
                        {
                            lblTemp.Text = "";
                            lblTemp.Visible = false;
                        }
                    }
                }
                foreach (var item in output)
                {
                    foreach (var ctrl in panel9.Controls)
                    {
                        lblTemp = (Label)ctrl;
                        if (lblTemp.Name == "start_time_" + count)
                        {
                            lblTemp.Text = " " + item.start.ToString("yyyy-MM-dd HH:mm");
                            lblTemp.Visible = true;
                        }
                        else if (lblTemp.Name == "minute_" + count)
                        {
                            lblTemp.Text = " " + item.minutes.ToString("0.00");
                            lblTemp.Visible = true;
                        }
                        else if (lblTemp.Name == "error_code_" + count)
                        {
                            lblTemp.Text = " " + item.acode.ToString();
                            lblTemp.Visible = true;
                        }
                        else if (lblTemp.Name == "error_name_" + count)
                        {
                            lblTemp.Text = " " + item.aname;
                            lblTemp.Visible = true;
                        }
                    }
                    count++;
                }
                CreateChart(output, start_time, end_time);
            }

            //*/
        }

        private void button6_Click(object sender, EventArgs e)
        {
            long tick = DateTime.Now.Ticks;
            Random random = new Random((int)(tick & 0xffffffffL) | (int)(tick >> 32));
            var no = random.Next(30, 36);
            var time = random.Next(999, 1301);
            var torque = Math.Round((double)random.Next(360, 400) / 1000, 3);
            string bandsn = "";
            string unit_serial_number = "";
            if (txtBandSN.Text.Trim().Length >= 17)
            {
                bandsn = txtBandSN.Text.Trim();
                unit_serial_number = txtBandSN.Text.Trim().Substring(0, 17);
            }
            else
            {
                bandsn = txtBandSN.Text.Trim();
                unit_serial_number = txtBandSN.Text.Trim();
            }
            TraceUploadData Trace_data = new TraceUploadData();
            Trace_data.serials = new serial();
            Trace_data.data = new data();
            Trace_data.data.insight = new insight();
            Trace_data.data.insight.test_attributes = new test_attribute();
            Trace_data.data.insight.test_station_attributes = new test_station_attribute();
            Trace_data.data.insight.uut_attributes = new uut_attribute();

            Trace_data.serials.band = bandsn;

            Trace_data.data.insight.test_attributes.test_result = "pass";
            Trace_data.data.insight.test_attributes.unit_serial_number = unit_serial_number;
            Trace_data.data.insight.test_attributes.uut_start = DateTime.Now.AddSeconds(-no).ToString("yyyy-MM-dd HH:mm:ss");
            Trace_data.data.insight.test_attributes.uut_stop = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            Trace_data.data.insight.test_station_attributes.fixture_id = "0";
            Trace_data.data.insight.test_station_attributes.head_id = "1";
            Trace_data.data.insight.test_station_attributes.line_id = StaticSettingsTrace.line_id;
            Trace_data.data.insight.test_station_attributes.software_name = "STATION1623";
            Trace_data.data.insight.test_station_attributes.software_version = "220418A";
            Trace_data.data.insight.test_station_attributes.station_id = StaticSettingsTrace.station_id;

            Trace_data.data.insight.uut_attributes.STATION_STRING = "Auto";
            Trace_data.data.insight.uut_attributes.band_sn = bandsn;
            Trace_data.data.insight.uut_attributes.speed = "150rmp";
            Trace_data.data.insight.uut_attributes.target_torque = "0.38kgf.cm";
            Trace_data.data.insight.uut_attributes.tossing_item = "";
            Trace_data.data.insight.uut_attributes.rework_item = "";
            Trace_data.data.insight.uut_attributes.rework_label = "";

            /* todo 取消results数据

            Screw screw1 = new Screw();
            screw1.result = "pass";
            screw1.test = "screw1_torque";
            screw1.units = "kgf.cm";
            screw1.value = Math.Round((double)random.Next(360, 400) / 1000, 3).ToString();

            Trace_data.data.insight.results.Add(screw1);

            Screw screw2 = new Screw();
            screw2.result = "pass";
            screw2.test = "screw1_time";
            screw2.units = "ms";
            screw2.value = random.Next(999, 1301).ToString();
            Trace_data.data.insight.results.Add(screw2);

            //Screw screw3 = new Screw();
            //screw3.result = "pass";
            //screw3.test = "screw1_fastening_time";
            //screw3.units = "ms";
            //screw3.value = random.Next(999, 1301).ToString();
            //Trace_data.data.insight.results.Add(screw3);

            Screw screw4 = new Screw();
            screw4.result = "pass";
            screw4.test = "screw2_torque";
            screw4.units = "kgf.cm";
            screw4.value = Math.Round((double)random.Next(360, 400) / 1000, 3).ToString();
            Trace_data.data.insight.results.Add(screw4);

            Screw screw5 = new Screw();
            screw5.result = "pass";
            screw5.test = "screw2_time";
            screw5.units = "ms";
            screw5.value = random.Next(999, 1301).ToString();
            Trace_data.data.insight.results.Add(screw5);

            //Screw screw6 = new Screw();
            //screw6.result = "pass";
            //screw6.test = "screw2_fastening_time";
            //screw6.units = "ms";
            //screw6.value = random.Next(999, 1301).ToString();
            //Trace_data.data.insight.results.Add(screw6);

            Screw screw7 = new Screw();
            screw7.result = "pass";
            screw7.test = "screw3_torque";
            screw7.units = "kgf.cm";
            screw7.value = Math.Round((double)random.Next(360, 400) / 1000, 3).ToString();
            Trace_data.data.insight.results.Add(screw7);

            Screw screw8 = new Screw();
            screw8.result = "pass";
            screw8.test = "screw3_time";
            screw8.units = "ms";
            screw8.value = random.Next(999, 1301).ToString();
            Trace_data.data.insight.results.Add(screw8);

            //Screw screw9 = new Screw();
            //screw9.result = "pass";
            //screw9.test = "screw3_fastening_time";
            //screw9.units = "ms";
            //screw9.value = random.Next(999, 1301).ToString();
            //Trace_data.data.insight.results.Add(screw9);

            Screw screw10 = new Screw();
            screw10.result = "pass";
            screw10.test = "screw4_torque";
            screw10.units = "kgf.cm";
            screw10.value = Math.Round((double)random.Next(360, 400) / 1000, 3).ToString();
            Trace_data.data.insight.results.Add(screw10);

            Screw screw11 = new Screw();
            screw11.result = "pass";
            screw11.test = "screw4_time";
            screw11.units = "ms";
            screw11.value = random.Next(999, 1301).ToString();
            Trace_data.data.insight.results.Add(screw11);

            //Screw screw12 = new Screw();
            //screw12.result = "pass";
            //screw12.test = "screw4_fastening_time";
            //screw12.units = "ms";
            //screw12.value = random.Next(999, 1301).ToString();
            //Trace_data.data.insight.results.Add(screw12);

            Screw screw13 = new Screw();
            screw13.result = "pass";
            screw13.test = "screw5_torque";
            screw13.units = "kgf.cm";
            screw13.value = Math.Round((double)random.Next(360, 400) / 1000, 3).ToString();
            Trace_data.data.insight.results.Add(screw13);

            Screw screw14 = new Screw();
            screw14.result = "pass";
            screw14.test = "screw5_time";
            screw14.units = "ms";
            screw14.value = random.Next(999, 1301).ToString();
            Trace_data.data.insight.results.Add(screw14);

            //Screw screw15 = new Screw();
            //screw15.result = "pass";
            //screw15.test = "screw5_fastening_time";
            //screw15.units = "ms";
            //screw15.value = random.Next(999, 1301).ToString();
            //Trace_data.data.insight.results.Add(screw15);

            Screw screw16 = new Screw();
            screw16.result = "pass";
            screw16.test = "screw6_torque";
            screw16.units = "kgf.cm";
            screw16.value = Math.Round((double)random.Next(360, 400) / 1000, 3).ToString();
            Trace_data.data.insight.results.Add(screw16);

            Screw screw17 = new Screw();
            screw17.result = "pass";
            screw17.test = "screw6_time";
            screw17.units = "ms";
            screw17.value = random.Next(999, 1301).ToString();
            Trace_data.data.insight.results.Add(screw17);

            //Screw screw18 = new Screw();
            //screw18.result = "pass";
            //screw18.test = "screw6_fastening_time";
            //screw18.units = "ms";
            //screw18.value = random.Next(999, 1301).ToString();
            //Trace_data.data.insight.results.Add(screw18);

            Screw screw19 = new Screw();
            screw19.result = "pass";
            screw19.test = "screw7_torque";
            screw19.units = "kgf.cm";
            screw19.value = Math.Round((double)random.Next(360, 400) / 1000, 3).ToString();
            Trace_data.data.insight.results.Add(screw19);

            Screw screw20 = new Screw();
            screw20.result = "pass";
            screw20.test = "screw7_time";
            screw20.units = "ms";
            screw20.value = random.Next(999, 1301).ToString();
            Trace_data.data.insight.results.Add(screw20);

            //Screw screw21 = new Screw();
            //screw21.result = "pass";
            //screw21.test = "screw7_fastening_time";
            //screw21.units = "ms";
            //screw21.value = random.Next(999, 1301).ToString();
            //Trace_data.data.insight.results.Add(screw21);

            Screw screw22 = new Screw();
            screw22.result = "pass";
            screw22.test = "screw8_torque";
            screw22.units = "kgf.cm";
            screw22.value = Math.Round((double)random.Next(360, 400) / 1000, 3).ToString();
            Trace_data.data.insight.results.Add(screw22);

            Screw screw23 = new Screw();
            screw23.result = "pass";
            screw23.test = "screw8_time";
            screw23.units = "ms";
            screw23.value = random.Next(999, 1301).ToString();
            Trace_data.data.insight.results.Add(screw23);

            //Screw screw24 = new Screw();
            //screw24.result = "pass";
            //screw24.test = "screw8_fastening_time";
            //screw24.units = "ms";
            //screw24.value = random.Next(999, 1301).ToString();
            //Trace_data.data.insight.results.Add(screw24);

            Screw screw25 = new Screw();
            screw25.result = "pass";
            screw25.test = "screw9_torque";
            screw25.units = "kgf.cm";
            screw25.value = Math.Round((double)random.Next(360, 400) / 1000, 3).ToString();
            Trace_data.data.insight.results.Add(screw25);

            Screw screw26 = new Screw();
            screw26.result = "pass";
            screw26.test = "screw9_time";
            screw26.units = "ms";
            screw26.value = random.Next(999, 1301).ToString();
            Trace_data.data.insight.results.Add(screw26);

            //Screw screw27 = new Screw();
            //screw27.result = "pass";
            //screw27.test = "screw9_fastening_time";
            //screw27.units = "ms";
            //screw27.value = random.Next(999, 1301).ToString();
            //Trace_data.data.insight.results.Add(screw27);

            Screw screw28 = new Screw();
            screw28.result = "pass";
            screw28.test = "screw1_whole_angle";
            screw28.units = "°";
            screw28.value = random.Next(720, 1100).ToString();
            Trace_data.data.insight.results.Add(screw28);

            Screw screw29 = new Screw();
            screw29.result = "pass";
            screw29.test = "screw2_whole_angle";
            screw29.units = "°";
            screw29.value = random.Next(720, 1100).ToString();
            Trace_data.data.insight.results.Add(screw29);

            Screw screw30 = new Screw();
            screw30.result = "pass";
            screw30.test = "screw3_whole_angle";
            screw30.units = "°";
            screw30.value = random.Next(720, 1100).ToString();
            Trace_data.data.insight.results.Add(screw30);

            Screw screw31 = new Screw();
            screw31.result = "pass";
            screw31.test = "screw4_whole_angle";
            screw31.units = "°";
            screw31.value = random.Next(720, 1100).ToString();
            Trace_data.data.insight.results.Add(screw31);

            Screw screw32 = new Screw();
            screw32.result = "pass";
            screw32.test = "screw5_whole_angle";
            screw32.units = "°";
            screw32.value = random.Next(720, 1100).ToString();
            Trace_data.data.insight.results.Add(screw32);

            Screw screw33 = new Screw();
            screw33.result = "pass";
            screw33.test = "screw6_whole_angle";
            screw33.units = "°";
            screw33.value = random.Next(720, 1100).ToString();
            Trace_data.data.insight.results.Add(screw33);

            Screw screw34 = new Screw();
            screw34.result = "pass";
            screw34.test = "screw7_whole_angle";
            screw34.units = "°";
            screw34.value = random.Next(720, 1100).ToString();
            Trace_data.data.insight.results.Add(screw34);

            Screw screw35 = new Screw();
            screw35.result = "pass";
            screw35.test = "screw8_whole_angle";
            screw35.units = "°";
            screw35.value = random.Next(720, 1100).ToString();
            Trace_data.data.insight.results.Add(screw35);

            Screw screw36 = new Screw();
            screw36.result = "pass";
            screw36.test = "screw9_whole_angle";
            screw36.units = "°";
            screw36.value = random.Next(720, 1100).ToString();
            Trace_data.data.insight.results.Add(screw36);

            //Screw screw37 = new Screw();
            //screw37.result = "pass";
            //screw37.test = "screw1_angle";
            //screw37.units = "°";
            //screw37.value = random.Next(20, 40).ToString();
            //Trace_data.data.insight.results.Add(screw37);

            //Screw screw38 = new Screw();
            //screw38.result = "pass";
            //screw38.test = "screw2_angle";
            //screw38.units = "°";
            //screw38.value = random.Next(20, 40).ToString();
            //Trace_data.data.insight.results.Add(screw38);

            //Screw screw39 = new Screw();
            //screw39.result = "pass";
            //screw39.test = "screw3_angle";
            //screw39.units = "°";
            //screw39.value = random.Next(20, 40).ToString();
            //Trace_data.data.insight.results.Add(screw39);

            //Screw screw40 = new Screw();
            //screw40.result = "pass";
            //screw40.test = "screw4_angle";
            //screw40.units = "°";
            //screw40.value = random.Next(20, 40).ToString();
            //Trace_data.data.insight.results.Add(screw40);

            //Screw screw41 = new Screw();
            //screw41.result = "pass";
            //screw41.test = "screw5_angle";
            //screw41.units = "°";
            //screw41.value = random.Next(20, 40).ToString();
            //Trace_data.data.insight.results.Add(screw41);

            //Screw screw42 = new Screw();
            //screw42.result = "pass";
            //screw42.test = "screw6_angle";
            //screw42.units = "°";
            //screw42.value = random.Next(20, 40).ToString();
            //Trace_data.data.insight.results.Add(screw42);

            //Screw screw43 = new Screw();
            //screw43.result = "pass";
            //screw43.test = "screw7_angle";
            //screw43.units = "°";
            //screw43.value = random.Next(20, 40).ToString();
            //Trace_data.data.insight.results.Add(screw43);

            //Screw screw44 = new Screw();
            //screw44.result = "pass";
            //screw44.test = "screw8_angle";
            //screw44.units = "°";
            //screw44.value = random.Next(20, 40).ToString();
            //Trace_data.data.insight.results.Add(screw44);

            //Screw screw45 = new Screw();
            //screw45.result = "pass";
            //screw45.test = "screw9_angle";
            //screw45.units = "°";
            //screw45.value = random.Next(20, 40).ToString();
            //Trace_data.data.insight.results.Add(screw45);
            Trace_data.data.insight.results = Trace_data.data.insight.results.OrderBy(x => x.test).ToList();
            //Trace_data.data.insight.items.Add("error_1", "10003001_2020-04-15 01:00:00");
            //Trace_data.data.insight.items.Add("error_2", "10003002_2020-04-15 02:00:00");
            //Trace_data.data.insight.items.Add("error_3", "00000000_2020-04-15 03:00:00");
            //Trace_data.data.insight.items.Add("error_4", "10003003_2020-04-15 01:00:00");
            //Trace_data.data.insight.items.Add("error_5", "10003004_2020-04-15 02:00:00");
            //Trace_data.data.insight.items.Add("error_6", "20000005_2020-04-15 03:00:00");
            //Trace_data.data.items.Add("error_7", "00000000_2020-04-15 03:00:00");


            //*/

            string trace_upload = JsonTools.ObjectToJson(Trace_data);
            showRtb.AppendTextBoxTraceSup(trace_upload);
            //richTextBox1.AppendText("\r\n");
            showRtb.AppendTextBoxTraceSup(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ",Trace手动上传[" + txtBandSN.Text.Trim() + "]缓存数据：PASS。");
            string result = DaqTraceData.PostData(trace_upload);
            //richTextBox1.AppendText("\r\n");
            showRtb.AppendTextBoxTraceSup(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ",Trace手动上传[" + result + "]缓存数据：PASS。");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            OEEProduct data = new OEEProduct();
            OEEUploadRespond result = OEEUpload.OEEProductUpload(data);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            OEEDownTime data = new OEEDownTime();
            OEEUploadRespond result = OEEUpload.OEEDownTimeUpload(data);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            OEEHeart data = new OEEHeart();
            OEEUploadRespond result = OEEUpload.OEEHeartUpload(data);
        }

        //public System.Timers.Timer t1 = new System.Timers.Timer(1000 * 15 * 60);
        //public System.Timers.Timer t2 = new System.Timers.Timer(1000 * 60 * 60);
        //public System.Timers.Timer t3 = new System.Timers.Timer(1000 * 60 * 60);
        public int choose = 0;//0正常、1首件、2吃饭休息
        public System.Timers.Timer timer = new System.Timers.Timer(100);
        decimal minutes = 0;

        private System.Threading.Timer _timerFAT = null;
        private int _intervalFAT = 15 * 60 * 1000;

        private System.Threading.Timer _timerBREAK = null;
        private int _intervalBREAK = 60 * 60 * 1000;

        /// <summary>
        /// 首件超时
        /// </summary>
        private bool _timeOutFAT = false;
        private DateTime _dtFAT = DateTime.Now;
        private DateTime _dtBREAK = DateTime.Now;
        //吃饭休息
        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("　　    是否开始吃饭休息", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            if (dr == DialogResult.Cancel)
                return;
            bool isVaild = false;
            CheckMachineStatus.Invoke(this, new OeeEventArgs<Action<bool>>((suc) =>
            {
                isVaild = !suc;
            }));

            //if (!isVaild)
            //{
            //    MessageBox.Show("　　    请先停止机台 ！", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //    return;
            //}

            button3.Enabled = true;
            button2.Enabled = false;
            choose = 2;

            var alarmCodeModel = StaticAlarmCode.AlarmCodes.FirstOrDefault(x => x.ErrorCode == "11019001");
            alarmCodeModel.IsEnd = false;
            OeeFATOrBREAK?.Invoke(this, new OeeEventArgs<AlarmCodeModel>(alarmCodeModel));
            _dtBREAK = DateTime.Now;
            if (null == _timerBREAK)
            {
                _timerBREAK = new System.Threading.Timer(new TimerCallback(HintBREAK), null, _intervalBREAK, _intervalBREAK);
            }
            else
            {
                _timerBREAK.Change(_intervalBREAK, _intervalBREAK);
            }
        }
        /// <summary>
        /// 吃饭休息结束
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {

            DialogResult dr = MessageBox.Show("　　    是否结束吃饭休息", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            if (dr == DialogResult.Cancel)
                return;
            _timerBREAK.Change(Timeout.Infinite, Timeout.Infinite);

            button2.Enabled = true;
            button3.Enabled = false;
            choose = 0;
            var alarmCodeModel = StaticAlarmCode.AlarmCodes.FirstOrDefault(x => x.ErrorCode == "11019001");
            alarmCodeModel.IsEnd = true;
            OeeFATOrBREAK?.Invoke(this, new OeeEventArgs<AlarmCodeModel>(alarmCodeModel));
        }
        //点选首件开始
        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("　　    是否开始首件", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            if (dr == DialogResult.Cancel)
                return;
            bool isVaild = false;
            CheckMachineStatus.Invoke(this, new OeeEventArgs<Action<bool>>((suc) =>
            {
                isVaild = suc;
            }));

            //if (!isVaild)
            //{
            //    MessageBox.Show("　　    请先运行机台 ！", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //    return;
            //}

            button5.Enabled = true;
            button4.Enabled = false;

            choose = 1;

            var alarmCodeModel = StaticAlarmCode.AlarmCodes.FirstOrDefault(x => x.ErrorCode == "20019001");
            alarmCodeModel.IsEnd = false;
            OeeFATOrBREAK?.Invoke(this, new OeeEventArgs<AlarmCodeModel>(alarmCodeModel));
            _dtFAT = DateTime.Now;
            if (null == _timerFAT)
            {
                _timerFAT = new System.Threading.Timer(new TimerCallback(HintFAT), null, _intervalFAT, _intervalFAT);
            }
            else
            {
                _timerFAT.Change(_intervalFAT, _intervalFAT);
            }
        }
        //点选首件结束
        private void button5_Click(object sender, EventArgs e)
        {

            DialogResult dr = MessageBox.Show("　　    是否结束首件", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            if (dr == DialogResult.Cancel)
                return;
            EndHintFAT();

            button5.Enabled = false;
            button4.Enabled = true;

            var alarmCodeModel = StaticAlarmCode.AlarmCodes.FirstOrDefault(x => x.ErrorCode == "20019001");
            alarmCodeModel.IsEnd = true;
            if (sender == null)
            {
                alarmCodeModel.IsTimeout = true;
            }
            OeeFATOrBREAK?.Invoke(this, new OeeEventArgs<AlarmCodeModel>(alarmCodeModel));
            alarmCodeModel.IsTimeout = false;

        }

        public void EndHintFAT()
        {
            _timerFAT.Change(Timeout.Infinite, Timeout.Infinite);
        }
        private void HintFAT(object state)
        {
            //触发首件超时
            if (DateTime.Now.Subtract(_dtFAT).TotalHours >= 1)
            {
                button5_Click(null, null);
            }
            MessageBox.Show("　　    首件运行时间过长 ！", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void HintBREAK(object state)
        {
            //触发吃饭休息超时
            if (DateTime.Now.Subtract(_dtBREAK).TotalHours >= 1)
            {
                button3_Click(null, null);
            }
        }

        public void warning(object source, System.Timers.ElapsedEventArgs e)
        {
            minutes++;
            //15分钟报警一次
            if (minutes % 15 == 0 && choose == 1)
            {
                DialogResult dr = MessageBox.Show("待料时间过长", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
                EMD.BLL.errorcodes berr = new EMD.BLL.errorcodes();
                alarm alarm = new alarm();
                alarm.start = DateTime.Now;
                List<third_level_output> comboBoxData = berr.GetThirdLevelList();
                alarm.acode = 20019001;
                alarm.aname = "首件";
                alarm.remark = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " " + "首件";
                alarm.status = 1;
                alarm.atimes = 0;
                EMD.BLL.alarm aa = new EMD.BLL.alarm();
                bool result = aa.Add(alarm);
            }
            //每一个小时判断是否待料
            if (minutes % 60 == 0 && choose == 1)
            {
                isWaiting();
            }
            //运行状态大于一小时设备停机报警
            if (minutes / 60 >= 1 && choose == 1)
            {
                choose = 0;
                //上传首件超时报警
                EMD.Model.alarm alarm = new EMD.Model.alarm();
                alarm.start = DateTime.Now;
                alarm.acode = 20019002;
                alarm.aname = "首件超时";
                alarm.status = 1;
                alarm.remark = alarm.start.ToString("yyyy-MM-dd HH:mm:ss") + " " + alarm.aname;
                EMD.BLL.alarm aa = new EMD.BLL.alarm();
                bool result = aa.Add(alarm);
            }
            //超过一个小时强制结束吃饭休息
            if (minutes / 60 >= 1 && choose == 2)
            {
                this.button2.Enabled = true;
                this.button3.Enabled = false;
                //上传设备当前状态
                var request = new OeeDownTimeRequest()
                {
                    ClientPcName = NetHelper.LocalHostName,
                    IP = NetHelper.LANIP_V4,
                    MAC = NetHelper.GetMacByNetworkInterface(),
                    EventTime = DateTime.Now,
                    //设备当前状态
                };
                _ = _oeeMqttClient.PublishOeDownTimeData(request);
                choose = 0;
                timer.Close();
            }

        }
        //15分钟报警一次
        //public void warning(object source, System.Timers.ElapsedEventArgs e)
        //{
        //    DialogResult dr = MessageBox.Show("待料时间过长", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
        //}
        //1小时判断是否待料

        public void isWaiting()
        {
            if (status == "1")
            {
                //上传待料
                var request = new OeeDownTimeRequest()
                {
                    ClientPcName = NetHelper.LocalHostName,
                    IP = NetHelper.LANIP_V4,
                    MAC = NetHelper.GetMacByNetworkInterface(),
                    EventTime = DateTime.Now,
                    Status = OeeDownTimeStatusEnum.WaitingForParts,
                };
                _ = _oeeMqttClient.PublishOeDownTimeData(request);
                timer.Close();
            }
            else
            {
                //上传设备当前状态
                var request = new OeeDownTimeRequest()
                {
                    ClientPcName = NetHelper.LocalHostName,
                    IP = NetHelper.LANIP_V4,
                    MAC = NetHelper.GetMacByNetworkInterface(),
                    EventTime = DateTime.Now,
                    //设备当前状态
                };
                _ = _oeeMqttClient.PublishOeDownTimeData(request);
                timer.Close();
            }
            choose = 0;
        }

        //public void isWaiting(object source, System.Timers.ElapsedEventArgs e)
        //{
        //    OEEDownTime data = new OEEDownTime();
        //    data.EventTime = DateTime.Now;
        //    data.Status = status;
        //    OEEUploadRespond result = OEEUpload.OEEDownTimeUpload(data);
        //}

        private void button11_Click(object sender, EventArgs e)
        {
            this.button6_Click(null, null);
            //var band_sn = this.txtBandSN.Text.Trim();
            //BLL.trace_data traceBll = new BLL.trace_data();
            //var modelTraceUpload = traceBll.GetModelByBandSn(band_sn, 1);//已完成，等待上传的数据
            //if (null == modelTraceUpload)
            //{
            //    showRtb.AppendTextBoxTraceSup(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ",产品码[" + txtBandSN.Text.Trim() + "]未找到对应trace数据，自动生成trace数据。");
            //    this.button6_Click(null, null);
            //}
            //else
            //{
            //    TraceUploadData Trace_data = new TraceUploadData();

            //    Trace_data.serials.band = modelTraceUpload.Band;
            //    Trace_data.data.insight.uut_attributes.speed = modelTraceUpload.Speed;
            //    Trace_data.data.insight.uut_attributes.band_sn = modelTraceUpload.Band_sn;
            //    Trace_data.data.insight.uut_attributes.tossing_item = modelTraceUpload.Tossing_item;
            //    Trace_data.data.insight.uut_attributes.target_torque = modelTraceUpload.Target_torque;
            //    Trace_data.data.insight.uut_attributes.STATION_STRING = modelTraceUpload.Station_string;
            //    Trace_data.data.insight.uut_attributes.rework_item = modelTraceUpload.Rework_item;
            //    Trace_data.data.insight.uut_attributes.rework_label = modelTraceUpload.Rework_label;

            //    Trace_data.data.insight.test_attributes.uut_start = modelTraceUpload.Uut_start.HasValue ? modelTraceUpload.Uut_start.Value.ToString("yyyy-MM-dd HH:mm:ss") : "";
            //    Trace_data.data.insight.test_attributes.uut_stop = modelTraceUpload.Uut_stop.HasValue ? modelTraceUpload.Uut_stop.Value.ToString("yyyy-MM-dd HH:mm:ss") : "";
            //    Trace_data.data.insight.test_attributes.test_result = modelTraceUpload.Test_result;
            //    Trace_data.data.insight.test_attributes.test_result = "pass";//todo 取消results数据 默认上传pass
            //    Trace_data.data.insight.test_attributes.unit_serial_number = modelTraceUpload.Unit_serial_number;

            //    Trace_data.data.insight.test_station_attributes.head_id = modelTraceUpload.Head_id;
            //    Trace_data.data.insight.test_station_attributes.line_id = modelTraceUpload.Line_id;
            //    Trace_data.data.insight.test_station_attributes.fixture_id = modelTraceUpload.Fixture_id;
            //    Trace_data.data.insight.test_station_attributes.station_id = modelTraceUpload.Station_id;
            //    Trace_data.data.insight.test_station_attributes.software_name = modelTraceUpload.Software_name;
            //    Trace_data.data.insight.test_station_attributes.software_version = modelTraceUpload.Software_version;

            //    /* todo 取消results数据
            //   BLL.screw_data screwBll = new BLL.screw_data();
            //   var screwDatas = screwBll.GetModelList(modelTraceUpload.Id);

            //   foreach (var item in screwDatas)
            //   {
            //       Screw screw = new Screw();
            //       screw.value = item.Value;
            //       screw.test = item.Test;
            //       screw.units = item.Units;
            //       screw.result = item.Result;
            //       Trace_data.data.insight.results.Add(screw);
            //   }

            //   if (screwDatas.Count != 9 * 3)
            //   {
            //       for (int i = 0; i < 3; i++)
            //       {
            //           for (int j = 0; j < 3; j++)
            //           {
            //               long tick = DateTime.Now.Ticks;
            //               Random random = new Random((int)(tick & 0xffffffffL) | (int)(tick >> 32));

            //               var screw = screwDatas.FirstOrDefault(x => x.Machine_no == (i + 3) && x.Screw_no == j + 1);
            //               if (screw == null)
            //               {
            //                   var test = "pass";
            //                   string testPrefix = $"screw{i * 3 + j + 1}";

            //                   Screw screwlTorque = new Screw()
            //                   {
            //                       result = test,
            //                       test = $"{testPrefix}_torque",
            //                       value = Math.Round((double)random.Next(360, 400) / 1000, 3).ToString(),
            //                       units = "kgf.cm"
            //                   };
            //                   Trace_data.data.insight.results.Add(screwlTorque);

            //                   Screw screwTime = new Screw()
            //                   {
            //                       result = test,
            //                       test = $"{testPrefix}_time",
            //                       value = random.Next(999, 1301).ToString(),
            //                       units = "ms"
            //                   };
            //                   Trace_data.data.insight.results.Add(screwTime);

            //                   //Screw screwFasteningTime = new Screw()
            //                   //{
            //                   //    result = test,
            //                   //    test = $"{testPrefix}_fastening_time",
            //                   //    value = random.Next(999, 1301).ToString(),
            //                   //    units = "ms"
            //                   //};
            //                   //Trace_data.data.insight.results.Add(screwFasteningTime);

            //                   Screw screwWholeAngle = new Screw()
            //                   {
            //                       result = test,
            //                       test = $"{testPrefix}_whole_angle",
            //                       value = random.Next(720, 1100).ToString(),
            //                       units = "°"
            //                   };
            //                   Trace_data.data.insight.results.Add(screwWholeAngle);

            //                   //Screw screwAngle = new Screw()
            //                   //{
            //                   //    result = test,
            //                   //    test = $"{testPrefix}_angle",
            //                   //    value = random.Next(20, 40).ToString(),
            //                   //    units = "°"
            //                   //};
            //                   //Trace_data.data.insight.results.Add(screwAngle);
            //               }
            //           }
            //       }

            //       Trace_data.data.insight.results = Trace_data.data.insight.results.OrderBy(x => x.test).ToList();
            //   }


            //    BLL.screw_error screwErrorBll = new BLL.screw_error();
            //    var screwErrors = screwErrorBll.GetModelDic(modelTraceUpload.Id);
            //    Trace_data.data.items = screwErrors;

            //    //模拟数据上传并重新计算pass or fail
            //    bool isExsit = screwDatas.Exists(x => x.Result == "fail");
            //    Trace_data.data.insight.test_attributes.test_result = isExsit ? "fail" : "pass";

            //    //*/

            //    string trace_upload = JsonTools.ObjectToJson(Trace_data);
            //    showRtb.AppendTextBoxTraceSup(trace_upload);
            //    showRtb.AppendTextBoxTraceSup(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ",Trace手动上传[" + txtBandSN.Text.Trim() + "]缓存数据：PASS。");
            //    string result = DaqTraceData.PostData(trace_upload);
            //    showRtb.AppendTextBoxTraceSup(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ",Trace手动上传[" + result + "]缓存数据：PASS。");

            //    traceBll.UpdateStatus(new trace_data() { Id = modelTraceUpload.Id, Status = 2 });

            //    logs = new EMD.Model.log(0, "Trace", "Trace补传", StaticModel.StaticLoginUser.username, StaticModel.StaticLoginUser.ip, DateTime.Now);
            //    gblog.Add(logs);
            //}
            label23.Text = (int.Parse(label23.Text) + 1).ToString();
        }


        /// <summary>
        /// Oee确认事件处理
        /// </summary>
        public event OeeConfirmHandler OeeConfirm;
        /// <summary>
        /// 首件或者吃饭休息
        /// </summary>
        public event OeeFATOrBREAKHandler OeeFATOrBREAK;
        /// <summary>
        /// 检查机台运行状态
        /// </summary>
        public event CheckMachineStatusHandler CheckMachineStatus;

        private void button7_Click(object sender, EventArgs e)
        {
            EMD.BLL.alarm bll = new EMD.BLL.alarm();
            //var output = bll.GetList($" start>='{start_time_select.Value}' and end<='{end_time_select.Value}' order by start");
            //Export.ToExcel(output);
            refresh_Click(null, null);
            Export.ToExcel(dataGridView1);

        }
    }

    public delegate void OeeConfirmHandler(object sender, OeeEventArgs<AlarmCodeModel> args);
    public delegate void OeeFATOrBREAKHandler(object sender, OeeEventArgs<AlarmCodeModel> args);
    public delegate void CheckMachineStatusHandler(object sender, OeeEventArgs<Action<bool>> args);
}
